package com.example.project3;

public class Reminder {

    private String title;
    private String date;
    private int priorityImg;
    private String timeStamp;

    public Reminder(String title, String date, String timeStamp, int priorityImg) {
        this.title = title;
        this.date = date;
        this.priorityImg = priorityImg;
        this.timeStamp = timeStamp;
    }

    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public int getPriorityImg() {
        return priorityImg;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setPriorityImg(int priorityImg) {
        this.priorityImg = priorityImg;
    }

    public String getTimeStamp(){
        return timeStamp;

    }
    public void setTimeStamp(String timeStamps){
        this.timeStamp = timeStamps;
    }
}
