package com.example.project3;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.R.layout;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


public class MainActivity extends AppCompatActivity{
    SharedPreferences myprefs;

    SharedPreferences.Editor editor;

    List<Reminder> myReminders;
    List<Reminder> dataLog;
    //var to register (-) click
    Boolean minusPressed = false;

    List<Reminder> data;
    List<Reminder> z = new ArrayList<Reminder>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //test on z
        z.add(new Reminder("first", "10/21/2222", "10:30", R.mipmap.h));
        z.add(new Reminder("second", "10/21/2222", "10:30", R.mipmap.h));
        z.add(new Reminder("third", "10/21/2222", "10:30", R.mipmap.l));

        myprefs = getSharedPreferences("SharedPref", MODE_PRIVATE);

        editor = myprefs.edit();
        Boolean firstTime = getIntent().getBooleanExtra("firstTime", true);
        Log.i("First Time", firstTime.toString());

        Boolean dl = getIntent().getBooleanExtra("dl", false);

        Log.i("dataLog? ", dl.toString());
        if (firstTime){
            editor.clear();
            editor.commit();
        }
        //        get list of reminders
        myReminders = (ArrayList<Reminder>) this.getList("reminders");
        //   get dataLog
        dataLog = (ArrayList<Reminder>) this.getList("dataLog");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView topRight = findViewById(R.id.myList);
        if(dl){
            topRight.setText("Data Log");
        }
        else{
            topRight.setText("Reminders");
        }
        data = getReminders(dl);
        populateListView();
        registerListClicks();

    }

    private List<Reminder> getReminders(Boolean d) {
        List<Reminder> x;
        if(d){
            x = dataLog;
        }
        else{
            x = myReminders;
        }
        //test set arrayList

        Log.i("ArrayList Z", z.toString())  ;
        Log.i("Arraylist x", x.toString());
        return x;
    }

    private void registerListClicks() {
        ListView listView = findViewById(R.id.LV);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View clickedView, int position, long id) {
                //this holds all info about which item was selected from list
                // textView = (TextView) clickedView;
                Log.i("item clicked?","ese");
                boolean d = getIntent().getBooleanExtra("dl", false);
                if(minusPressed){
                    if(d == false){
                        String message = "You deleted item: " + position;
                        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                        //update my reminders based on deletion

                        // update data based on deletion to see if it works
                        data.remove(position);
                        // change shared prefs to reflect
                        setList("reminders", data);

                        populateListView();
                        registerListClicks();

                    }
                }
                minusPressed = false;
            }
        });
    }
// Don't need this if accessing straight from shared preferences
//    private List<Reminder> getMyReminders(){
//        private List<Reminder> myReminders = new ArrayList<Reminder>();
//    }



    private void populateListView() {

        // Create an Adapter (convert list into views)
        ArrayAdapter<Reminder> myAdapter = new MyCustomListAdapter();


//                ArrayAdapter<Reminder>(MainActivity.this, android.R.layout.simple_list_item_1, myReminders);
        // Configure ListView to attach my adapter
        ListView listView = findViewById(R.id.LV);
        listView.setAdapter(myAdapter);
    }

    public void deleteReminder(View view) {
        minusPressed = true;
    }


    private class MyCustomListAdapter extends ArrayAdapter<Reminder>{
        public MyCustomListAdapter() {
            super(MainActivity.this, R.layout.reminderlayout, data);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            //return super.getView(position, convertView, parent);
            View itemView = convertView;
            if (itemView == null)
                itemView = getLayoutInflater().inflate(R.layout.reminderlayout, parent, false);

            TextView textViewTitle = itemView.findViewById(R.id.title);
            TextView textViewDate = itemView.findViewById(R.id.date);
            ImageView imageViewIcon = itemView.findViewById(R.id.image);
            TextView textViewTimeStamp = itemView.findViewById(R.id.TimeStamp);
            // check if user wants to view dataLog or Reminders?
            boolean d = getIntent().getBooleanExtra("dl", false);
            if (d){
                Reminder currentReminder = (Reminder) data.get(position);

                textViewTimeStamp.setText(currentReminder.getTimeStamp());
                textViewTitle.setText(currentReminder.getTitle());
                textViewDate.setText(currentReminder.getDate());
                imageViewIcon.setImageResource(currentReminder.getPriorityImg());

            }
            else{
                Log.i("Date of curReminder", data.get(position).getDate());
                Reminder currentReminder = (Reminder) data.get(position);

                textViewTitle.setText(currentReminder.getTitle());
                textViewDate.setText(currentReminder.getDate());
                imageViewIcon.setImageResource(currentReminder.getPriorityImg());
            }
            return itemView;
        }
    }

    public void toAddReminderActivity(View view) {
        Log.i("Plus", "Activated");
        startActivity(new Intent(MainActivity.this, AddReminder.class));
    }

    public void removeReminder(){
        // function to remove reminder from showList, save showList, call screen update

    }
    public <Reminder> void setList(String key, List<Reminder> list) {
        Gson gson = new Gson();
        String json = gson.toJson(list);

        set(key, json);
    }

    public void set(String key, String value) {

        editor.putString(key, value);
        editor.commit();
    }

    public List<Reminder> getList(String key){
        List<Reminder> arrayItems;

        String serializedObject = myprefs.getString(key, null);
        if (serializedObject != null) {
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<Reminder>>() {
            }.getType();
            arrayItems = gson.fromJson(serializedObject, type);
            Log.i("arrayItems", arrayItems.toString());
            return arrayItems;
        }
        return new ArrayList<Reminder>();
    }
}