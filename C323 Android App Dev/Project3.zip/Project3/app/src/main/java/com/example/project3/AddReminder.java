package com.example.project3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.Calendar;

public class AddReminder extends AppCompatActivity {

    SharedPreferences myprefs;

    SharedPreferences.Editor editor;

    //        get list of reminders
    List<Reminder> myReminders;
    //   get dataLog
    List<Reminder> dataLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //get list of Reminders for additions made later
        setContentView(R.layout.activity_add_reminder);
        myprefs = getSharedPreferences("SharedPref", MODE_PRIVATE);
        editor = myprefs.edit();
        myReminders = this.getList("reminders");
        dataLog = this.getList("dataLog");
    }

    public void addToList(View view) {

        // ask about how to retreive reminders from tinydb? try except block?
        //myReminders = tinydb.getListObject("MyReminders", Reminder.class);
        EditText t = findViewById(R.id.titleEnter);
        String title = t.getText().toString().trim();

        EditText d = findViewById(R.id.dateEnter);
        String date = d.getText().toString().trim();
        boolean isHP = ((CheckBox) findViewById(R.id.highPriority)).isChecked();
        Calendar c = Calendar .getInstance();
        System.out.println("Current time => "+c.getTime());
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mms");
        String timeStamp = df.format(c.getTime());
        Log.i("timestamp", timeStamp);

        if (isHP) {
            myReminders.add(new Reminder(title, date, timeStamp, R.mipmap.h));
            dataLog.add(new Reminder(title, date, timeStamp, R.mipmap.h));
        } else {
            myReminders.add(new Reminder(title, date, timeStamp, R.mipmap.l));
            dataLog.add(new Reminder(title, date, timeStamp, R.mipmap.l));
        }


//      add list of reminders to shared preferences
        setList("reminders", myReminders);
        //come back and make dataLog file
        setList("dataLog", dataLog);

        // pass myReminders list to mainActivity to populate list even though you could just grab from shared prefs
        Intent intent = new Intent(AddReminder.this, MainActivity.class);
        intent.putExtra("firstTime", false);
        startActivity(intent);
//        TextView tv = findViewById(R.id.myList);
//        tv.setText("Reminders");

    }
    public <Reminder> void setList(String key, List<Reminder> list) {
        Gson gson = new Gson();
        String json = gson.toJson(list);

        set(key, json);
    }

    public void set(String key, String value) {

        editor.putString(key, value);
        editor.commit();
    }

    public List<Reminder> getList(String key){
        List<Reminder> arrayItems;
        String serializedObject = myprefs.getString(key, null);
        if (serializedObject != null) {
            Gson gson = new Gson();
            String json = myprefs.getString(key, null);
            Type type = new TypeToken<ArrayList<Reminder>>() {
            }.getType();
            arrayItems = gson.fromJson(json, type);
            return arrayItems;
        }
        return new ArrayList<Reminder>();
    }

    public void viewDataLog(View view) {
        // pass data log list to mainActivity to populate list with intent extra saying data log was pressed
        Intent intent = new Intent(AddReminder.this, MainActivity.class);
        intent.putExtra("dl", true);
        intent.putExtra("firstTime", false);
        startActivity(intent);
//        TextView tv = findViewById(R.id.myList);
//        tv.setText("Data Log");
    }
}