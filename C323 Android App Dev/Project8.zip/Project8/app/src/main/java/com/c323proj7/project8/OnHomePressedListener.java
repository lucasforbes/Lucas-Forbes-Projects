package com.c323proj7.project8;

public interface OnHomePressedListener {
    void onHomePressed();
    void onHomeLongPressed();
}