package com.c323proj7.project8;

public interface SmsListener {
    public void messageReceived(String messageText);
}
