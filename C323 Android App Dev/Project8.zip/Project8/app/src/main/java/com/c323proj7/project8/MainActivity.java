package com.c323proj7.project8;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    EditText OTPEdit;
    TextView message;
    BroadcastReceiver receiver;
    IntentFilter intentFilter;
    String code;
    MediaPlayer.OnCompletionListener l;
    int fetch;
    MusicPlayer mp;
    HomeWatcher mHomeWatcher;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mHomeWatcher = new HomeWatcher(this);
        mHomeWatcher.setOnHomePressedListener(new OnHomePressedListener() {
            @Override
            public void onHomePressed() {
                mp.player.stop();
            }
            @Override
            public void onHomeLongPressed() {
            }
        });
        mHomeWatcher.startWatch();
        fetch = 0;
        OTPEdit = findViewById(R.id.OTPNumber);
        message = findViewById(R.id.OTPverification);
        disableSmsButton();
        checkForSmsPermission();
        configureReciever();
    }

    private void configureReciever() {
        intentFilter = new IntentFilter();
        intentFilter.addAction("android.provider.Telephony.SMS_RECEIVED");
        receiver = new SmsReceiver();
        receiver.goAsync();
        registerReceiver(receiver, intentFilter);
        code = receiver.getResultData();
        OTPEdit.setText(code);
    }

    @Override
    protected void onResume() {
        registerReceiver(receiver, intentFilter);
        super.onResume();
    }
    @Override
    protected void onPause() {
        unregisterReceiver(receiver);
        super.onPause();
    }
    private void sendB() {
        Intent sendIntent = new Intent(Intent.ACTION_VIEW);
        sendIntent.putExtra("sms_body", "Content of the SMS goes here...");
        sendIntent.setType("vnd.android-dir/mms-sms");
        sendBroadcast(sendIntent);
    }


    public void playMusic(View view) {
        // maybe call AsyncTask to play music
        ImageView im = findViewById(R.id.pic);
        im.setImageResource(R.mipmap.g);
//        mp = MediaPlayer.create(MainActivity.this, R.raw.chimes);
////        mp.start();
////        mp.setOnCompletionListener(l);
        mp = new MusicPlayer(getApplicationContext());
        mp.execute();
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        System.out.println("onKeyDown");
        if (keyCode == KeyEvent.KEYCODE_HOME) {
            mp.cancel(true); //stop media player
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    public void verify(View view) {
        if(fetch == 0) {
            message.setText("Your Code Below. Press Verify to continue");
        }

        // verify info correct then start activity two
        code = receiver.getResultData();
        OTPEdit.setText(code);
        System.out.println("Code in main" + code);
        if(fetch == 1){
            if(code != null){
                if( fetch == 1 && code.compareTo("1234") == 0){
                    receiver.abortBroadcast();
                    Intent intent = new Intent(MainActivity.this, activity2class.class);
                    intent.putExtra("getTextsInt", 1);
                    startActivity(intent);
                }
                else{
                    message.setText("Invalid code, Please send the correct code 1234 to continue");
                    fetch = 0;
                }
            }else{
                message.setText("Invalid code, Please send the correct code 1234 to continue");
                fetch = 0;
            }

        }
        fetch = 1;



    }

//    private class myThreadTask extends AsyncTask<String, Void, String> {
//
//        @Override
//        protected String doInBackground(String... strings) {
//            return null;
//        }
//    }

    private void checkForSmsPermission() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.RECEIVE_SMS) !=
                PackageManager.PERMISSION_GRANTED) {
            // Permission not yet granted. Use requestPermissions().
            // MY_PERMISSIONS_REQUEST_SEND_SMS is an
            // app-defined int constant. The callback method gets the
            // result of the request.
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECEIVE_SMS},
                    13);
        } else {
            // Permission already granted. Enable the SMS button.
            enableSmsButton();
        }
    }

    private void enableSmsButton() {
        Button but = findViewById(R.id.VerifyButton);
        but.setVisibility(View.VISIBLE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 13: {
                if (permissions[0].equalsIgnoreCase
                        (Manifest.permission.RECEIVE_SMS)
                        && grantResults[0] ==
                        PackageManager.PERMISSION_GRANTED) {
                    // Permission was granted. Enable sms button.
                    enableSmsButton();
                } else {
                    // Permission denied.
                    Toast.makeText(this, "Permission Denied, No Recieving Texts", Toast.LENGTH_LONG).show();
                    // Disable the sms button.
                    disableSmsButton();
                }
            }
        }
    }

    private void disableSmsButton() {
        Button but = findViewById(R.id.VerifyButton);
        but.setVisibility(View.INVISIBLE);
    }

    public void testMessage(View view) {
        Intent sendIntent = new Intent();
        sendIntent.setFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
        sendIntent.putExtra("sms_body", "Content of the SMS goes here...");
        sendIntent.setType("vnd.android-dir/mms-sms");
        sendBroadcast(sendIntent);
    }
}