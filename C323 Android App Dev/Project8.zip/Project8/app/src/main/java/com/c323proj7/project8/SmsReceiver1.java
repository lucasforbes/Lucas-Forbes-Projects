package com.c323proj7.project8;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Parcelable;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.util.ArrayList;
import java.util.List;

public class SmsReceiver1 extends BroadcastReceiver {
    ArrayList<text> allTexts = new ArrayList<text>();
    activity2class sendResults = new activity2class();
    int check = 0;
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void onReceive(Context context, Intent intent) {
        // Get the SMS message.
        System.out.println("message received");
        //---get the SMS message passed in---
        for (SmsMessage message : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
            if (message == null) {
                Log.i("Check recieved message", "message is null");
                break;
            }
            String smsOriginatingAddress = message.getDisplayOriginatingAddress();
            String smsDisplayMessage = message.getDisplayMessageBody();
            text newText = new text(smsOriginatingAddress, smsDisplayMessage);
            allTexts.add(newText);
            System.out.println(smsDisplayMessage);
            System.out.println("check count" + check);
            sendResults.listTexts = allTexts;
            sendResults.setTexts();
            check += 1;
        }
    }
    public List<text> getAllTexts(){
        return allTexts;
    }
}
