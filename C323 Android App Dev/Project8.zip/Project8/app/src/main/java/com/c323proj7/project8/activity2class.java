package com.c323proj7.project8;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.provider.Telephony;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class activity2class  extends AppCompatActivity {
    List<text> listTexts;
    SmsReceiver1 receiver;
    static Context context = null;
    static ListView LV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);
        listTexts = new ArrayList<text>();
        context = getApplication().getApplicationContext();
        LV = findViewById(R.id.LV);
        // might have background task to get all texts
        int textNum = getIntent().getIntExtra("getTextsInt", 0);
        getTexts();
        setTextsFirst();
    }

    private void setTextsFirst() {
        System.out.println("Setting Adapter");
        ArrayAdapter<text> myAdapter = new MyCustomListAdapter(context, listTexts);

        // set adapter
        ListView listView = LV;

        // add adapter to lv
        listView.setAdapter(myAdapter);
    }

    private void getTexts() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.provider.Telephony.SMS_RECEIVED");
        receiver = new SmsReceiver1();
        receiver.goAsync();
        listTexts = receiver.getAllTexts();
        listTexts.add(new text("Example Number: XXX-XXX-XXXX", "Example Message: Hello" ));
        registerReceiver(receiver,filter);
        System.out.println("Size of listTexts = " + listTexts.size());
    }

    void setTexts() {
        System.out.println("did we get texts?" + listTexts.size());
        System.out.println("Message in setText " +listTexts.get(0).message);
        // get array list of texts
        System.out.println(context.toString());
        ((BaseAdapter) LV.getAdapter()).notifyDataSetChanged();
    }

    public class MyCustomListAdapter extends ArrayAdapter<text> {
        List<text> le;
        public MyCustomListAdapter(Context context, List<text> liste) {
            super(context, R.layout.message, liste);
            le = liste;
            Log.i("here?", "yes");
        }
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            //return super.getView(position, convertView, parent);
            Log.i("getView", "yes");
            View itemView = convertView;
            if (itemView == null)
                itemView = getLayoutInflater().inflate(R.layout.message, parent, false);

            TextView number = itemView.findViewById(R.id.textView);
            TextView message = itemView.findViewById(R.id.MessageText);
            // check if user wants to view dataLog or Reminders?
//            Log.i("List Empty?", le.get(position).getOriginalTitle());
            text currentText = (text) le.get(position);
            number.setText("Phone Number: " +currentText.getPhoneNumber());
            message.setText("Message: " +currentText.getMessage());
            return itemView;
        }
    }

}
