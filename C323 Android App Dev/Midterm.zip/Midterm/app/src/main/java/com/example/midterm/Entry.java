package com.example.midterm;

public class Entry {

    private String name;
    private String history;
    private String bestTime;
    private  String ticketPrice;
    private String image;
    private  double lat;
    private double longa;
    private  int category;


    private String location;

    public Entry(String name, String history, String bestTime, String ticketPrice, String location, String image, double lat, double longa, int cat){
        this.name = name;
        this.history = history;
        this.bestTime =bestTime;
        this. ticketPrice = ticketPrice;
        this.image = image;
        this.lat = lat;
        this.longa = longa;
        this.category = cat;
        this.location = location;
    }
    public Entry(String name, String bestTime, String ticketPrice, String location, String image, double lat,  double longa, int cat){
        this.name = name;
        this.history = "";
        this.bestTime =bestTime;
        this. ticketPrice = ticketPrice;
        this.image = image;
        this.lat = lat;
        this.longa = longa;
        this.category = cat;
        this.location = location;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getBestTime() {
        return bestTime;
    }

    public void setBestTime(String bestTime) {
        this.bestTime = bestTime;
    }

    public String getTicketPrice() {
        return ticketPrice;
    }

    public void setTicketPrice(String ticketPrice) {
        this.ticketPrice = ticketPrice;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLonga() {
        return longa;
    }

    public void setLonga(double longa) {
        this.longa = longa;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

}
