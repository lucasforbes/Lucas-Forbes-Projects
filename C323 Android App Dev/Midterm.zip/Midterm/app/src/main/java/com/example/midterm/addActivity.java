package com.example.midterm;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class addActivity extends AppCompatActivity {
    JSONArray data = new JSONArray();
    ArrayList entries = new ArrayList<Entry>();
    File dir;
    ImageView picFrame;
    Context context;
    String location;
    byte[] picture;
    int category;
    double lata;
    double longa;
    LocationManager locationManager;
    LocationListener locationListener;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.additem);
        dir = getFilesDir();
//        get arraylists
        try {
            getEntries();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        int i = getIntent().getIntExtra("cat", 0);
        category = i;
        FragmentManager fm = getSupportFragmentManager();
        //add
        FragmentTransaction ft = fm.beginTransaction();
        cityFrag frag1 = new cityFrag();
        monumentFrag frag2 = new monumentFrag();
        campingFrag frag3 = new campingFrag();
        if(i == 0){
            ft.add(R.id.fragContainer, frag1);
        }
        else if(i == 1){
            ft.add(R.id.fragContainer, frag2);
        }
        else{
            ft.add(R.id.fragContainer, frag3);
        }
        //commit change
        ft.commit();
        location = "";
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        context = getBaseContext();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Log.i("Provider Enabled? : ", "" + locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER));
            Log.i("Location Enabled? : ", "" + locationManager.isLocationEnabled());
        } else {
            //taken care of
        }

        locationListener = new LocationListener() {
            // method to have location settings changed by user
            @Override
            public void onProviderDisabled(@NonNull String provider) {
                startActivity(new Intent(Settings.ACTION_LOCALE_SETTINGS));
            }

            @Override
            public void onLocationChanged(@NonNull Location location) {
                double lat = location.getLatitude();
                double longi = location.getLongitude();
                lata = lat;
                longa = longi;
                Geocoder g = new Geocoder(context);
                List<Address> locArray = null;
                try {
                    locArray = g.getFromLocation(lat, longi, 1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String city = locArray.get(0).getLocality();
                String state = locArray.get(0).getAdminArea();
                setLocation("Location: " + city + ", " + state);
            }

            private void setLocation(String s) {
                location = s;
            }
        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.INTERNET}, 13);
            return;
        }
        else{
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        }
    }

    private void getEntries() throws IOException, JSONException{
        FileInputStream fis = openFileInput("entries");
        BufferedInputStream bis = new BufferedInputStream(fis);
        StringBuffer b = new StringBuffer();
        while(bis.available() != 0){
            b.append((char)bis.read());
        }
        bis.close();
        fis.close();
        JSONArray data = new JSONArray(b.toString());
        for (int i=0; i < data.length(); i++) {
            StringBuffer sb1 = new StringBuffer();
            StringBuffer sb2 = new StringBuffer();
            StringBuffer sb3 = new StringBuffer();
            StringBuffer sb4 = new StringBuffer();
            StringBuffer sb5 = new StringBuffer();
            // populate list entry with event info
            String name = data.getJSONObject(i).getString("name");
            sb1.append(name);
            String hist = data.getJSONObject(i).getString("hist");
            sb2.append(hist);
            String bestTime = data.getJSONObject(i).getString("bestTime");
            sb3.append(bestTime);
            String ticketPrice = data.getJSONObject(i).getString("ticketPrice");
            sb4.append(ticketPrice);
            String image = data.getJSONObject(i).getString("image");
            sb5.append(image);
            Log.i("Entry info extracted?", sb3.toString());
            double lata = data.getJSONObject(i).getDouble("lat");
            double longa = data.getJSONObject(i).getDouble("longa");
            int cat = data.getJSONObject(i).getInt("cat");
            Log.i("Got Info?", sb2.toString());
            // add to data List
            entries.add(new Entry(sb1.toString(), sb2.toString(), sb3.toString(), sb4.toString(), sb5.toString(), lata, longa, cat));
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case 13:
                if(grantResults.length > 0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 100, 0, locationListener);
                break;
        }
    }

    public void saveCity(View view) throws IOException, JSONException {
        EditText name = findViewById(R.id.name);
        EditText bestTime = findViewById(R.id.bestTime);
        EditText nearest = findViewById(R.id.ticketPtice);
        TextView locatino = findViewById(R.id.locationText2);
        picFrame = findViewById(R.id.picture);
        try{
            Log.i("Exception?", "we");
            if(locatino.getText().toString().compareTo("Click Location") == 0){
                Log.i("Exception?", "asdfasd");
                throw new IOException();
            }
            String encodedImage = Base64.encodeToString(picture, Base64.DEFAULT);
            Log.i("Exception?", "a");
            Entry newEntry = new Entry(name.getText().toString(), bestTime.getText().toString(), nearest.getText().toString(), locatino.getText().toString(), encodedImage, lata, longa, 0);
            entries.add(newEntry);
            writeJSON();
            Intent intent = new Intent(addActivity.this, MainActivity.class);
            startActivity(intent);
            Toast.makeText(getApplicationContext(),"Data has been added",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Please fill out all fields including picture",Toast.LENGTH_SHORT).show();
        }

    }

    public void saveCamping(View view) throws IOException, JSONException {
        EditText name = findViewById(R.id.name);
        EditText bestTime = findViewById(R.id.bestTime);
        EditText nearest = findViewById(R.id.ticketPtice);
        TextView locatino = findViewById(R.id.locationText3);
        picFrame = findViewById(R.id.picture);
        try{
            if(locatino.getText().toString().compareTo("Click Location") == 0){
                throw new IOException();
            }
            String encodedImage = Base64.encodeToString(picture, Base64.DEFAULT);
            Entry newEntry = new Entry(name.getText().toString(), bestTime.getText().toString(), nearest.getText().toString(), locatino.getText().toString(), encodedImage, lata, longa, 2);
            entries.add(newEntry);
            writeJSON();
            Intent intent = new Intent(addActivity.this, MainActivity.class);
            startActivity(intent);
            Toast.makeText(getApplicationContext(),"Data has been added",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Please fill out all fields including picture",Toast.LENGTH_SHORT).show();
        }
    }

    public void saveMonument(View view) throws IOException, JSONException {
        EditText name = findViewById(R.id.name);
        EditText history  = findViewById(R.id.history);
        EditText bestTime = findViewById(R.id.bestTime);
        EditText nearest = findViewById(R.id.ticketPtice);
        TextView locatino = findViewById(R.id.locationText);
        picFrame = findViewById(R.id.picture);
        try{
            if(locatino.getText().toString().compareTo("Click Location") == 0){
                throw new IOException();
            }
            String encodedImage = Base64.encodeToString(picture, Base64.DEFAULT);
            Entry newEntry = new Entry(name.getText().toString(), history.getText().toString(), bestTime.getText().toString(), nearest.getText().toString(), locatino.getText().toString(), encodedImage, lata, longa, 1);
            entries.add(newEntry);
            writeJSON();
            Intent intent = new Intent(addActivity.this, MainActivity.class);
            startActivity(intent);
            Toast.makeText(getApplicationContext(),"Data has been added",Toast.LENGTH_SHORT).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"Please fill out all fields including picture",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK){
            switch (requestCode){
                case 17:
                    Bundle extra = data.getExtras();
                    Bitmap bitmap = (Bitmap) extra.get("data");
                    Bitmap bmp = bitmap;
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    byte[] byteArray = stream.toByteArray();
                    picture = byteArray;
                    if(category == 0){
                        ImageView pic = findViewById(R.id.picture2);
                        pic.setImageBitmap(bitmap);
                        break;
                    }
                    else if(category == 1){
                        ImageView pic = findViewById(R.id.picture);
                        pic.setImageBitmap(bitmap);
                        break;
                    }
                    else{
                        ImageView pic = findViewById(R.id.picture3);
                        pic.setImageBitmap(bitmap);
                        break;
                    }
            }
        }
    }

    public void takePic(View view) {
        // takes user to camera
        if(hasCamera()){
            Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(takePictureIntent, 17);
        }
        else{
            view.setEnabled(false);
        }

    }

    private boolean hasCamera() {
        if(getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)){
            return true;
        }
        else{
            return false;
        }
    }

    public void setLocation(View view) {
        if(category == 0){
            TextView t = findViewById(R.id.locationText2);
            t.setText(location);
        }
        else if(category == 1){
            TextView t = findViewById(R.id.locationText);
            t.setText(location);
        }
        else{
            TextView t = findViewById(R.id.locationText3);
            t.setText(location);
        }
    }
    public void writeJSON()throws JSONException, IOException {
        for (int i = 0; i < entries.size(); i++) {
            Entry x = (Entry) entries.get(i);
            String name = x.getName();
            String hist = x.getHistory();
            String bestTime = x.getBestTime();
            String ticketPrice = x.getTicketPrice();
            String image = x.getImage();
            double lata = x.getLat();
            double longa = x.getLonga();
            int cat = x.getCategory();
            JSONObject event = new JSONObject();
            event.put("name", name);
            event.put("hist", hist);
            event.put("bestTime", bestTime);
            event.put("ticketPrice", ticketPrice);
            event.put("image", image);
            event.put("lat", lata);
            event.put("longa", longa);
            event.put("cat", cat);
            data.put(event);
            String text = data.toString();
            File myFile = new File(dir.getAbsolutePath(),"entries");
            FileOutputStream fos = new FileOutputStream(myFile);
            fos.write(text.getBytes());
            fos.close();
        }
    }
}
