package com.example.midterm;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class favorites extends AppCompatActivity {
    JSONArray data = new JSONArray();
    List<Entry> ent = new ArrayList<Entry>();
    File dir;
    ArrayList<Entry> favorites = new ArrayList<Entry>();
    ArrayAdapter<Entry> myAdapter1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favoriteslayout);
        dir = getFilesDir();
        Intent intent = getIntent();
//        get arraylists
        try {
            getEntries();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
//        favorites = new ArrayList<Entry>();
        populateList(favorites);
    }

    private void populateList(List<Entry> listFavs) {
        myAdapter1 = new MyCustomListAdapter(getApplicationContext(), listFavs);
        ListView listView = findViewById(R.id.listFavs);
        listView.setAdapter(myAdapter1);
    }

    private void getEntries() throws IOException, JSONException {
        FileInputStream fis = openFileInput("entries");
        BufferedInputStream bis = new BufferedInputStream(fis);
        StringBuffer b = new StringBuffer();
        while (bis.available() != 0) {
            b.append((char) bis.read());
        }
        bis.close();
        fis.close();
        JSONArray data = new JSONArray(b.toString());
        for (int i = 0; i < data.length(); i++) {
            StringBuffer sb1 = new StringBuffer();
            StringBuffer sb2 = new StringBuffer();
            StringBuffer sb3 = new StringBuffer();
            StringBuffer sb4 = new StringBuffer();
            StringBuffer sb5 = new StringBuffer();
            // populate list entry with event info
            String name = data.getJSONObject(i).getString("name");
            sb1.append(name);
            String hist = data.getJSONObject(i).getString("hist");
            sb2.append(hist);
            String bestTime = data.getJSONObject(i).getString("bestTime");
            sb3.append(bestTime);
            String ticketPrice = data.getJSONObject(i).getString("ticketPrice");
            sb4.append(ticketPrice);
            String image = data.getJSONObject(i).getString("image");
            sb5.append(image);
            double lata = data.getJSONObject(i).getDouble("lat");
            double longa = data.getJSONObject(i).getDouble("longa");
            int cat = data.getJSONObject(i).getInt("cat");
            Log.i("Got Info?", sb2.toString());
            // add to data List
            name = sb1.toString();
            Log.i("Checking if name works?", name);
            hist = sb2.toString();
            bestTime = sb3.toString();
            ticketPrice = sb4.toString();
            image = sb5.toString();
            Entry t = new Entry(name, hist, bestTime, ticketPrice, image, lata, longa, cat);
            favorites.add(t);
            String n = favorites.get(0).getName();
            Log.i("Name of string", n);
        }
    }

    public class MyCustomListAdapter extends ArrayAdapter<Entry> {
        List<Entry> le;
        public MyCustomListAdapter(Context context, List<Entry> liste) {
            super(context, R.layout.cardview, liste);
            le = liste;
            Log.i("here?", "yes");
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            Log.i("asdf","asldsadfasdfasdfsadfk");
            //return super.getView(position, convertView, parent);
            View itemView = convertView;
            if (itemView == null)
                itemView = getLayoutInflater().inflate(R.layout.cardview, parent, false);
            TextView name = itemView.findViewById(R.id.nameLoc);
            TextView bestTime = itemView.findViewById(R.id.bestTime);
            TextView location = itemView.findViewById(R.id.location);
            TextView tourSpots = itemView.findViewById(R.id.touristSpots);
            Button butt = itemView.findViewById(R.id.addtofavorites);
            butt.setText("REMOVE");
            butt.setTag(position);
            butt.setText("REMOVE");
            Button butt2 = itemView.findViewById(R.id.mapDisplay);
            butt2.setText("");
            butt.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    //How do I know which button is got clicked?
                    int position = (Integer)view.getTag();
                    try {
                        deleteEvent(position);
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
            final Entry currentEntry = (Entry) le.get(position);
            location.setText(currentEntry.getLocation());
            name.setText(currentEntry.getName());
            bestTime.setText(currentEntry.getBestTime());
            tourSpots.setText(currentEntry.getTicketPrice());
            Log.i("Got HEreera","ues");
            return itemView;
        }
    }
    private void deleteEvent(int position) throws IOException, JSONException {
        favorites.remove(position);
        Log.i("Favorite size", "" + favorites.size());
        populateList(favorites);
        writeJSON();
    }
    public void writeJSON()throws JSONException, IOException {
        if(favorites.isEmpty()){
            File myFile1 = new File(dir.getAbsolutePath(),"entries");
            boolean deleted = myFile1.delete();
        }
        for (int i = 0; i < favorites.size(); i++) {
            Entry x = (Entry) favorites.get(i);
            String name = x.getName();
            String hist = x.getHistory();
            String bestTime = x.getBestTime();
            String ticketPrice = x.getTicketPrice();
            String image = x.getImage();
            double lata = x.getLat();
            double longa = x.getLonga();
            int cat = x.getCategory();
            JSONObject event = new JSONObject();
            event.put("name", name);
            event.put("hist", hist);
            event.put("bestTime", bestTime);
            event.put("ticketPrice", ticketPrice);
            event.put("image", image);
            event.put("lat", lata);
            event.put("longa", longa);
            event.put("cat", cat);
            data.put(event);
            String text = data.toString();
            File myFile = new File(dir.getAbsolutePath(),"entries");
            FileOutputStream fos = new FileOutputStream(myFile);
            fos.write(text.getBytes());
            fos.close();
        }
    }
}
