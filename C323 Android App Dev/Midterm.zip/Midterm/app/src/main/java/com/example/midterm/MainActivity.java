package com.example.midterm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ArrayList campingSpots;
    ArrayList citySpots;
    ArrayList monumentSpots;
    JSONArray data = new JSONArray();
    ArrayList entries = new ArrayList<Entry>();
//    List<Entry> favorites = new ArrayList<Entry>();
    File dir;
    int first = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setOnClickListeners();
        ImageView pic = findViewById(R.id.profilePic);
        pic.setImageResource(R.mipmap.man);
        dir = getFilesDir();
//        get arraylists
        try{
            Entry test = (Entry) entries.get(0);
            String name = test.getName();
            Log.i("Json WOrk?", name);
        }catch (Exception e){
            e.printStackTrace();
            Log.i("Json Work?", "no");
        }
    }

    private void setOnClickListeners() {
        ConstraintLayout city = findViewById(R.id.cityLayout);
        ConstraintLayout hist = findViewById(R.id.histLayout);
        ConstraintLayout camp = findViewById(R.id.campingLayout);
        View.OnClickListener citylist = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, displayLists.class);
                intent.putExtra("cat", 0);
                startActivity(intent);
            }
        };
        View.OnClickListener histlist = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, displayLists.class);
                intent.putExtra("cat", 1);
                startActivity(intent);
            }
        };
        View.OnClickListener camplist = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, displayLists.class);
                intent.putExtra("cat", 2);
                startActivity(intent);
            }
        };
        city.setOnClickListener(citylist);
        hist.setOnClickListener(histlist);
        camp.setOnClickListener(camplist);
    }

    public void addCity(View view) throws IOException, JSONException {
        Intent intent = new Intent(MainActivity.this, addActivity.class);
        intent.putExtra("cat", 0);
        startActivity(intent);
    }

    public void addMonument(View view) throws IOException, JSONException {
        Intent intent = new Intent(MainActivity.this, addActivity.class);
        intent.putExtra("cat", 1);
        startActivity(intent);
    }

    public void addCamping(View view) throws IOException, JSONException {
        Intent intent = new Intent(MainActivity.this, addActivity.class);
        intent.putExtra("cat", 2);
        startActivity(intent);
    }



    public void toFavorites(View view) {
        Intent intent = new Intent(MainActivity.this, favorites.class);
        startActivity(intent);
    }
}