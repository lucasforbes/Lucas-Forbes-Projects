package com.example.midterm;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.annotation.ContentView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class displayLists extends AppCompatActivity {
    JSONArray data = new JSONArray();
    List<Entry> ent = new ArrayList<Entry>();
    File dir;
    List<Entry> campingSpots = new ArrayList<Entry>();
    List<Entry> citySpots = new ArrayList<Entry>();
    List<Entry> monumentSpots = new ArrayList<Entry>();
    List<Entry> favorites = new ArrayList<Entry>();
    ArrayAdapter<Entry> myAdapter;
    ArrayAdapter<Entry> myAdapter1;
    int category;
    Context con;
    LinearLayout mainLayout;
    boolean click;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actiitytwofrag);
        con = getApplicationContext();
        mainLayout = new LinearLayout(con);
        dir = getFilesDir();
        Intent intent = getIntent();
        click = true;
        category = intent.getIntExtra("cat", 0);
//        get arraylists
        try {
            getEntries();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        // spent 4 hours trying to figure why when I add to any arrayList, the Strings turn into widgets......
//        I quit and am manually entering data
        ent.clear();
        Entry one = new Entry("Bloomington", "Fall", "Indian University", "Bloomington IN", "", 39.1653, -86.5264, 0   );
        Entry two = new Entry("Colorado Springs", "Summer", "Rocky Mountains", "Colorado Springs, CO", "", 38.8339, -104.8214, 0   );
        Entry three = new Entry("Mt Rushmore", "1891","Fall", "Free", "South Dakota", "", 43.8791, -103.4591, 1   );
        Entry four = new Entry("Washington Monument", "1922","Spring", "Free", "Washington DC", "", 38.8895, -77.0353, 1  );
        Entry five = new Entry("Grand Tetons", "Fall", "Cody WY", "Wyoming", "", 43.7904, -110.6818, 2   );
        Entry six = new Entry("Arches National Park", "Spring", "Moab UT", "Moab UT", "", 38.7331, -109.5925, 2   );
        ent.add(one);
        ent.add(two);
        ent.add(three);
        ent.add(four);
        ent.add(five);
        ent.add(six);
        citySpots.clear();
        citySpots.add(one);
        citySpots.add(two);
        monumentSpots.clear();
        monumentSpots.add(three);
        monumentSpots.add(four);
        campingSpots.clear();
        campingSpots.add(five);
        campingSpots.add(six);
    }
    private void getEntries() throws IOException, JSONException {
        FileInputStream fis = openFileInput("entries");
        BufferedInputStream bis = new BufferedInputStream(fis);
        StringBuffer b = new StringBuffer();
        while (bis.available() != 0) {
            b.append((char) bis.read());
        }
        bis.close();
        fis.close();
        JSONArray data = new JSONArray(b.toString());
        for (int i = 0; i < data.length(); i++) {
            StringBuffer sb1 = new StringBuffer();
            StringBuffer sb2 = new StringBuffer();
            StringBuffer sb3 = new StringBuffer();
            StringBuffer sb4 = new StringBuffer();
            StringBuffer sb5 = new StringBuffer();
            // populate list entry with event info
            String name = data.getJSONObject(i).getString("name");
            sb1.append(name);
            String hist = data.getJSONObject(i).getString("hist");
            sb2.append(hist);
            String bestTime = data.getJSONObject(i).getString("bestTime");
            sb3.append(bestTime);
            String ticketPrice = data.getJSONObject(i).getString("ticketPrice");
            sb4.append(ticketPrice);
            String image = data.getJSONObject(i).getString("image");
            sb5.append(image);
            double lata = data.getJSONObject(i).getDouble("lat");
            double longa = data.getJSONObject(i).getDouble("longa");
            int cat = data.getJSONObject(i).getInt("cat");
            Log.i("Got Info?", sb2.toString());
            // add to data List
            name = sb1.toString();
            Log.i("Checking if name works?", name);
            hist = sb2.toString();
            bestTime = sb3.toString();
            ticketPrice = sb4.toString();
            image = sb5.toString();
            Entry t = new Entry(name, hist, bestTime,ticketPrice,image, lata, longa, cat);
            favorites.add(t);
            String n = favorites.get(0).getName();
//            Log.i("t name", n);
//            if(cat == 0){
//                citySpots.add(t);
//
//                Log.i("Data sadfsadf", "Yes");
//                Log.i("Extracted", sb1.toString());
//            }
//            if(cat == 1){
//                monumentSpots.add(t);
//            }
//            if(cat == 2){
//                campingSpots.add(t);
//            }
        }
    }
    public void writeJSON()throws JSONException, IOException {
        if(favorites.isEmpty()){
            File myFile1 = new File(dir.getAbsolutePath(),"entries");
            boolean deleted = myFile1.delete();
        }
        for (int i = 0; i < favorites.size(); i++) {
            Entry x = (Entry) favorites.get(i);
            String name = x.getName();
            String hist = x.getHistory();
            String bestTime = x.getBestTime();
            String ticketPrice = x.getTicketPrice();
            String image = x.getImage();
            double lata = x.getLat();
            double longa = x.getLonga();
            int cat = x.getCategory();
            JSONObject event = new JSONObject();
            event.put("name", name);
            event.put("hist", hist);
            event.put("bestTime", bestTime);
            event.put("ticketPrice", ticketPrice);
            event.put("image", image);
            event.put("lat", lata);
            event.put("longa", longa);
            event.put("cat", cat);
            data.put(event);
            String text = data.toString();
            File myFile1 = new File(dir.getAbsolutePath(),"entries");
            boolean deleted = myFile1.delete();
            File myFile = new File(dir.getAbsolutePath(),"entries");
            String path = (String) dir.getAbsolutePath();
            Log.i("File path", path);
            FileOutputStream fos = new FileOutputStream(myFile);
            fos.write(text.getBytes());
            fos.close();
        }
    }

    public void displayListView(View view) {
        Entry currentEntry = (Entry) ent.get(0);
        Log.i("please", currentEntry.getLocation());
        if(category == 0){
            myAdapter = new MyCustomListAdapter(getApplicationContext(), citySpots);
            ListView listView = findViewById(R.id.LV);
            listView.setAdapter(myAdapter);
        }
        if(category == 1){
            myAdapter = new MyCustomListAdapter(getApplicationContext(), monumentSpots);
            ListView listView = findViewById(R.id.LV);
            listView.setAdapter(myAdapter);
        }
        if(category == 2){
            myAdapter = new MyCustomListAdapter(getApplicationContext(), campingSpots);
            ListView listView = findViewById(R.id.LV);
            listView.setAdapter(myAdapter);
        }


    }

    public void displayCardView(View view) {
        Entry currentEntry = (Entry) ent.get(0);
        Log.i("please", currentEntry.getLocation());
        if(category == 0){
            myAdapter1 = new MyCustomListAdapter1(getApplicationContext(), citySpots);
            ListView listView = findViewById(R.id.LV);
            listView.setAdapter(null);
            listView.clearAnimation();
            listView.setAdapter(myAdapter1);
        }
        if(category == 1){
            myAdapter1 = new MyCustomListAdapter1(getApplicationContext(), monumentSpots);
            ListView listView = findViewById(R.id.LV);
            listView.setAdapter(null);
            listView.setAdapter(myAdapter1);
        }
        if(category == 2){
            myAdapter1 = new MyCustomListAdapter1(getApplicationContext(), campingSpots);
            ListView listView = findViewById(R.id.LV);
            listView.setAdapter(null);
            listView.setAdapter(myAdapter1);
        }
    }

    public class MyCustomListAdapter extends ArrayAdapter<Entry>{
        List<Entry> le;
        public MyCustomListAdapter(Context context, List<Entry> liste) {
            super(context, R.layout.listview, liste);
            le = liste;
            Log.i("here?", "yes");
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            Log.i("asdf","asldsadfasdfasdfsadfk");
            //return super.getView(position, convertView, parent);
            View itemView = convertView;
            if (itemView == null)
                itemView = getLayoutInflater().inflate(R.layout.listview, parent, false);
            ImageButton Button1 = itemView.findViewById(R.id.popUpWindowButton);
            Button1.setTag(position);
            final PopupWindow popUp = new PopupWindow(con);
            Button1.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    //How do I know which button is got clicked?
                    int position = (Integer)view.getTag();
                    Log.i("popUp position:", ""+position);
                    try {
                        showPopup(position, category);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            TextView location = itemView.findViewById(R.id.location);
            Entry currentEntry = (Entry) le.get(position);
            location.setText(currentEntry.getName());
            Log.i("Got HEreera","ues");
            return itemView;
        }
    }

    private void showPopup(int position, int category) {
        LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        PopupWindow pw = new PopupWindow(inflater.inflate(R.layout.popup, null, false),100,100, true);
        View cont = pw.getContentView();
        TextView name = cont.findViewById(R.id.name);
        TextView info = cont.findViewById(R.id.info);
        List<Entry> use = new ArrayList<Entry>();
        if(category == 0){
            use = citySpots;
        }
        if(category ==1){
            use = monumentSpots;
        }
        if(category == 2){
            use = campingSpots;
        }
        name.setText(use.get(position).getName());
        info.setText(use.get(position).getTicketPrice());
        pw.showAtLocation(this.findViewById(R.id.popUpFrame), Gravity.CENTER, 0, 0);
    }

    public class MyCustomListAdapter1 extends ArrayAdapter<Entry>{
        List<Entry> le;
        public MyCustomListAdapter1(Context context, List<Entry> liste) {
            super(context, R.layout.listview, liste);
            le = liste;
            Log.i("here?", "yes");
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            Log.i("asdf","asldsadfasdfasdfsadfk");
            //return super.getView(position, convertView, parent);
            View itemView = convertView;
            if (itemView == null)
                itemView = getLayoutInflater().inflate(R.layout.cardview, parent, false);
            TextView name = itemView.findViewById(R.id.nameLoc);
            TextView bestTime = itemView.findViewById(R.id.bestTime);
            TextView location = itemView.findViewById(R.id.location);
            TextView tourSpots = itemView.findViewById(R.id.touristSpots);
            final Entry currentEntry = (Entry) le.get(position);
            location.setText(currentEntry.getLocation());
            name.setText(currentEntry.getName());
            bestTime.setText(currentEntry.getBestTime());
            tourSpots.setText(currentEntry.getTicketPrice());
            Button Button1 = itemView.findViewById(R.id.addtofavorites);
            Button1.setTag(position);
            Button1.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    //How do I know which button is got clicked?
                    int position = (Integer)view.getTag();
                    Log.i("Delete position:", ""+position);
                    try {
                        addToFavorites(position, category);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            Button Button2 = itemView.findViewById(R.id.mapDisplay);
            Button2.setTag(position);
            Button2.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    //How do I know which button is got clicked?
                    int position = (Integer)view.getTag();
                    Log.i("Delete position:", ""+position);
                    try {
                        goToMaps(currentEntry.getLat(), currentEntry.getLonga(), currentEntry.getName());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            Log.i("Got HEreera","ues");
            return itemView;
        }
    }

    private void goToMaps(double lat, double longa, String place) {
        Intent intent = new Intent(displayLists.this, MapsActivity.class);  
        intent.putExtra("lat", lat);
        intent.putExtra("long", longa);
        intent.putExtra("p", place);
        startActivity(intent);
    }

    private void addToFavorites(int position, int category) throws IOException, JSONException {
        if(category == 0){
            Log.i("added", "0");
            favorites.add(citySpots.get(position));
        }
        if(category == 1){
            Log.i("added", "1");
            favorites.add(monumentSpots.get(position));
        }
       if(category == 2){
            Log.i("added", "2");
            favorites.add(campingSpots.get(position));
        }
        writeJSON();
    }
}
