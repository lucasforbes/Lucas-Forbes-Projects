package com.example.project6;

public class Event {
    private String eventInfo;
    private String date;
    private String location;
    private double lat;
    private double longa;
    private int deletePressed;
    public Event(String eventInfo, String date, String location, double lat, double longa){
        this.eventInfo = eventInfo;
        this.date = date;
        this.location = location;
        this.lat = lat;
        this.longa = longa;
        this.deletePressed = 0;
    }

    public int getDeletePressed() {
        return deletePressed;
    }

    public void setDeletePressed(int deletePressed) {
        this.deletePressed = deletePressed;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(float lat) {
        this.lat = lat;
    }

    public double getLonga() {
        return longa;
    }

    public void setLonga(float longa) {
        this.longa = longa;
    }

    public String getEventInfo() {
        return eventInfo;
    }

    public void setEventInfo(String eventInfo) {
        this.eventInfo = eventInfo;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

}
