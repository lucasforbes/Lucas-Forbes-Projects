package com.example.project6;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
//
//import com.google.gson.Gson;
//import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    LocationManager locationManager;
    LocationListener locationListener;
    String currentCity;
    String currentState;
    double lata;
    double longa;
    Context context;
    TextView location;
    DatePicker simpleDatePicker;
    List<Event> myEvents;
    JSONArray data = new JSONArray();
    int update = 0;
    public int timer = 0;
    File dir;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        location = findViewById(R.id.location);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        context = getBaseContext();
        dir = getFilesDir();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Log.i("Provider Enabled? : ", "" + locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER));
            Log.i("Location Enabled? : ", "" + locationManager.isLocationEnabled());
        } else {
            //taken care of
        }
        locationListener = new LocationListener() {
            // method to have location settings changed by user
            @Override
            public void onProviderDisabled(@NonNull String provider) {
                startActivity(new Intent(Settings.ACTION_LOCALE_SETTINGS));
            }

            @Override
            public void onLocationChanged(@NonNull Location location) {
                double lat = location.getLatitude();
                double longi = location.getLongitude();
                lata = lat;
                longa = longi;
                Log.i("any change?", "yes");

                Geocoder g = new Geocoder(MainActivity.this);
                List<Address> locArray = null;
                try {
                    locArray = g.getFromLocation(lat, longi, 1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String city = locArray.get(0).getLocality();
                String state = locArray.get(0).getAdminArea();
                currentCity = city;
                currentState = state;
                Log.i("City changed?", currentCity);
            }
        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.INTERNET}, 13);
            return;
        } else {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            //locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        simpleDatePicker = (DatePicker) findViewById(R.id.simpleDatePicker);
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 13:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
                break;
        }
    }

    public void listEventFunc(View view) {
        Intent intent = new Intent(MainActivity.this, EventList.class);
        startActivity(intent);
    }

    public void setLocation(View view) {
//        locationManager.removeUpdates(locationListener);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10, 0, locationListener);
        locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if(timer == 0){
            Log.i("Updeated", "yes");
            location.setText("Wait 6 seconds, then click 'Find' again");
            timer = 1;
        }
        else{
            Log.i("Else","yes" + timer);
            location.setText("Location: " + currentCity + ", " + currentState);
            timer = 0;
        }


        update = 0;
    }

    public void updateLocation(View view) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

    }
    public void storeEvent(View view) throws JSONException, IOException {
        //location already in current city / state
        // Get event info
        EditText eventInfo = findViewById(R.id.eventInfo);
        String info = eventInfo.getText().toString();
        Log.i("Event info?", info);
        // Get Date
        String day = "/"+ simpleDatePicker.getDayOfMonth();
        String month = "" + (simpleDatePicker.getMonth() + 1);
        String year = "/" + simpleDatePicker.getYear();
        if(day.length() == 2){
            day = "/"+ "0" + simpleDatePicker.getDayOfMonth();
        }
        if(month.length() == 1){
            month = "0" + month;
        }
        String date = month + day + year;
        String loca = currentCity + ", " + currentState;
//        Event event = new Event(info,date,loca);
//        myEvents.add(event);
        JSONObject event = new JSONObject();
        event.put("location", loca);
        event.put("date", date);
        event.put("info", info);
        event.put("lata", lata);
        event.put("longa", longa);
        data.put(event);
        String text = data.toString();
        File myFile = new File(dir.getAbsolutePath(),"events");
        FileOutputStream fos = new FileOutputStream(myFile);
//        FileOutputStream fos = openFileOutput("eventList", MODE_PRIVATE);
        fos.write(text.getBytes());
        fos.close();
    }
}