package com.example.project6;

import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Map extends AppCompatActivity {
    List<Event> listEvents = new List<Event>() {
        @Override
        public int size() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean contains(@Nullable Object o) {
            return false;
        }

        @NonNull
        @Override
        public Iterator<Event> iterator() {
            return null;
        }

        @NonNull
        @Override
        public Object[] toArray() {
            return new Object[0];
        }

        @NonNull
        @Override
        public <T> T[] toArray(@NonNull T[] a) {
            return null;
        }

        @Override
        public boolean add(Event event) {
            return false;
        }

        @Override
        public boolean remove(@Nullable Object o) {
            return false;
        }

        @Override
        public boolean containsAll(@NonNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean addAll(@NonNull Collection<? extends Event> c) {
            return false;
        }

        @Override
        public boolean addAll(int index, @NonNull Collection<? extends Event> c) {
            return false;
        }

        @Override
        public boolean removeAll(@NonNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean retainAll(@NonNull Collection<?> c) {
            return false;
        }

        @Override
        public void clear() {

        }

        @Override
        public Event get(int index) {
            return null;
        }

        @Override
        public Event set(int index, Event element) {
            return null;
        }

        @Override
        public void add(int index, Event element) {

        }

        @Override
        public Event remove(int index) {
            return null;
        }

        @Override
        public int indexOf(@Nullable Object o) {
            return 0;
        }

        @Override
        public int lastIndexOf(@Nullable Object o) {
            return 0;
        }

        @NonNull
        @Override
        public ListIterator<Event> listIterator() {
            return null;
        }

        @NonNull
        @Override
        public ListIterator<Event> listIterator(int index) {
            return null;
        }

        @NonNull
        @Override
        public List<Event> subList(int fromIndex, int toIndex) {
            return null;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map);
        try {
            populateMap();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void populateMap() throws IOException, JSONException {
        // first read in json file
        readJSONFile();
        for(int i = 0; i < listEvents.size(); i++){
            // get location
            double lata = listEvents.get(i).getLat();
            double longa = listEvents.get(i).getLonga();
            // mark on map
            LatLng latlng = new LatLng(lata, longa);
            CameraUpdate update = CameraUpdateFactory.newLatLng(latlng );
        }

    }
    public void readJSONFile() throws IOException, JSONException {
        FileInputStream fis = openFileInput("eventList");
        BufferedInputStream bis = new BufferedInputStream(fis);
        StringBuffer b = new StringBuffer();
        while (bis.available() != 0) {
            b.append((char) bis.read());
        }
        bis.close();
        fis.close();
        JSONArray data = new JSONArray(b.toString());
        for (int i = 0; i < data.length(); i++) {
            StringBuffer sb1 = new StringBuffer();
            StringBuffer sb2 = new StringBuffer();
            StringBuffer sb3 = new StringBuffer();
            // populate list entry with event info
            String location = data.getJSONObject(i).getString("location");
            sb1.append(location);
            String date = data.getJSONObject(i).getString("date");
            sb2.append(date);
            String info = data.getJSONObject(i).getString("info");
            sb3.append(info);
            double lata = data.getJSONObject(i).getDouble("lata");
            double longa = data.getJSONObject(i).getDouble("longa");
            Log.i("Got Info?", sb2.toString());
            // add to data List
            listEvents.add(new Event(sb1.toString(), sb2.toString(), sb3.toString(), lata, longa));
//            Log.i("listEntry?", listEvents.get(0).getDate());
        }
    }
}