package com.example.project6;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOError;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class EventList extends AppCompatActivity {
    JSONArray data = new JSONArray();
    List<Event> listEvents = new ArrayList<Event>();
    ArrayAdapter<Event> myAdapter;
    public int delete = 0;
    File dir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listevents);
        dir = getFilesDir();
        try {
            readJSONFile();
        } catch (IOException e) {
            Log.i("IOExcEption","asd");
            e.printStackTrace();
        } catch (JSONException e) {
            Log.i("JSONException","asd");
            e.printStackTrace();
        }
//        myAdapter.notifyDataSetChanged();
//        registerListClicks();
    }
//    public void registerListClicks() {
//        final ListView listv = findViewById(R.id.eventListView);
//        listv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Log.i("item clicked", "uyes");
//                Object listItem = listv.getItemAtPosition(position);
//            }
//        });
//    }

    public void readJSONFile() throws IOException, JSONException{
        FileInputStream fis = openFileInput("events");
        BufferedInputStream bis = new BufferedInputStream(fis);
        StringBuffer b = new StringBuffer();
        while(bis.available() != 0){
            b.append((char)bis.read());
        }
        bis.close();
        fis.close();
        JSONArray data = new JSONArray(b.toString());
        for (int i=0; i < data.length(); i++){
            StringBuffer sb1 = new StringBuffer();
            StringBuffer sb2 = new StringBuffer();
            StringBuffer sb3 = new StringBuffer();

            // populate list entry with event info
            String location = data.getJSONObject(i).getString("location" );
            sb1.append(location);
            String date = data.getJSONObject(i).getString("date" );
            sb2.append(date);
            String info = data.getJSONObject(i).getString("info" );
            sb3.append(info);
            Log.i("Event info extracted?", sb3.toString());
            double lata = data.getJSONObject(i).getDouble("lata");
            double longa = data.getJSONObject(i).getDouble("longa");
            Log.i("Got Info?", sb2.toString());
            // add to data List
            listEvents.add(new Event(sb1.toString(),sb2.toString(),sb3.toString(), lata, longa));
//            Log.i("listEntry?", listEvents.get(0).getDate());
        }
        populateListView(listEvents);
    }
    public void writeJSON()throws JSONException, IOException {

        for (int i = 0; i < listEvents.size(); i++) {
            String eventInfo = listEvents.get(i).getEventInfo();
            String date = listEvents.get(i).getDate();
            String location = listEvents.get(i).getLocation();
            double lat = listEvents.get(i).getLat();
            double longa = listEvents.get(i).getLonga();
            JSONObject event = new JSONObject();
            event.put("location", location);
            event.put("date", date);
            event.put("info", eventInfo);
            event.put("lata", lat);
            event.put("longa", longa);
            data.put(event);
            String text = data.toString();
            File myFile = new File(dir.getAbsolutePath(),"events");
            FileOutputStream fos = new FileOutputStream(myFile);
            fos.write(text.getBytes());
            fos.close();
        }
    }

    public void goToMap(View view) {
        Intent intent = new Intent(EventList.this, MapsActivity.class);
        startActivity(intent);
    }

    public void deletePressed(View view) {
        delete = 1;
        Log.i("deletePressed", "yes");
        return;
    }

    public void filterByDate(View view){
        List<Event> filteredList = new ArrayList<Event>();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        EditText ed1 = findViewById(R.id.date1);
        String d1 = ed1.getText().toString();
        EditText ed2 = findViewById(R.id.date2);
        String d2 = ed2.getText().toString();
        Date date1 = null;
        Date date2= null;
        try{
            date1 = formatter.parse(d1);
            Log.i("date1 worked", "yes");
        }
        catch (ParseException e){
            ed1.setText("Wrong format, please ");
            ed2.setText("enter date MM/DD/YYYY");
        }
        try{
            date2 = formatter.parse(d2);
            Log.i("date2 worked", "yes");
        }
        catch (ParseException e){
            ed1.setText("Wrong format, please ");
            ed2.setText("enter date MM/DD/YYYY");
        }
        if(date1 != null && date2 != null){
            Log.i("here1", "yes");
            Log.i("date1", ""+date1);
            Log.i("date1", ""+date2);
            if(date1.before(date2) || date1.equals(date2)){
                Log.i("here2", "yes");
                for(int i=0; i < listEvents.size(); i++){
                    try{
                        Date eventDate = formatter.parse(listEvents.get(i).getDate());
                        if((eventDate.after(date1) || eventDate.equals(date1)) && (eventDate.before(date2) || eventDate.equals(date2))){
                            Log.i("here3", "yes");
                            filteredList.add(listEvents.get(i));
                        }
                    }
                    catch (ParseException e){

                    }


                }
            }

        }
        if(filteredList.isEmpty()){
            filteredList.add(new Event("No Upcoming Events Found","","",0, 0  ));
        }
        populateListView(filteredList);
    }

    public class MyCustomListAdapter extends ArrayAdapter<Event>{
        List<Event> le;
        public MyCustomListAdapter(Context context, List<Event> liste) {
            super(context, R.layout.eventlistentry, liste);
            le = liste;
            Log.i("here?", "yes");
        }
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            //return super.getView(position, convertView, parent);
            Log.i("getView", "yes");
            View itemView = convertView;
            if (itemView == null)
                itemView = getLayoutInflater().inflate(R.layout.eventlistentry, parent, false);

            TextView textViewLocation = itemView.findViewById(R.id.location);
            TextView textViewDate = itemView.findViewById(R.id.date);
            TextView textViewInfo = itemView.findViewById(R.id.event);
            Button Button1 = itemView.findViewById(R.id.delete);
            Button1.setTag(position);
            Button1.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    //How do I know which button is got clicked?
                    int position = (Integer)view.getTag();
                    Log.i("Delete position:", ""+position);
                    try {
                        deleteEvent(position);
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
            // check if user wants to view dataLog or Reminders?
            Log.i("List Empty?", le.get(position).getDate());
            Event currentReminder = (Event) le.get(position);
            textViewLocation.setText(currentReminder.getLocation());
            textViewDate.setText(currentReminder.getDate());
            textViewInfo.setText(currentReminder.getEventInfo());

            return itemView;
        }
    }
    private void deleteEvent(int position) throws IOException, JSONException {
        listEvents.remove(position);
        populateListView(listEvents);
        writeJSON();
    }
    private void populateListView(List<Event> le) {
        Log.i("populate", "yes");
        // Create an Adapter (convert list into views)
        ArrayAdapter<Event> myAdapter = new MyCustomListAdapter(getApplicationContext(), le);
//        Log.i("setAdapter?", "yes");
        // Configure ListView to attach my adapter
        ListView listView = (ListView) findViewById(R.id.eventListView);
        listView.setAdapter(myAdapter);
        listView.setClickable(true);
        Log.i("setAdapter?", "yes");

    }

}