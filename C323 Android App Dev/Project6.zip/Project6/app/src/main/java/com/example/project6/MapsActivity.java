package com.example.project6;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    List<Event> listEvents = new ArrayList<Event>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        try {
            populateMap();
            Log.i("map populated?", "yes");
        } catch (IOException e) {
            e.printStackTrace();
            Log.i("IOException?", "yes");
        } catch (JSONException e) {
            e.printStackTrace();
            Log.i("JSONException?", "yes");
        }
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
//        LatLng sydney = new LatLng(-34, 151);
//        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
//        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
        for(int i = 0; i < listEvents.size(); i++){
            // get location
            double lata = listEvents.get(i).getLat();
            double longa = listEvents.get(i).getLonga();
            Log.i("Location: ", listEvents.get(i).getLocation());
            // mark on map
            LatLng latlng = new LatLng(lata, longa);
            Marker mark = mMap.addMarker(new MarkerOptions().position(latlng).title("Event: " + (i+1)).draggable(true));
            mMap.moveCamera(CameraUpdateFactory.newLatLng(latlng));
        }

    }

//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.map);
//        try {
//            populateMap();
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//    }

    private void populateMap() throws IOException, JSONException {
        // first read in json file
        readJSONFile();
        Log.i("list size?", ""+listEvents.size());
//        for(int i = 0; i < listEvents.size(); i++){
//            // get location
//            double lata = listEvents.get(i).getLat();
//            double longa = listEvents.get(i).getLonga();
//            Log.i("Location: ", listEvents.get(i).getLocation());
//            // mark on map
//            LatLng latlng = new LatLng(lata, longa);
//            Marker mark = mMap.addMarker(new MarkerOptions().position(latlng).title("Event: " + i).draggable(true));
//            mMap.moveCamera(CameraUpdateFactory.newLatLng(latlng));
//        }

    }
    public void readJSONFile() throws IOException, JSONException {
        FileInputStream fis = openFileInput("events");
        BufferedInputStream bis = new BufferedInputStream(fis);
        StringBuffer b = new StringBuffer();
        while (bis.available() != 0) {
            b.append((char) bis.read());
        }
        bis.close();
        fis.close();
        JSONArray data = new JSONArray(b.toString());
        for (int i = 0; i < data.length(); i++) {
            StringBuffer sb1 = new StringBuffer();
            StringBuffer sb2 = new StringBuffer();
            StringBuffer sb3 = new StringBuffer();
            // populate list entry with event info
            String location = data.getJSONObject(i).getString("location");
            sb1.append(location);
            String date = data.getJSONObject(i).getString("date");
            sb2.append(date);
            String info = data.getJSONObject(i).getString("info");
            sb3.append(info);
            double lata = data.getJSONObject(i).getDouble("lata");
            double longa = data.getJSONObject(i).getDouble("longa");
            Log.i("Got Info?", sb2.toString());
            // add to data List
            Event x = new Event(sb1.toString(), sb2.toString(), sb3.toString(), lata, longa);
            Log.i("Event x: ", x.toString());
            listEvents.add(x);
            Log.i("List size json?", "" + listEvents.size());
        }
    }
}