package com.example.project5;

public class Motion {
    private String motion;
    public Motion(String motion){
        this.motion = motion;
    }
    public String getMotion(){
        return motion;
    }
    public void setMotion(String motin){
        this.motion = motin;
    }
}
