package com.example.project5;

import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class firstFrag extends Fragment {
    View view;
    ImageView ball;
    float lastX = 0;
    float lastY = 0;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        view = inflater.inflate(R.layout.firstlayout, container, false  );
        ball = view.findViewById(R.id.redball);

        return view;
    }


    public void moveUP(float x, float y, int maxX, int maxY) {
        if(x < 0){
            ball.setX(0);
            ball.setY(3);
        }
        else {
            ball.setX(lastX);
            ball.setY(3);
        }
//        lastX = x;
        lastY = 3;
        Log.i("X: ", ""+x);
        Log.i("Y: ", ""+3);

    }

    public void moveDOWN(float x, float y, int maxX, int maxY) {
        if(x < 3){
            ball.setX(0);
            ball.setY(maxY - ball.getHeight());
        }
        else {
            ball.setX(lastX);
            ball.setY(maxY - ball.getHeight());
        }
        lastY = maxY - ball.getHeight();
        Log.i("X: ", ""+x);
        Log.i("Y: ", ""+(maxY - ball.getHeight()));
    }

    public void moveLEFT(float x, float y, int maxX, int maxY) {
        if(y < 3){
            ball.setX(0);
            ball.setY(3);
        }
        else {
            ball.setX(0);
            ball.setY(lastY);
        }
        lastX = 0;
        Log.i("X: ", ""+0);
        Log.i("Y: ", ""+y);
    }

    public void moveRIGHT(float x, float y, int maxX, int maxY) {
        if(y < 3){
            ball.setX(maxX - ball.getWidth());
            ball.setY(3);
        }
        else {
            ball.setX(maxX - ball.getWidth());
            ball.setY(lastY);
        }
        lastX = maxX - ball.getWidth();
        Log.i("X: ", ""+(maxX - ball.getWidth()));
        Log.i("Y: ", ""+y);
    }
}
