package com.example.project5;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentTransaction;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.TriggerEvent;
import android.hardware.TriggerEventListener;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.VolumeShaper;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener, GestureDetector.OnDoubleTapListener, GestureDetector.OnGestureListener{
    TextView name;
    TextView locationText;
    TextView temp;
    TextView pressure;

    private SensorManager sensorManager;
    private Sensor sensor1, sensor2;
    LocationManager locationManager;
    LocationListener locationListener;
    Context context;
    GestureDetector gestureDetector;
    private int startTouchX, startTouchY;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gestureDetector = new GestureDetector(this, this);

        ConstraintLayout constraintLayout = findViewById(R.id.SensorPlayground);
        constraintLayout.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getActionMasked();
                switch (action){
                    case MotionEvent.ACTION_DOWN:
                        startTouchX = (int) event.getX();
                        startTouchY = (int) event.getY();
                        Log.i("Touch app", "DOWN");
                        break;
                    case MotionEvent.ACTION_POINTER_DOWN:
                        Log.i("Touch app", " Pointer DOWN");
                        break;
                    case MotionEvent.ACTION_POINTER_UP:
                        Log.i("Touch app", "Pointer UP");
                        break;
                }
                return false;
            }
        });
        name = findViewById(R.id.name);
        locationText = findViewById(R.id.location);
        temp = findViewById(R.id.currentTemp);
        pressure = findViewById(R.id.airPressure);
        getSensorData();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        context = getBaseContext();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Log.i("Provider Enabled? : ", "" + locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER));
            Log.i("Location Enabled? : ", "" + locationManager.isLocationEnabled());
        } else {
            //taken care of
        }

        locationListener = new LocationListener() {
            // method to have location settings changed by user
            @Override
            public void onProviderDisabled(@NonNull String provider) {
                startActivity(new Intent(Settings.ACTION_LOCALE_SETTINGS));
            }

            @Override
            public void onLocationChanged(@NonNull Location location) {
                double lat = location.getLatitude();
                double longi = location.getLongitude();
                Geocoder g = new Geocoder(context);
                List<Address> locArray = null;
                try {
                    locArray = g.getFromLocation(lat,longi,1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String city = locArray.get(0).getLocality();
                String state = locArray.get(0).getAdminArea();
                locationText.setText("Location: " + city + ", " + state);
            }
        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.INTERNET}, 13);
            return;
        }
        else{
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 100, 0, locationListener);
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case 13:
                if(grantResults.length > 0 && grantResults[0]==PackageManager.PERMISSION_GRANTED)
                    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 100, 0, locationListener);
                break;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void getSensorData() {
        name.setText("Lucas Forbes");
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensor1 = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
        sensor2 = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);

        sensorManager.registerListener(this, sensor2, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, sensor1, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Log.i("Sensor Change", "changed");
        if(event.sensor.getType() == Sensor.TYPE_AMBIENT_TEMPERATURE){
            Log.i("got hur", "yes");
            temp.setText("Temperature: " + event.values[0] + " °C");
        }
        else if(event.sensor.getType() == Sensor.TYPE_PRESSURE){
            pressure.setText("Air Pressure: " + event.values[0] + " hPa");
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // dont need
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {
    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        //this is what where we start Gesture Playground
        Log.i("Fling occured", "true");
        startActivity(new Intent(MainActivity.this, GestureActivity.class));
        return true;
    }
}