package com.example.project5;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class secondFrag extends Fragment {
    SharedPreferences myprefs;

    SharedPreferences.Editor editor;
    public static ArrayList<Motion> myMotions = new ArrayList<>();
    View view;
    TextView motion;
    GestureActivity g = new GestureActivity();
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        view = inflater.inflate(R.layout.secondlayout, container, false);
        motion = view.findViewById(R.id.motionDescription);
        myMotions = g.data;
        String motions = "";
        for(int i=0; i < myMotions.size(); i++){
            Motion m = myMotions.get(i);
            String motion = m.getMotion();
            motions += motion;
            motions += ", ";
        }
        motion.setText(motions);
        return view;
    }
    public void addEventToLog(String motion) {
        myMotions.add(new Motion(motion));

    }

    public ArrayList<Motion> getMotions(){
        return myMotions;
    }

    public void setText(String motions) {
        motion.setText(motions);
    }
}
