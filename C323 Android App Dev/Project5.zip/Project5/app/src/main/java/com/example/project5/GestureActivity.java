package com.example.project5;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentTransaction;
import java.util.ArrayList;
import java.util.List;

import static android.view.MotionEvent.ACTION_CANCEL;
import static android.view.MotionEvent.ACTION_DOWN;
import static android.view.MotionEvent.ACTION_HOVER_ENTER;
import static android.view.MotionEvent.ACTION_HOVER_EXIT;
import static android.view.MotionEvent.ACTION_HOVER_MOVE;
import static android.view.MotionEvent.ACTION_MASK;
import static android.view.MotionEvent.ACTION_MOVE;
import static android.view.MotionEvent.ACTION_OUTSIDE;
import static android.view.MotionEvent.ACTION_POINTER_DOWN;
import static android.view.MotionEvent.ACTION_POINTER_INDEX_MASK;
import static android.view.MotionEvent.ACTION_POINTER_INDEX_SHIFT;
import static android.view.MotionEvent.ACTION_POINTER_UP;
import static android.view.MotionEvent.ACTION_SCROLL;
import static android.view.MotionEvent.ACTION_UP;

public class GestureActivity extends AppCompatActivity implements GestureDetector.OnDoubleTapListener, GestureDetector.OnGestureListener {
    SharedPreferences myprefs;
    SharedPreferences.Editor editor;
    firstFrag first;
    secondFrag second;
    TextView motionList;
    ArrayList<Motion> data = new ArrayList<>();
//    TextView motionLog;
    Context context;
    GestureDetector gestureDetector;
    int maxX;
    int maxY;
    private int startTouchX, startTouchY;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.gestureactivity);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        Configuration config = getResources().getConfiguration();

        first = new firstFrag();
        second = new secondFrag();
        fragmentTransaction.replace(R.id.frag1Frame, first);
        fragmentTransaction.replace(R.id.frag2Frame, second);
        fragmentTransaction.commit();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        maxY = displayMetrics.heightPixels / 2 - 45;
        maxX = displayMetrics.widthPixels;
        gestureDetector = new GestureDetector(this, this);
        FrameLayout constraintLayout = findViewById(R.id.frag1Frame);
        constraintLayout.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getActionMasked();
                switch (action){
                    case ACTION_DOWN:
                        startTouchX = (int) event.getX();
                        startTouchY = (int) event.getY();
                        Log.i("Touch app", "DOWN");
                        break;
                    case ACTION_POINTER_DOWN:
                        Log.i("Touch app", " Pointer DOWN");
                        break;
                    case ACTION_POINTER_UP:
                        Log.i("Touch app", "Pointer UP");
                        break;
                }
                return false;
            }
        });
//        motionLog.setText("asdkfjlasdkjflasdkjf");
    }
    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
//        // Checks the orientation of the screen
//        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
//            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
//        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
//            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
//        }
        Log.i("orientation", "changed");
        super.onConfigurationChanged(newConfig);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        if(newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            setContentView(R.layout.gestureactivity);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            maxY = displayMetrics.heightPixels / 2 - 45;
            maxX = displayMetrics.widthPixels;
            Log.i("orientation", "portrait1");
            first = new firstFrag();
            fragmentTransaction.replace(R.id.frag1Frame, first);

            second = new secondFrag();
            fragmentTransaction.replace(R.id.frag2Frame, second);
        }
        else if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE){
            setContentView(R.layout.gesturehorizon);
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            maxY = displayMetrics.heightPixels / 2 + 250;
            maxX = displayMetrics.widthPixels / 2 - 100;
            Log.i("orientation", "landscape");
            first = new firstFrag();
            fragmentTransaction.replace(R.id.frag1, first);
            second = new secondFrag();
            fragmentTransaction.replace(R.id.frag2, second);
        }
        fragmentTransaction.commit();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);
//        String action = actionToString(event.getAction());
//        data.add(new Motion(action));
//        String motions = "";
//        for(int i=0; i < data.size(); i++){
//            Motion m = data.get(i);
//            String motion = m.getMotion();
//            motions += motion;
//            motions += ", ";
//        }
//        second.setText(motions);
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        data.add(new Motion("Single Tap"));
        String motions = "";
        for(int i=0; i < data.size(); i++){
            Motion m = data.get(i);
            String motion = m.getMotion();
            motions += motion;
            motions += ", ";
        }
        second.setText(motions);
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        data.add(new Motion("Double Tap"));
        String motions = "";
        for(int i=0; i < data.size(); i++){
            Motion m = data.get(i);
            String motion = m.getMotion();
            motions += motion;
            motions += ", ";
        }
        second.setText(motions);
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent e) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent e) {

    }
    private static final int SWIPE_THRESHOLD = 100;
    private static final int SWIPE_VELOCITY_THRESHOLD = 100;
    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        boolean result = false;
        try {
            float diffY = e2.getY() - e1.getY();
            float diffX = e2.getX() - e1.getX();
            if (Math.abs(diffX) > Math.abs(diffY)) {
                if (Math.abs(diffX) > SWIPE_THRESHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_THRESHOLD) {
                    if (diffX > 0) {
                        data.add(new Motion("Swipe Right"));
                        onSwipeRight(e2.getX(), e2.getY());
                    } else {
                        data.add(new Motion("Swipe Left"));
                        onSwipeLeft(e2.getX(), e2.getY());
                    }
                    result = true;
                }
            }
            else if (Math.abs(diffY) > SWIPE_THRESHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_THRESHOLD) {
                if (diffY > 0) {
                    data.add(new Motion("Swipe Down"));
                    onSwipeBottom(e2.getX(), e2.getY());
                } else {
                    data.add(new Motion("Swipe Up"));
                    onSwipeTop(e2.getX(), e2.getY());
                }
                result = true;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        String motions = "";
        for(int i=0; i < data.size(); i++){
            Motion m = data.get(i);
            String motion = m.getMotion();
            motions += motion;
            motions += ", ";
        }
        second.setText(motions);
        return result;
    }

    private void onSwipeTop(float x, float y) {
        //move ball up
        Log.i("Swipe", "UP");
        first.moveUP(x,y,maxX,maxY);
    }

    private void onSwipeBottom(float x, float y) {
        //move ball down
        Log.i("Swipe", "DOWN");
        first.moveDOWN(x,y,maxX,maxY);
    }

    private void onSwipeLeft(float x, float y) {
        //move ball left
        Log.i("Swipe", "LEFT");
        first.moveLEFT(x,y,maxX,maxY);
    }

    private void onSwipeRight(float x, float y) {
        //move ball right
        Log.i("Swipe", "RIGHT");
        first.moveRIGHT(x,y,maxX,maxY);
    }

    public static String actionToString(int action) {
        switch (action) {
            case ACTION_DOWN:
                return "ACTION_DOWN";
            case ACTION_UP:
                return "ACTION_UP";
            case ACTION_CANCEL:
                return "ACTION_CANCEL";
            case ACTION_OUTSIDE:
                return "ACTION_OUTSIDE";
            case ACTION_MOVE:
                return "ACTION_MOVE";
            case ACTION_HOVER_MOVE:
                return "ACTION_HOVER_MOVE";
            case ACTION_SCROLL:
                return "ACTION_SCROLL";
            case ACTION_HOVER_ENTER:
                return "ACTION_HOVER_ENTER";
            case ACTION_HOVER_EXIT:
                return "ACTION_HOVER_EXIT";
        }
        int index = (action & ACTION_POINTER_INDEX_MASK) >> ACTION_POINTER_INDEX_SHIFT;
        switch (action & ACTION_MASK) {
            case ACTION_POINTER_DOWN:
                return "ACTION_POINTER_DOWN(" + index + ")";
            case ACTION_POINTER_UP:
                return "ACTION_POINTER_UP(" + index + ")";
            default:
                return Integer.toString(action);
        }
    }
}
