package com.c323proj9.ldforbes;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Item implements Comparable<Item>{

    String exp;
    String ms;
    String dat;
    String cat;
    String id;
    Date date;
    public Item(String i, String e, String m, String d, String c) throws ParseException {
        this.id = i;
        this.exp = e;
        this.ms = m;
        this.dat = d;
        this.cat = c;
        setDate();
    }

    public void setDate() throws ParseException {
        this.date = new SimpleDateFormat("MM/dd/yyyy").parse(dat);
    }

    public Date getDate(){
        return date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getExp() {
        return exp;
    }

    public void setExp(String exp) {
        this.exp = exp;
    }

    public String getMs() {
        return ms;
    }

    public void setMs(String ms) {
        this.ms = ms;
    }

    public String getDat() {
        return dat;
    }

    public void setDat(String dat) {
        this.dat = dat;
    }

    public String getCat() {
        return cat;
    }

    public void setCat(String cat) {
        this.cat = cat;
    }

    @Override
    public int compareTo(Item o) {
        return getDate().compareTo(o.getDate());
    }
}
