package com.c323proj9.ldforbes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder>{
    private List<Item> ItemList;
    private ClickListener<Item> clickListener;
    private AdapterView.OnItemClickListener mListener;
    RecyclerViewAdapter(List<Item> ItemList){
        this.ItemList = ItemList;
    }
    @Override
    public RecyclerViewAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_adapter_layout,parent,false);
        return new MyViewHolder(view);
    }
    @Override
    public void onBindViewHolder(RecyclerViewAdapter.MyViewHolder holder, final int position) {
        final Item item = ItemList.get(position);
        holder.title.setText(item.getExp());
        holder.moneySpentTitle.setText("$"+item.getMs());
        holder.datetitle.setText(item.getDat());
        holder.categoryTitle.setText(item.getCat());
        if(item.getCat().compareTo("Grocery") == 0){
            holder.image.setImageResource(R.mipmap.grocery);
        }
        else if(item.getCat().compareTo("Gas") == 0){
            holder.image.setImageResource(R.mipmap.gas);
        }
        else if(item.getCat().compareTo("Shopping") == 0){
            holder.image.setImageResource(R.mipmap.shopping);
        }else{
            holder.image.setImageResource(R.mipmap.misc);
        }
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("clicked on item: " + position);
                clickListener.onDeleteClick(position);
            }
        });
    }
    @Override
    public int getItemCount() {
        return ItemList.size();
    }
    public void setOnItemClickListener(ClickListener<Item> movieClickListener) {
        this.clickListener = movieClickListener;
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public ImageView image;
        public CardView cardView;
        public TextView moneySpentTitle;
        public TextView categoryTitle;
        public TextView datetitle;
        public ImageView editButton;
        public ImageView deleteButton;
        public MyViewHolder(final View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title);
            image = itemView.findViewById(R.id.image);
            cardView = itemView.findViewById(R.id.carView);
            moneySpentTitle = itemView.findViewById(R.id.moneySpentTitle);
            categoryTitle = itemView.findViewById(R.id.categoryTitle);
            datetitle = itemView.findViewById(R.id.dateTitle);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
interface ClickListener<T> {
    void onItemClick(T data);
    void onDeleteClick(int position);
}
//interface OnItemClickListener{
//    void onDeleteClick(int position);
//}