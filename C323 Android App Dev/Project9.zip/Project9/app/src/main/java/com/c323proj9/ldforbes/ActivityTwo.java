package com.c323proj9.ldforbes;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class ActivityTwo extends AppCompatActivity {
    Spinner dropDown;
    String itemvalue;
    List<Item> newList;
    SQLiteDatabase database = null;
    private RecyclerView recyclerView;
    private RecyclerViewAdapter recyclerViewAdapter;
    public List<Item> itemList;
    public List<Item> sortedItemList;
    int first;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.expenselog);
        dropDown = (Spinner) findViewById(R.id.spinner);
        List<String> l = new ArrayList<>();
        first = 0;
        l.add("Grocery");
        l.add("Gas");
        l.add("Shopping");
        l.add("Miscellaneous");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, l);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dropDown.setAdapter(adapter);
        dropDown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                itemvalue = parent.getItemAtPosition(position).toString();
                Toast.makeText(ActivityTwo.this, "selected: " + itemvalue, Toast.LENGTH_LONG);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        itemList = new ArrayList<>();
        getItems();
        sortItems();
        addItemstoCards(itemList);
    }

    private void sortItems() {
        Collections.sort(itemList);
    }

    public void removeItem(int position){
        System.out.println("removing Item: " + position);
        Item x = itemList.get(position);
        String id = x.getId();
        int prevSize = itemList.size();
        itemList.remove(position);
        updateDB(id);
        recyclerViewAdapter.notifyItemRangeRemoved(0, prevSize);
        recyclerViewAdapter.notifyItemRangeInserted(0, itemList.size());
        recyclerViewAdapter.notifyItemChanged(position);
    }

    private void updateDB(String id) {
        System.out.println("ID = " + id);
        try{
            database.execSQL("DELETE FROM itemsTable WHERE id = "+id+";");
        }catch(IndexOutOfBoundsException e){
            Toast.makeText(this, "Item deleted from DB", Toast.LENGTH_SHORT);
            Log.i("Index out of bounds", ""+e);
        }

    }

    private void getItems() {
        // bring in items from db
//        itemList.add(new Item("food","1234", "12/12/12", "0"));
//        itemList.add(new Item("food","1234", "12/12/12", "1"));
        try{
            database = this.openOrCreateDatabase("itemDB", MODE_PRIVATE, null);
            File db = getApplicationContext().getDatabasePath("itemDB.db");
            System.out.println(db);
            if(!db.exists()){
                Toast.makeText(this, "Database Exists", Toast.LENGTH_LONG).show();
                //call add db contents to arraylist
                Cursor cursor = database.rawQuery("SELECT * from itemsTable", null);
                int indexColumn_id = cursor.getColumnIndex("id");
                int indexColumn_expense = cursor.getColumnIndex("expense");
                int indexColumn_moneySpent = cursor.getColumnIndex("moneySpent");
                int indexColumn_date = cursor.getColumnIndex("date");
                int indexColumn_category = cursor.getColumnIndex("category");
                cursor.moveToFirst();
//                String idList = "";
//                StringBuffer itemList = new StringBuffer();
                if(cursor != null && cursor.getCount()>0){
                    do{
                        String id = cursor.getString(indexColumn_id);
                        String expense = cursor.getString(indexColumn_expense);
                        String moneySpent = cursor.getString(indexColumn_moneySpent);
                        String date = cursor.getString(indexColumn_date);
                        String category = cursor.getString(indexColumn_category);
                        // add new instance to arraylist
                        itemList.add(new Item(id, expense, moneySpent, date, category));
                    }while(cursor.moveToNext());
                }
            }
            else{
                Toast.makeText(this, "DataBase Doesn't Exist", Toast.LENGTH_LONG).show();
            }
        }catch (SQLException | ParseException e){
            Log.v("DB_ERROR", "ERRPOR");
        }

    }

    private void addItemstoCards(List<Item> iList) {
        recyclerView = (RecyclerView)findViewById(R.id.recyclerView);
        recyclerViewAdapter = new RecyclerViewAdapter(iList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerViewAdapter.setOnItemClickListener(new ClickListener<Item>(){
            @Override
            public void onItemClick(Item data) {
                Toast.makeText(ActivityTwo.this, data.getExp(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onDeleteClick(int position) {
                removeItem(position);
            }
        });

        recyclerView.setAdapter(recyclerViewAdapter);
    }

    public void FilterList(View view) {
        if(first != 0){
            itemList.clear();
            itemList.addAll(newList);
            recyclerViewAdapter.notifyDataSetChanged();
        }
        EditText filt = findViewById(R.id.keywordSearch);
        String search = filt.getText().toString();
        System.out.println("searching with: " + search + ", " + itemvalue);
        if(search.length() == 0){
            if(itemvalue == null){
                Toast.makeText(ActivityTwo.this, "No Search Criteria", Toast.LENGTH_SHORT).show();
            }
            else{
                searchListWith(itemvalue, "");
            }
        }
        else{
            searchListWith(itemvalue, search);
        }

    }

    private void searchListWith(String itemvalue, String crit){
        recyclerViewAdapter.notifyDataSetChanged();
        newList = new ArrayList<Item>(itemList);
        List<Item> filtList = new ArrayList<>();
        System.out.println("Beginning List Size " + newList.size());
        for(int i = 0; i<itemList.size(); i++){
            Item x = itemList.get(i);
            String exp = x.getExp();
            String ms = x.getMs();
            String date = x.getDat();
            String cat = x.getCat();
            if(exp.compareTo(crit) == 0 || ms.compareTo(crit) == 0 || date.compareTo(crit) == 0 || cat.compareTo(crit) == 0 || cat.compareTo(itemvalue) == 0){
                filtList.add(x);
//                itemList.remove(x);
            }
        }
        System.out.println("Items going to be shown:" + filtList.size());
//        recyclerViewAdapter.notifyItemRangeRemoved(0, newList.size());
//        recyclerViewAdapter.notifyItemRangeInserted(0, itemList.size());
        itemList.clear();
        itemList.addAll(filtList);
        recyclerViewAdapter.notifyDataSetChanged();
        first += 1;
        System.out.println("Itemlist back to :" + itemList.size());
    }
}
