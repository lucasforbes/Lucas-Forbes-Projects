package com.c323proj9.ldforbes;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.File;
import java.lang.reflect.Array;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@RequiresApi(api = Build.VERSION_CODES.O)
public class MainActivity extends AppCompatActivity {
    Spinner dropDown;
    EditText expense;
    EditText moneySpent;
    EditText date;
    String itemvalue;
    SQLiteDatabase database = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView pp = findViewById(R.id.profilePic);
        pp.setImageResource(R.mipmap.man);
        expense = findViewById(R.id.expenseEnter);
        moneySpent = findViewById(R.id.moneyEnter);
        date = findViewById(R.id.dateEnter);
        dropDown = (Spinner) findViewById(R.id.dropDown);
        List<String> l = new ArrayList<>();
        l.add("Grocery");
        l.add("Gas");
        l.add("Shopping");
        l.add("Miscellaneous");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, l);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dropDown.setAdapter(adapter);
        dropDown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                itemvalue = parent.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity.this, "selected: " + itemvalue, Toast.LENGTH_LONG);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        createDB();
    }

    public void addToDB(View view) {
        // add to sqlite database
        String exp = expense.getText().toString();
        String ms = moneySpent.getText().toString();
        String dat = date.getText().toString();
        String cat = itemvalue;
        if(exp.length() != 0 && ms.length() != 0 && dat.length() != 0 && cat != null){
            if(isValidFormat("MM/dd/yyy", dat, Locale.US)){

                //save
                database.execSQL("INSERT INTO itemsTable (expense, moneySpent, date, category) VALUES('"+exp + "','"+ms+"','"+dat+"','"+cat+"');");
                Toast.makeText(MainActivity.this, "Saving: " + exp + ", " + ms + ", " + dat + ", " + cat, Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(MainActivity.this, "Date Format Incorrect, Use MM/DD/YYYY", Toast.LENGTH_LONG).show();
            }
        }
        else{

            Toast.makeText(MainActivity.this, "One or more fields left blank, Can't Save", Toast.LENGTH_LONG).show();
        }

    }

    public void goToActivity2(View view) {
        Intent intent = new Intent(MainActivity.this, ActivityTwo.class);
        startActivity(intent);

    }
    public void createDB(){
        try{
            database = this.openOrCreateDatabase("itemDB", MODE_PRIVATE, null);
            database.execSQL("CREATE TABLE IF NOT EXISTS itemsTable "+"(id integer primary key, expense VARCHAR, moneySpent VARCHAR, date VARCHAR, category TEXT);");
            File db = getApplicationContext().getDatabasePath("itemDB.db");
            if(!db.exists()){
                Toast.makeText(this, "Database Created", Toast.LENGTH_LONG).show();
            }
            else{
                Toast.makeText(this, "DataBase Doesn't Exist", Toast.LENGTH_LONG).show();
            }
        }catch (SQLException e){
            Log.v("DB_ERROR", "ERRPOR");
        }
    }
    public static boolean isValidFormat(String format, String value, Locale locale) {
        LocalDateTime ldt = null;
        DateTimeFormatter fomatter = DateTimeFormatter.ofPattern(format, locale);

        try {
            ldt = LocalDateTime.parse(value, fomatter);
            String result = ldt.format(fomatter);
            return result.equals(value);
        } catch (DateTimeParseException e) {
            try {
                LocalDate ld = LocalDate.parse(value, fomatter);
                String result = ld.format(fomatter);
                return result.equals(value);
            } catch (DateTimeParseException exp) {
                try {
                    LocalTime lt = LocalTime.parse(value, fomatter);
                    String result = lt.format(fomatter);
                    return result.equals(value);
                } catch (DateTimeParseException e2) {
                    // Debugging purposes
                    //e2.printStackTrace();
                }
            }
        }

        return false;
    }
}