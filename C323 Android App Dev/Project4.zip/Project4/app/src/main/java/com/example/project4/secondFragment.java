package com.example.project4;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class secondFragment extends Fragment{
    View view;

    String sound;
    String battery;
    String storage;
    String display;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return super.onCreateView(inflater, container, savedInstanceState);
        view = inflater.inflate(R.layout.second_layout, container, false);

        return view;
    }

    public String getMessage(int i) {
        String message = "";
        switch (i){
            case 0:
                message = "Sound: 75%";
                break;
            case 1:
                message = "Storage: 32% Capacity";
                break;
            case 2:

                message = "Display: ";
                break;
            case 3:
                message = "Battery: 88% full";
                break;
        }
        return message;
    }
}
