package com.example.project4;

import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


public class firstFragment extends Fragment {
    View view;
    EditText text;
    EditText location;
    FirstFragInfo firstFragInfo = new FirstFragInfo("", "", R.mipmap.person);
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        return super.onCreateView(inflater, container, savedInstanceState);
        view = inflater.inflate(R.layout.first_layout, container, false);
        text = view.findViewById(R.id.name);
        location = view.findViewById(R.id.Location);
        //set first frag info for shared prefs
        try {
            text.setText(MainActivity.info.getName());
            Log.i("got hur", "yes");
            location.setText(MainActivity.info.getLocation());
            Log.i("location Landscape", MainActivity.info.getLocation());
            firstFragInfo = new FirstFragInfo(MainActivity.info.getName().toString(), MainActivity.info.getLocation().toString(), R.mipmap.person);

        }
        catch (Exception e){
            return view;
        }

        return view;

    }
    public void setEditable(Boolean x){
        if(x == false){
            text.setEnabled(false);
            location.setEnabled(false);
            String locate = location.getText().toString();
            String name = text.getText().toString();
            Log.i("name:", name);
            Log.i("location:", locate);
            firstFragInfo.setName(name);
            firstFragInfo.setLocation(locate);
        }
        else{
            text.setEnabled(true);
            location.setEnabled(true);
        }
    }
}
