package com.example.project4;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {
    firstFragment first;
    secondFragment second;
    TextView settingsmessage;
    int orientation;
    int setting;
    static FirstFragInfo info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();

        Configuration config = getResources().getConfiguration();
        Log.i("orientation", "portrait");
        first = new firstFragment();
        fragmentTransaction.replace(R.id.frameLayout, first);

        second = new secondFragment();
        fragmentTransaction.replace(R.id.linearLayoutMain, second);
        orientation = 0;

        fragmentTransaction.commit();
        settingsmessage = findViewById(R.id.settingsMessage1);
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
//        // Checks the orientation of the screen
//        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
//            Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
//        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
//            Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
//        }
        super.onConfigurationChanged(newConfig);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        if(newConfig.orientation == Configuration.ORIENTATION_PORTRAIT){
            setContentView(R.layout.activity_main);
            Log.i("orientation", "portrait1");
            first = new firstFragment();
            fragmentTransaction.replace(R.id.frameLayout, first);

            second = new secondFragment();
            fragmentTransaction.replace(R.id.linearLayoutMain, second);
            orientation = 0;
        }
        else if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE){
            setContentView(R.layout.landscape);
            Log.i("orientation", "landscape");
            first = new firstFragment();
            fragmentTransaction.replace(R.id.personInfo, first);
            second = new secondFragment();
            fragmentTransaction.replace(R.id.settings, second);
            orientation = 1;
            settingsmessage = findViewById(R.id.settingsMessage1);
        }
        fragmentTransaction.commit();
    }

//    @Override
//    protected void onSaveInstanceState(@NonNull Bundle outState) {
//        super.onSaveInstanceState(outState);
//        outState.putCharSequence("name", info.getName());
//        outState.putCharSequence("location", info.getLocation());
//        outState.putInt("picture", info.getImage());
//    }
//
//    @Override
//    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
//        super.onRestoreInstanceState(savedInstanceState);
//        info.setImage(R.mipmap.person);
//        info.setLocation(savedInstanceState.getString("location"));
//        info.setName(savedInstanceState.getString("name"));
//    }

    public void editTextFalse(View view) {
        // set frag 1 editText to uneditable
        first.setEditable(false);
        info = first.firstFragInfo;
        Log.i("editable:", "false");
    }

    public void editTextTrue(View view) {
        // set frag 1 editText to editable
        first.setEditable(true);
        info = first.firstFragInfo;
        Log.i("editable:", "true");
    }

    public void soundSetting(View view) {
        setting = 3;
        String m = second.getMessage(0);
        settingsmessage.setText(m);
    }

    public void storageSetting(View view) {
        setting = 1;
        String m = second.getMessage(1);
        settingsmessage.setText(m);
    }

    public void displaySetting(View view) {
        setting = 2;
        String m = second.getMessage(2);
        if (orientation == 0){
            m = m + "portrait";
        }
        else{
            m = m + "landscape";
        }
        settingsmessage.setText(m);
    }

    public void batterySetting(View view) {
        setting = 0;
        String m = second.getMessage(3);
        settingsmessage.setText(m);
    }

    public void next(View view) {
        setting += 1;
        if(setting == 4){
            setting = 0;
        }
        String message = "";
        switch (setting){
            case 3:
                message = "Sound: 75%";
                break;
            case 1:
                message = "Storage: 32% Capacity";
                break;
            case 2:
                message = "Display: ";
                if (orientation == 0){
                    message = message + "portrait";
                }
                else{
                    message = message + "landscape";
                }
                break;
            case 0:
                message = "Battery: 88% full";
                break;
        }
        settingsmessage.setText(message);
    }
}