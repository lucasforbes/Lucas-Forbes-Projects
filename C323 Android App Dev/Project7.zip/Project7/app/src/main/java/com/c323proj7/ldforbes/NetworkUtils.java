package com.c323proj7.ldforbes;

import android.util.Log;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class NetworkUtils {
    public static ArrayList<Movie> fetchData(String url) throws IOException {
        ArrayList<Movie> movies = new ArrayList<Movie>();
        ArrayList<Movie> movies2 = new ArrayList<Movie>();
        try {
            URL new_url = new URL(url); //create a url from a String
            HttpURLConnection connection = (HttpURLConnection) new_url.openConnection(); //Opening a http connection  to the remote object
            connection.setReadTimeout(3000);
            connection.setConnectTimeout(3000);
            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            connection.connect();
            int responceCode = connection.getResponseCode();
            if (responceCode != HttpURLConnection.HTTP_OK){
                throw new IOException("Http error code: "+responceCode);
            }
            InputStream inputStream = connection.getInputStream(); //reading from the object
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
            StringBuffer result  = new StringBuffer();
            String content = "";
            while ((content = bufferedReader.readLine()) != null){
                result.append(content);
                Log.i("result", result.toString());
                Log.i("Content", "!!!!!!!!");
            }
            parseJson(result.toString(),movies);
            inputStream.close();
            return movies;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return movies;
    }
    public static void parseJson(String data, ArrayList<Movie> list){

        try {
            JSONObject mainObject = new JSONObject(data);

            JSONArray resArray = mainObject.getJSONArray("results"); //Getting the results object
            for (int i = 0; i < 5; i++) {
                JSONObject jsonObject = resArray.getJSONObject(i);
                Movie movie = new Movie(); //New Movie object
                movie.setId(jsonObject.getInt("id"));
                movie.setVoteAverage(jsonObject.getInt("vote_average"));
                movie.setVoteCount(jsonObject.getInt("vote_count"));
                movie.setOriginalTitle(jsonObject.getString("original_title"));
                movie.setTitle(jsonObject.getString("title"));
                movie.setPopularity(jsonObject.getDouble("popularity"));
                movie.setBackdropPath(jsonObject.getString("backdrop_path"));
                movie.setOverview(jsonObject.getString("overview"));
                movie.setReleaseDate(jsonObject.getString("release_date"));
                movie.setPosterPath(jsonObject.getString("poster_path"));
//                if enough time get genres
                JSONArray genres_list_array;
                List<Integer> genreIDs = new ArrayList<Integer>();
                genres_list_array = jsonObject.getJSONArray("genre_ids");
                for (int j = 0; j < genres_list_array.length(); j++) {
                    System.out.println("Genre IDs = "+genres_list_array.get(j));
                    genreIDs.add(genres_list_array.getInt(j));
                }
                movie.setGenreIDs(genreIDs);
                list.add(movie);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Log.i("Error in parsing JSON", e.toString());
        }

    }
}
