package com.c323proj7.ldforbes;

import android.os.AsyncTask;
import android.os.NetworkOnMainThreadException;

import org.json.JSONArray;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FetchMovies extends AsyncTask<Void,Void,Void> {
    List mPopularList = new ArrayList<>();
    List mTopTopRatedList = new ArrayList<>();
    String myApiKey = "93853a958bbafde2aa059be135898817";
    int temp = 0;
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
//        mProgressBar.setVisibility(View.VISIBLE);
    }

    @Override
    protected Void doInBackground(Void... voids) {
        String popularMoviesURL = "https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key="+myApiKey;

//        mPopularList = new ArrayList<>();
        mPopularList = download(popularMoviesURL);
        temp = 1;
        return null;
    }

    public List<Movie> download(String popularMoviesURL) {
        try {
            System.out.println("Got Here");
            NetworkUtils net = new NetworkUtils();
            mPopularList = net.fetchData(popularMoviesURL); //Get popular movies
            System.out.println("MpopularList size"+ mPopularList.size());
            mTopTopRatedList = mPopularList;
            temp = 1;
            return mTopTopRatedList;
        } catch (IOException e){
            temp = 0;
            e.printStackTrace();
        }
        return null;
    }

    public List<Movie> getMovies() throws IOException {
//        if(temp != 0){
            NetworkUtils net = new NetworkUtils();

           // mPopularList = net.fetchData("https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key="+myApiKey);
            System.out.println("Get Movies size"+ mPopularList.size());
            return mPopularList;
//        }
       // return null;
    }
    @Override
    protected void onPostExecute(Void  s) {
        temp = 1;
        super.onPostExecute(s);
    //        mProgressBar.setVisibility(View.INVISIBLE);
        //set global array?
    }

}