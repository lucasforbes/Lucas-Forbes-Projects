package com.c323proj7.ldforbes;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class setMovieInfo extends AppCompatActivity {
    Context context;
    Map<Integer,String> dic1 = new HashMap<Integer,String>();
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_info);
        context = getBaseContext();
        String title = getIntent().getStringExtra("title");
        String language = "English";
        String popularity = getIntent().getStringExtra("popularity");
        String releaseDate = getIntent().getStringExtra("releaseDate");
        String description = getIntent().getStringExtra("description");
        String picURL = getIntent().getStringExtra("picURL");
        TextView titl = findViewById(R.id.movieTitle);
        TextView lang = findViewById(R.id.Language);
        TextView pop = findViewById(R.id.Popularity);
        TextView rd = findViewById(R.id.ReleaseDate);
        TextView desc = findViewById(R.id.Description);
        ImageView movieImage = findViewById(R.id.movieImage);
        titl.setText("Title: " + title);
        lang.setText("Language: " + language);
        pop.setText("Popularity Scale: " + popularity);
        rd.setText("Release Date: " + releaseDate);
        desc.setText("Description: " + description);
        setImage(picURL);
        FetchGenres fetch = new FetchGenres();
        fetch.execute();
        while(fetch.temp != 1){
//            wait
            System.out.println("Stuck in loop");
        }
        dic1 = fetch.dic;
        fetch.temp = 0;
        String genres = "";
        List<Integer> listIDs = getIntent().getIntegerArrayListExtra("ids");
        for(int i = 0; i < listIDs.size(); i++){
            int id = listIDs.get(i);
            genres += dic1.get(id);
            genres += ", ";
        }
        pop.setText("Genres are: " + genres);
        System.out.println("Dic contents"+ dic1.entrySet());
        //If enough time set genres
//        https://api.themoviedb.org/3/genre/movie/list?api_key=93853a958bbafde2aa059be135898817&language=en-US
    }

    private void setImage(String picURL) {
        context = getBaseContext();
        ImageView movieImage = findViewById(R.id.movieImage);
        System.out.println(picURL);
        Picasso.with(context).load(picURL).fit().into(movieImage);
    }
// Make api call for mapping
private static class FetchGenres extends AsyncTask<Void,Void,Void> {
    Map<Integer,String> dic = new HashMap<Integer,String>();
    int temp = 0;
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
//        mProgressBar.setVisibility(View.VISIBLE);
    }

    @Override
    protected Void doInBackground(Void... voids) {
        String genresURL = "https://api.themoviedb.org/3/genre/movie/list?api_key=93853a958bbafde2aa059be135898817&language=en-US";
        download(genresURL);
        return null;
    }

    public void download(String url) {
        try {
            URL new_url = new URL(url); //create a url from a String
            HttpURLConnection connection = (HttpURLConnection) new_url.openConnection(); //Opening a http connection  to the remote object
            connection.setReadTimeout(3000);
            connection.setConnectTimeout(3000);
            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            connection.connect();
            int responceCode = connection.getResponseCode();
            if (responceCode != HttpURLConnection.HTTP_OK) {
                throw new IOException("Http error code: " + responceCode);
            }
            InputStream inputStream = connection.getInputStream(); //reading from the object
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
            StringBuffer result = new StringBuffer();
            String content = "";
            while ((content = bufferedReader.readLine()) != null) {
                result.append(content);
                Log.i("result", result.toString());
                Log.i("Content", "!!!!!!!!");
            }
            parseJson(result.toString());
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onPostExecute(Void s) {
        System.out.println("Executed");
        super.onPostExecute(s);
    }

    public void parseJson(String data) {
        try {
            JSONObject mainObject = new JSONObject(data);
            JSONArray resArray = mainObject.getJSONArray("genres"); //Getting the results object
            for (int i = 0; i < resArray.length(); i++) {
                JSONObject jsonObject = resArray.getJSONObject(i);
                System.out.println("Json obje = " + jsonObject.toString());
                int id = jsonObject.getInt("id");
                System.out.println("int obje"+id);
                String gen = jsonObject.getString("name");
                dic.put(id,gen);
            }
            System.out.println("what are the jawns"+ dic.size());
            temp = 1;
        } catch (JSONException e) {
            e.printStackTrace();
            Log.i("Error in parsing JSON", e.toString());
        }

    }
}}
