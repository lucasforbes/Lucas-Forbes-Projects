package com.c323proj7.ldforbes;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

class Weather extends AsyncTask<String,Void,String>{
    @Override
    protected String doInBackground(String... address) {
        //String... means multiple address can be send. It acts as array
        StringBuffer result  = new StringBuffer();
        try {
            URL url = new URL(address[0]);
            Log.i("Adress", address[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setReadTimeout(3000);
            connection.setConnectTimeout(3000);
            connection.setRequestMethod("GET");
            connection.setDoInput(true);
            //Establish connection with address
            connection.connect();
            int responceCode = connection.getResponseCode();
            if (responceCode != HttpURLConnection.HTTP_OK){
                throw new IOException("Http error code: "+responceCode);
            }
            //retrieve data from url
            InputStream is = connection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String content = "";
            while ((content = bufferedReader.readLine()) != null){
                result.append(content);
                Log.i("result", result.toString());
                Log.i("Content", "!!!!!!!!");
            }
            return result.toString();

        } catch (ProtocolException e) {
            e.printStackTrace();
        }  catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}