package com.c323proj7.ldforbes;

import android.content.Context;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MovieAdapter extends AppCompatActivity {
    private Context mContext;
    ArrayList<Movie> list;
    public MovieAdapter(Context context, ArrayList<Movie> movieList) {
        this.mContext = context;
        this.list = movieList;
    }
}
