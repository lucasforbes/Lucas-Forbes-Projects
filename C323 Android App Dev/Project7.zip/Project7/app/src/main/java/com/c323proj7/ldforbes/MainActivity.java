package com.c323proj7.ldforbes;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.squareup.picasso.Picasso;
//import com.wca.android.cinema.R;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static java.lang.Math.round;

public class MainActivity extends AppCompatActivity{
    LocationManager locationManager;
    LocationListener locationListener;
    String currentCity = "Bloomington";
    String currentState = "IN";
    String tdWeather;
    String weatherDescript;
    String temp;
    String feelsLike;
    List mPopularList = new ArrayList<>();
    JSONObject data;
    double lata = 0;
    double longa = 0;
    Context context;
    ProgressDialog progressDialog;
    FrameLayout Frame;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Frame = findViewById(R.id.Frame);
        context = getBaseContext();
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ConstraintLayout myView = (ConstraintLayout) inflater.inflate(R.layout.weather, null);
        Frame.addView(myView);
        Button b1 = myView.findViewById(R.id.getCurrentWeatherData);
        Button b2 = myView.findViewById(R.id.getEnteredWeather);
        Button b3 = myView.findViewById(R.id.movieListButton);
        b1.setOnClickListener(new View.OnClickListener(){
            @Override public void onClick(View v) {
                try {
                    getCurrentWeather1(v);
                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener(){
            @Override public void onClick(View v) {
                    getEnteredWeather(v);
            }
        });
        b3.setOnClickListener(new View.OnClickListener(){
            @Override public void onClick(View v) {
                try {
                    goToMovieList(v);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Log.i("Provider Enabled? : ", "" + locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER));
            Log.i("Location Enabled? : ", "" + locationManager.isLocationEnabled());
        } else {
            //taken care of
        }
        locationListener = new LocationListener() {
            // method to have location settings changed by user
            @Override
            public void onProviderDisabled(@NonNull String provider) {
                startActivity(new Intent(Settings.ACTION_LOCALE_SETTINGS));
            }

            @Override
            public void onLocationChanged(@NonNull Location location) {
                double lat = location.getLatitude();
                double longi = location.getLongitude();
                lata = lat;
                longa = longi;
                Log.i("any change?", "yes");

                Geocoder g = new Geocoder(MainActivity.this);
                List<Address> locArray = null;
                try {
                    locArray = g.getFromLocation(lat, longi, 1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String city = locArray.get(0).getLocality();
                String state = locArray.get(0).getAdminArea();
                currentCity = city;
                currentState = state;
                try {
                    setWeatherPage();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Log.i("City changed?", currentCity);
            }
        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.INTERNET}, 13);
            return;
        } else {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
            //locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, locationListener);
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, locationListener);
        try {
            setWeatherPage();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void setWeatherPage() throws ExecutionException, InterruptedException, JSONException {
        EditText location = findViewById(R.id.location);
        TextView todaysWeather = findViewById(R.id.todaysWeather);
        TextView description1 = findViewById(R.id.weatherDescription);
        TextView temperature1 = findViewById(R.id.temperature);
        TextView feelsLike = findViewById(R.id.feelsLike);
        Button getWeatherData = findViewById(R.id.getCurrentWeatherData);
        Button toMovieList = findViewById(R.id.movieListButton);
        try{
            location.setHint("Location: " + round(longa) + ", " + round(lata) + ", " + currentCity + ", " + currentState);
        }catch (Exception e){
            Toast.makeText(this, "Location not availble yet. Try again soon",Toast.LENGTH_LONG);
        }
    }
    public void weatherHelper() throws Exception {
        EditText location = findViewById(R.id.location);
        TextView todaysWeather = findViewById(R.id.todaysWeather);
        TextView description1 = findViewById(R.id.weatherDescription);
        TextView temperature1 = findViewById(R.id.temperature);
        TextView feelsLike = findViewById(R.id.feelsLike);
        Button getWeatherData = findViewById(R.id.getCurrentWeatherData);
        Button toMovieList = findViewById(R.id.movieListButton);
        ImageView weatherImage = findViewById(R.id.weatherImage);
        location.setHint("Location: " + round(longa) + ", " + round(lata) + ", " + currentCity + ", " + currentState);
        Weather weather = new Weather();

        String content = weather.execute("https://api.openweathermap.org/data/2.5/weather?q="+currentCity+"&units=imperial&APPID=0f372f75c9a6bcf95b6e7768bdbe9852").get();
//Log the data
        JSONObject job = null;
        try{
            Log.i("contentData",content);
            job = new JSONObject(content);
        }catch (Exception e){
            throw new Exception(e);
        }

        try{
            String todayWet = job.getString("weather");
            JSONArray array = new JSONArray(todayWet);
            String main = "";
            String description = "";
            String iconCode = "";
            for(int i=0; i<array.length(); i++){
                JSONObject weatherPart = array.getJSONObject(i);
                main = weatherPart.getString("main");
                description = weatherPart.getString("description");
                iconCode = weatherPart.getString("icon");
            }
            String todayTemp = job.getString("main");
            JSONObject boj = new JSONObject(todayTemp);
            String temp = boj.getString("temp");
            String feels = boj.getString("feels_like");
            System.out.println(feels);
            todaysWeather.setText("The Weather today is "+main);
            description1.setText("It will be "+description);
            temperature1.setText("The Temperature is "+temp);
            feelsLike.setText("But it feels like "+feels);
            System.out.println("Image is: "+ iconCode);
            String iconUrl = "https://openweathermap.org/img/w/" + iconCode + ".png";
            System.out.println("Image URL is: "+ iconUrl);
            Picasso.with(context).load(iconUrl).fit().into(weatherImage);
        } catch (Exception e) {
            Log.i("Exception", ":aer");
            e.printStackTrace();
            Log.i("Exception", ":aer");
        }

    }
    private static JSONObject getObject(String tagName, JSONObject jObj) throws JSONException {
        JSONObject subObj = jObj.getJSONObject(tagName);
        return subObj;
    }
    private static String getString(String tagName, JSONObject jObj) throws JSONException {
        return jObj.getString(tagName);
    }
    private static float getFloat(String tagName, JSONObject jObj) throws JSONException {
        return (float) jObj.getDouble(tagName);
    }

    private static int getInt(String tagName, JSONObject jObj) throws JSONException {
        return jObj.getInt(tagName);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
//        return super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        ConstraintLayout CL = findViewById(R.id.CL);
        int id = item.getItemId();
        switch (id){
            case R.id.action_weather:
                if(item.isCheckable()){
                    item.setChecked(false);
                    // set layout to weather activity
                    Context context = getBaseContext();
                    LayoutInflater inflater = (LayoutInflater) context
                            .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    ConstraintLayout myView = (ConstraintLayout) inflater.inflate(R.layout.weather, null);
                    Frame.removeAllViews();
                    Frame.addView(myView);
                    EditText location = findViewById(R.id.location);
                    location.setHint("Location: " + round(longa) + ", " + round(lata) + ", " + currentCity + ", " + currentState);
                }else{
                    item.setChecked(true);
                }
                return true;
            case R.id.action_movie:
                if(item.isCheckable()){
                    item.setChecked(false);
                    // set layout to movie activity
                    Context context = getBaseContext();
                    LayoutInflater inflater = (LayoutInflater) context
                            .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    ConstraintLayout myView = (ConstraintLayout) inflater.inflate(R.layout.movies, null);
                    Frame.removeAllViews();
                    Frame.addView(myView);
                    progressDialog = ProgressDialog.show(this, "Movies", "Connecting, please wait...", true, true);
                    ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                    NetworkInfo networkInfo = cm.getActiveNetworkInfo();
                    List<Movie> mvs = new ArrayList<Movie>();
                    FetchMovies movs = new FetchMovies();
                    if (networkInfo != null && networkInfo.isConnected()){
                        //create new task in seperate thread
                        System.out.println("Inside if");
                        movs.execute();
                        while(movs.temp != 1){
                            //nothing
                        }
                        mPopularList = movs.mPopularList;
                    }else{
                        Toast.makeText(this, "Network not available", Toast.LENGTH_LONG);
                    }
                    try{
                        System.out.println("Main list size" + mPopularList.size());
                        Movie firstMov = (Movie) mPopularList.get(0);
                        Log.i("First Movie in List", firstMov.getOriginalTitle());
                        setListAdapter();
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    progressDialog.dismiss();
                }else{
                    item.setChecked(true);
                }
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void getEnteredWeather(View view) {
        EditText editText = findViewById(R.id.location);
        try{
            currentCity = editText.getText().toString();
            weatherHelper();
        } catch (JSONException e) {
            Toast.makeText(this, "Enter a Valid City Name", Toast.LENGTH_LONG);
            e.printStackTrace();

        } catch (InterruptedException e) {
            Toast.makeText(this, "Enter a Valid City Name", Toast.LENGTH_LONG);
            e.printStackTrace();

        } catch (ExecutionException e) {
            Toast.makeText(this, "Enter a Valid City Name", Toast.LENGTH_LONG);
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void goToMovieList(View view) throws IOException {
        Context context = getBaseContext();
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ConstraintLayout myView = (ConstraintLayout) inflater.inflate(R.layout.movies, null);
        Frame.removeAllViews();
        Frame.addView(myView);
        progressDialog = ProgressDialog.show(this, "Movies", "Connecting, please wait...", true, true);

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        List<Movie> mvs = new ArrayList<Movie>();
        FetchMovies movs = new FetchMovies();
        if (networkInfo != null && networkInfo.isConnected()){
            //create new task in seperate thread
            System.out.println("Inside if");
            movs.execute();
           while(movs.temp != 1){
               //nothing
           }
           mPopularList = movs.mPopularList;
        }else{
            Toast.makeText(this, "Network not available", Toast.LENGTH_LONG);
        }
        try{
            System.out.println("Main list size" + mPopularList.size());
            Movie firstMov = (Movie) mPopularList.get(0);
            Log.i("First Movie in List", firstMov.getOriginalTitle());
            setListAdapter();
        }catch (Exception e){
            e.printStackTrace();
        }
        progressDialog.dismiss();


    }

    private void setListAdapter() {
        ArrayAdapter<Movie> myAdapter = new MyCustomListAdapter(getApplicationContext(), mPopularList);
//        Log.i("setAdapter?", "yes");
        // Configure ListView to attach my adapter
        ListView listView = (ListView) findViewById(R.id.listMovies);
        listView.setAdapter(myAdapter);
        listView.setClickable(true);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, setMovieInfo.class);
                Movie currentMovie = (Movie) mPopularList.get(position);
                String title = currentMovie.getTitle();
                System.out.println("Current title sent is: " + title);
                String language = "English";
                Double pop = currentMovie.getPopularity();
                String popularity = pop.toString();
                String releaseDate = currentMovie.getReleaseDate();
                String description = currentMovie.getOverview();
                String picURL = "https://image.tmdb.org/t/p/w185/" + currentMovie.getPosterPath();
                intent.putExtra("title", title);
                intent.putExtra("popularity", popularity);
                intent.putExtra("releaseDate", releaseDate);
                intent.putExtra("description", description);
                intent.putExtra("picURL", picURL);
                ArrayList<Integer> ar = currentMovie.getGenreIDs();
                intent.putIntegerArrayListExtra("ids", ar);
                startActivity(intent);
            }
        });
        Log.i("setAdapter?", "yes");
    }

    public void getCurrentWeather1(View view) throws Exception {
        Log.i("Get Current w", "Yes");
        weatherHelper();
    }

    public class MyCustomListAdapter extends ArrayAdapter<Movie> {
        List<Movie> le;
        public MyCustomListAdapter(Context context, List<Movie> liste) {
            super(context, R.layout.movie_item, liste);
            le = liste;
            Log.i("here?", "yes");
        }
        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            //return super.getView(position, convertView, parent);
            Log.i("getView", "yes");
            View itemView = convertView;
            if (itemView == null)
                itemView = getLayoutInflater().inflate(R.layout.movie_item, parent, false);

            TextView movieTitle = itemView.findViewById(R.id.movieTitle);
            ImageView moviePic = itemView.findViewById(R.id.moviePic);
            // check if user wants to view dataLog or Reminders?
            Log.i("List Empty?", le.get(position).getOriginalTitle());
            Movie currentMovie = (Movie) le.get(position);
            movieTitle.setText(currentMovie.getTitle());
            String movieImageURL = "https://image.tmdb.org/t/p/w185/" + currentMovie.getPosterPath();
            System.out.println("Image for movie is: "+ movieImageURL);
            Picasso.with(context).setLoggingEnabled(true);
            Picasso.with(context).load(movieImageURL).fit().into(moviePic);

            return itemView;
        }
    }
}