

# Problem 3.1
#def fib(x):
#    if x <= 1:
#        return x
#    else:
#        return fib(x-1) + fib(x-2)

#for i in range(20):
#    print(fib(i))


#Problem 3.2
#def firstLast(seq):
#    first = seq[0]
#    last = seq[len(seq) - 1]
#    if len(seq) == 1:
#        newTup = (first)
#        return newTup
#    else:
#        newTup = (first, last)
#        return newTup
#    return "Didn't work"
#print(firstlast([5]))


#Problem 3.3
#class  node:
#    def  __init__(self , value , subnodes ):
#        self.value = value
#        self.subnodes = subnodes
#extree = node(1,[node (2,[]), node(3,[node(4,[node(5,[]), node(6,[node (7 ,[])])])])])

#sum = 0
#    def sumnodesrec(root):
#        #you need to find a way to find if a node has a next node
#        if root.subnodes.size <= 1:
#            return sum
#        else:
#            sum += root.value
#            #send next node
#            #choose a way of traversing the tree L,C,R?
#            return sumNodesRec(root) # what ever next node is


#Problem 3.4
#Complete thesumNodesNoRec(root)function so it returns the sumof the values at each 
#node in the tree without using recursion.


#Problem 3.5 
compose = lambda x: lambda y: x * y
f_outer  = compose(.5)  #Split amount in half
f_inner = compose(.25)    #Split amount in fourths
print(f_outer(20))
print(f_inner(20))


#Problem 3.6

