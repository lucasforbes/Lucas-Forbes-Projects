EA <- read.table("C:\\Users\\Lucas Forbes\\Downloads\\examanxiety.txt", header = TRUE)
summary(EA)
anxietyM = subset(EA$Anxiety, EA$Gender == 'Male')
anxietyF = subset(EA$Anxiety, EA$Gender == 'Female')

t.test(anxietyF,anxietyM,alt="t",conf.level=0.95) 


#part b

linreg = lm(EA$Exam ~ EA$Anxiety)
summary(linreg)

#part c
# i
plot(EA$Exam ~ EA$Anxiety)

# ii
cor.test(EA$Anxiety,EA$Exam)

# iii
plot(resid(linreg)) #plot of residuals

# iv
qqnorm(resid(linreg)) #normality check for residuals
qqline(resid(linreg))