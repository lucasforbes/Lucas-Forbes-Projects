quotes <- read.table("C:\\Users\\Lucas Forbes\\Downloads\\quoteattribution.txt", header = TRUE)

george = subset(quotes, quotes$quoteGroup == 1)
Osama = subset(quotes, quotes$quoteGroup == 0)
Osama = Osama[complete.cases(Osama),]
summary(Osama)
summary(george)
# Part a
hist(george$quote,
     main = "Frequency of Ratings for George Washington",
     xlab = "Scale (0-9)")
hist(Osama$quote,
     main = "Frequency of Ratings for Osama bin Laden",
     xlab = "Scale (0-9)")
 
# Part e
meanG = 5.928
meanO = 5.232
d = meanG - meanO
stG = sd(george$quote)
stO = sd(Osama$quote)
print(stO)
nG = nrow(george)
nO = nrow(Osama)
print(nG)
print(nO)
print(stO^2)
se = sqrt((stG^2 / nG) + (stO^2 / nO))
print(se)
df = ((stG^2 / nG) + (stO^2 / nO))^2 / (((stG^2 / nG)^2/(nG-1))  + ((stO^2 / nO)^2/(nO-1)))
print(df)
tTest = (d - df)/ se
print(tTest)
p = pval(tTest)

# These are the tests I used for Part e-g
res = t.test(george$quote, Osama$quote, alternative = "greater")
print(res)
print(res$p.value)

res = t.test(george$quote, Osama$quote, conf.level = 0.99)
print(res)
