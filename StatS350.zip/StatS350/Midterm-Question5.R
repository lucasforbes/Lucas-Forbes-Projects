tests <- read.table("C:\\Users\\Lucas Forbes\\Downloads\\ranehill20.txt", header = TRUE)
tests$difference = tests$test2 - tests$test1

hp = subset(tests, tests$hp_condition == 1)
lp = subset(tests, tests$hp_condition == 0)

summary(hp)
summary(lp)

# Part a
boxplot(hp$difference, 
     main = "Box Plot for difference in testosterone levels (after-before) for High Power Pose ",
     ylab = "Difference in testosterone levels (after-before)",
     xlab = "High Power Pose")

boxplot(lp$difference, 
        main = "Box Plot for difference in testosterone levels (after-before) for High Power Pose ",
        ylab = "Difference in testosterone levels (after-before)",
        xlab = "High Power Pose")

meanHP = 2.6896
meanLP = 6.767
d = meanHP - meanLP
stHP = sd(hp$difference)
stLP = sd(lp$difference)
print(stHP)
print(stLP)
nHP = nrow(hp)
nLP = nrow(lp)
print(nHP)
print(nLP)

se = sqrt((stHP^2 / nHP) + (stLP^2 / nLP))
print(se)

df = ((stHP^2 / nHP) + (stLP^2 / nLP))^2 / (((stHP^2 / nHP)^2/(nHP-1))  + ((stLP^2 / nLP)^2/(nLP-1)))
print(df)

tTest = (d - df)/ se
print(tTest)
p = pval(tTest)

t.test(hp$difference, lp$difference, alt="greater")

t.test(lp$difference)