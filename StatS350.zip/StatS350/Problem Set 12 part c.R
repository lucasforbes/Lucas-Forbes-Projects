game <- read.table("C:\\Users\\Lucas Forbes\\Downloads\\GameEmpathy.txt", header = TRUE)
summary(game)

game$logEmpathy = log(game$empathy)

x1 = subset(game$empathy, game$game.type == 'neutral')

x2 = subset(game$empathy, game$game.type == 'HalfLife')
x3 = subset(game$empathy, game$game.type == 'GTA')

y1 = subset(game$logEmpathy, game$game.type == 'neutral')
y2 = subset(game$logEmpathy, game$game.type == 'HalfLife')
y3 = subset(game$logEmpathy, game$game.type == 'GTA')

neutralPlayers = subset(game, game.type == "neutral")
halflifePlayers= subset(game, game.type == 'HalfLife')
gtaPlayers = subset(game, game.type == 'GTA')

boxplot(x1, x2, x3)

boxplot(y1, y2, y3)

# anova
anova(lm(empathy ~ game.type, data = game))

# question b
boxplot(neutralPlayers$identify, neutralPlayers$empathy)
boxplot(halflifePlayers$identify, halflifePlayers$empathy)
boxplot(gtaPlayers$identify, gtaPlayers$empathy)


# anova neutral: identification vs empathy
anova(lm(identify ~ empathy, data = neutralPlayers))
# anova halflife: identification vs empathy
anova(lm(identify ~ empathy, data = halflifePlayers))
# anova gta: identification vs empathy
anova(lm(identify ~ empathy, data = gtaPlayers))