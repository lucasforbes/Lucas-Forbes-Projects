##################### Question 2 ##########################
exam <- read.table("C:\\Users\\Lucas Forbes\\Downloads\\exam.txt", header = TRUE)
summary(exam)

math = exam$math
reading = exam$reading

model = lm(math ~ reading, data=exam)
print(model)
# Check linearity, homoskedasticity, normality of errors
par(mfrow = c(2,2))
plot(model)

#confidence interval
confint(model, level=0.9)

##################### Question 3 ##########################
citations <-read.table("C:\\Users\\Lucas Forbes\\Downloads\\citations.txt", header = TRUE)
summary(citations)
n = length(citations$X0)
print(n)
# data normal?
x <- citations$X0
sigma = sd(x)
h<-hist(x, breaks=10, col="red", xlab="Miles Per Gallon",
        main="Histogram with Normal Curve")
xfit<-seq(min(x),max(x),length=40)
yfit<-dnorm(xfit,mean=mean(x),sd=sd(x))
yfit <- yfit*diff(h$mids[1:2])*length(x)
lines(xfit, yfit, col="blue", lwd=2)
citations
d <- density(citations$X0)
plot(d, main="Kernel Density of Miles Per Gallon")
polygon(d, col="red", border="blue")

# confidence interval of mean
q = qnorm(.95)
me = q*(sigma/sqrt(n))
upBound = mean(x)+me
lowBound = mean(x)-me
print(upBound)
print(lowBound)

# proportion
zeroCits = sum(x == 0)
print(zeroCits)
zeroCits = zeroCits / n
print(q)
me = q * sqrt(zeroCits * (1 - zeroCits) / n)
print(me)
upBound = zeroCits + me
lowBound = zeroCits - me
print(upBound)
print(lowBound)

############## question 4 ###########################
library(ggpubr)
low1 = c(12.3, 17.7, 12.3, 4.3, 6.8, 8.5, 5.7, NA)
med1 = c(4, 4, 3.1, 4.9, 6.3, 6.2, 3.5, 3.7)
high1 = c(3.6, 1.7, 3.8, 4.1, 1.3, 3.4, 1.2, 2.8)
# put in txt file for easy load into table
temps <-read.table("C:\\Users\\Lucas Forbes\\Downloads\\question4.txt", header = TRUE)
print(temps)
summary(temps)

logTemp = log(temps$temp)
temps$logTemp = logTemp

boxplot(temps$temp ~ temps$group)

boxplot(temps$logTemp ~ temps$group)
low = subset(temps$temp, temps$group == 'low')
med = subset(temps$temp, temps$group == 'med')
high = subset(temps$temp, temps$group == 'high')
logLow = subset(temps$logTemp, temps$group == 'low')
logMed = subset(temps$logTemp, temps$group == 'med')
logHigh = subset(temps$logTemp, temps$group == 'high')

print(sd(low))
print(sd(med))
print(sd(high))
print(sd(logLow))
print(sd(logMed))
print(sd(logHigh))
# log scale anova
anova(lm(temps$logTemp ~ temps$group, data = temps))

# follow up
lowMed <- subset(temps, temps$group != 'high')
lowHigh <- subset(temps, temps$group != 'med')
medHigh <- subset(temps, temps$group != 'low')

# low med anova
anova(lm(logTemp ~ group, data = lowMed))
# low high anova
anova(lm(logTemp ~ group, data = lowHigh))
# med high anova
anova(lm(logTemp ~ group, data = medHigh))

########### question 5 ##########################
obvious <-read.table("C:\\Users\\Lucas Forbes\\Downloads\\obvious.txt", header = TRUE)
summary(obvious)

# question a
# method = anova test
yesSpice <- subset(obvious, obvious$spicy == "Yes")
noSpice <- subset(obvious, obvious$spicy == "No")
boxplot(yesSpice$indianfood, noSpice$indianfood)
# assumptions equal sd
sd(yesSpice$indianfood)
sd(noSpice$indianfood)
# show correlation
model = lm(obvious$indianfood ~ obvious$spicyInt, data=obvious)
anova(model)

# Ignore the code inside the block. Was first attempt at using linear regression
################################################################################
# library(ggplot2)
# ggplot(obvious$indianfood)
# obvious$spicyInt = ifelse(obvious$spicy == "Yes", 1,0)
# n = length(obvious$age)
# boxplot(obvious$spicyInt)
# model = lm(obvious$indianfood ~ obvious$spicyInt, data=obvious)
# fitted.values(model)
# print(sum(obvious$spicy == "Yes"))
# print(sum(obvious$spicy == "No"))
# obvious.model = model
# summary(obvious.model)
# #95% confidence interval for regression
# upbound = 1.7429 + qt(.975, n-2) * 0.3034
# lowBound = 1.7429 - qt(.975, n-2) * 0.3034
# print(upBound)
# print(lowBound)
# # RSE
# sd(obvious$indianfood)
# predictions <- 2.8 + 1.7429 * obvious$spicyInt
# errors <- obvious$indianfood - predictions
# mean(errors)
# sd(errors)
# 
# #Assumption 1 Linearity
# #install.packages("broom")
# library(broom)
# plot(obvious$spicyInt, residuals(model))
# my.lm.df <- augment(model)
# ggplot(my.lm.df, aes(obvious$spicyInt, .resid)) + geom_point() + geom_smooth()
# 
# # Assumptioon 2 Independence = True, random sample stated
# 
# # Assumption 3 Homoskedasticity
# ggplot(my.lm.df, aes(obvious$spicyInt, abs(.resid))) + geom_point() + geom_smooth()
# 
# #Multiple R squared
# cor(obvious$spicyInt, obvious$indianfood)^2
# # anova
# anova(model)
######################################################################################

# question b
# Method = linear Regression
model2 = lm(obvious$retire ~ obvious$age, data = obvious)
obvious.model2 = model2

#Assumption 1 Linearity = smooth line horizontal indicating linearity
#install.packages("broom")
library(broom)
my.lm.df <- augment(model2)
ggplot(my.lm.df, aes(obvious$age, .resid)) + geom_point() + geom_smooth()

# Assumptioon 2 Independence = True, random sample stated

# Assumption 3 Homoskedasticity = Unknown, the spread 
ggplot(my.lm.df, aes(obvious$age, abs(.resid))) + geom_point() + geom_smooth()
# remove outlier to continue
print(length(obvious$age))
outliersRemovedData = subset(obvious, obvious$retire != 100000)
outliersRemovedData = subset(outliersRemovedData, outliersRemovedData$age != 5)
print(length(outliersRemovedData$age))
model2removed = lm(outliersRemovedData$retire ~ outliersRemovedData$age, data=outliersRemovedData)
my.lm.df <- augment(model2removed) 
# new check on homoskedasticity
ggplot(my.lm.df, aes(outliersRemovedData$age, abs(.resid))) + geom_point() + geom_smooth()

#Assumption 4 Normality of errors
ggplot(my.lm.df, aes(sample = .resid)) + stat_qq()

#Significance test
summary(model2removed)
