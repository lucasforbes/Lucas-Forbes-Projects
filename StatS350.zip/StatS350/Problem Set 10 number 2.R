indiana <- read.table("C:\\Users\\Lucas Forbes\\Downloads\\indiana2020.txt", header = TRUE)

indiana$swing = indiana$margin2020 - indiana$margin2016
summary(indiana)

plot(indiana$college, indiana$swing, main="Scatterplot College vs Swing",
     xlab="College ", ylab="Swing", pch=19)

# log swing scatterplot
plot(indiana$college, log(indiana$swing), main="Scatterplot College vs Swing",
     xlab="College ", ylab="Swing", pch=19)

linReg = lm(indiana$swing ~ log(indiana$college))
summary(linReg)

indiana$residual = linReg$residuals

maxcounty = subset(indiana, indiana$residual > 7.1939)
print(maxcounty$name)

mincounty = subset(indiana, indiana$residual < -3.9)
print(mincounty$name)
