
ANESpilot <- read.table("C:\\Users\\Lucas Forbes\\Downloads\\ANESpilot.txt", header = TRUE)
# null = binom.test(1163,0.5)
sum(ANESpilot$ClintonFT < ANESpilot$TrumpFT)
binom.test(623, 1163, 0.5, conf.level=0.99)
binom.test(1288,2561,0.5,conf.level=0.95)
# question 3
pval = 1- pnorm(4.23055)
print(pval)

