cancer <- read.table("C:\\Users\\Lucas Forbes\\Downloads\\cancer.txt", header = TRUE)

x1 = subset(cancer$Survival, cancer$Cancer =='Stomach')
x2 = subset(cancer$Survival, cancer$Cancer =='Bronchus')
x3 = subset(cancer$Survival, cancer$Cancer =='Colon')
x4 = subset(cancer$Survival, cancer$Cancer =='Ovary')
x5 = subset(cancer$Survival, cancer$Cancer =='Breast')

y1 = log(x1)
y2 = log(x2)
y3 = log(x3)
y4 = log(x4)
y5 = log(x5)
# print(x1)

cancer$logSurvive = log(cancer$Survival)
boxplot(x1, x2, x3, x4, x5)

boxplot(y1, y2, y3, y4, y5)

data1 = c(y1, y2, y3, y4, y5)

anova(lm(logSurvive ~ Cancer, data = cancer))

