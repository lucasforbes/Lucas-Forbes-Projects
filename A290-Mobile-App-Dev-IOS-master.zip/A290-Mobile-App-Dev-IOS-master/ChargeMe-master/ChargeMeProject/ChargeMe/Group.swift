//
//  Group.swift
//  ChargeMe
//
//  Created by Jimmy Conway on 12/3/18.
//  Copyright © 2018 A290 Lab. All rights reserved.
//

import UIKit
import os.log

class Group: NSObject, NSCoding {
    var name: String
    var photo: UIImage
    var members: [String]
    var owed: Double
    var payLog: [String]
    var total = 0.0
    var groupSize = 0.0
    var perPerson = 0.0
    var payArray = [Double]()
    
    
    init(name: String, photo: UIImage, members: [String], owed: Double, total: Double, groupSize: Double, perPerson: Double, payArray: [Double], payLog: [String]) {
        self.name = name
        self.photo = photo
        self.members = members
        self.owed = owed
        self.total = total
        self.groupSize = groupSize
        self.perPerson = perPerson
        self.payArray = payArray
        self.payLog = payLog
        
    }
    
    //Persistent save data code
    struct PropertyKey {
        static let name = "name"
        static let photo = "photo"
        static let members = "members"
        static let owed = "owed"
        static let groupSize = "groupSize"
        static let perPerson = "perPerson"
        static let total = "total"
        static let payArray = "payArray"
        static let payLog = "payLog"
    }
    
    //MARK: NSCoding
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: PropertyKey.name)
        aCoder.encode(photo, forKey: PropertyKey.photo)
        aCoder.encode(members, forKey: PropertyKey.members)
        aCoder.encode(owed, forKey: PropertyKey.owed)
        aCoder.encode(groupSize, forKey: PropertyKey.groupSize)
        aCoder.encode(perPerson, forKey: PropertyKey.perPerson)
        aCoder.encode(total, forKey: PropertyKey.total)
        aCoder.encode(payArray, forKey: PropertyKey.payArray)
        aCoder.encode(payLog, forKey: PropertyKey.payLog)
        
        
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        let name = aDecoder.decodeObject(forKey: PropertyKey.name)
        let photo = aDecoder.decodeObject(forKey: PropertyKey.photo) as? UIImage
        let members = aDecoder.decodeObject(forKey: PropertyKey.members)
        let owed = aDecoder.decodeDouble(forKey: PropertyKey.owed)
        let groupSize = aDecoder.decodeDouble(forKey: PropertyKey.groupSize)
        let perPerson = aDecoder.decodeDouble(forKey: PropertyKey.perPerson)
        let total = aDecoder.decodeDouble(forKey: PropertyKey.total)
        let payArray = aDecoder.decodeObject(forKey: PropertyKey.payArray)
        let payLog = aDecoder.decodeObject(forKey: PropertyKey.payLog)
        
        self.init(name: name as! String, photo: photo!, members: members as! [String], owed: owed, total: total, groupSize: groupSize, perPerson: perPerson, payArray: payArray as! [Double], payLog: payLog as! [String])
    }
    
    //MARK: Archiving Paths
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("group")
}

