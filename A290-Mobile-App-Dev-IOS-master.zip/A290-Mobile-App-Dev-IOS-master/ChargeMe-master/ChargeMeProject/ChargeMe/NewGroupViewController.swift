//
//  NewGroupViewController.swift
//  ChargeMe
//
//  Created by Jimmy Conway on 11/28/18.
//  Copyright © 2018 A290 Lab. All rights reserved.
//

import UIKit

class NewGroupViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var groupNameTextField: UITextField!
    @IBOutlet weak var memberTextField: UITextField!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    @IBOutlet weak var groupProfilePhoto: UIImageView!
    
    var newGroup: Group?

    override func viewDidLoad() {
        super.viewDidLoad()
        print("***This view did load***")
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func addGroupPicture(_ sender: Any) {
        let alertController = UIAlertController(title: nil, message: "Camera or existing picture?", preferredStyle: .actionSheet)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { action in
            // ...
        }
        alertController.addAction(cancelAction)
        
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { action in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                let imagePickerController = UIImagePickerController()
                
                imagePickerController.sourceType = .camera
                imagePickerController.delegate = self
                self.present(imagePickerController, animated: true, completion: nil)
            } else {
                let messageController = UIAlertController(title: "Error", message: "Camera not available", preferredStyle: .alert)
                messageController.addAction(cancelAction)
                
                self.present(messageController, animated: true, completion: nil)
                
                
            }
        }
        alertController.addAction(cameraAction)
        
        let chooseAction = UIAlertAction(title: "Choose Existing Photo", style: .default) { action in
            let imagePickerController = UIImagePickerController()
            
            imagePickerController.sourceType = .photoLibrary
            imagePickerController.delegate = self
            self.present(imagePickerController, animated: true, completion: nil)
        }
        alertController.addAction(chooseAction)
        
        let deletePhotoAction = UIAlertAction(title: "Delete Profile Picture", style: .destructive) { action in
            //self.profilePicture.image = #imageLiteral(resourceName: "ProfileIcon")
            //self.profile?.photo = #imageLiteral(resourceName: "ProfileIcon")
        }
        alertController.addAction(deletePhotoAction)
        
        self.present(alertController, animated: true) {
            // ...
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        // The info dictionary may contain multiple representations of the image. You want to use the original.
        guard let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        
        // Set photoImageView to display the selected image.
        groupProfilePhoto.image = selectedImage
        newGroup?.photo = selectedImage
        
        // Dismiss the picker.
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        guard let button = sender as? UIBarButtonItem, button == saveButton else {
            print("Save button not pressed, cancelling...")
            return
        }
        let name = groupNameTextField.text
        // need to change members so names are saved without " "
        let members = memberTextField.text?.components(separatedBy: ", ")
        var groupImage: UIImage
        if groupProfilePhoto.image != nil {
            groupImage = groupProfilePhoto.image!
        } else {
            groupImage = #imageLiteral(resourceName: "pexels-photo-1068989")
        }
        //
        newGroup = Group(name: name!, photo: groupImage, members: members!, owed: 0.00, total: 0.0, groupSize: 0.0, perPerson: 0.0, payArray: [], payLog: [])
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    

}
