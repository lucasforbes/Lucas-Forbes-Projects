import math

# takes a set of real numbers which is broken down into a list of real parts and a list of the imaginary parts
def compute_dft(inreal, inimag):
	assert len(inreal) == len(inimag)
	n = len(inreal)
	outreal = []
	outimag = []
	for k in range(n):  # For each output element
		sumreal = 0.0
		sumimag = 0.0
		for t in range(n):  # For each input element
			angle = 2 * math.pi * t * k / n
			sumreal +=  inreal[t] * math.cos(angle) + inimag[t] * math.sin(angle)
			sumimag += -inreal[t] * math.sin(angle) + inimag[t] * math.cos(angle)
		outreal.append(round(sumreal))
		outimag.append(round(sumimag))
	return (outreal, outimag)

# call dft on a complex set of numberrs
dft = compute_dft([1,2,0,-1], [0,-1,-1,2])
print(dft)
#