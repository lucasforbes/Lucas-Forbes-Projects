import static org.junit.Assert.*;
import org.junit.Test;

public class Testing {

  @Test
  public void setUpTest() {
    MatrixDigraph gr = new MatrixDigraph(4);
    gr.addEdge(0, 1, 1);
    gr.addEdge(0, 2, 2);
    gr.addEdge(1, 1, 3);
    gr.addEdge(1, 3, 4);
    gr.addEdge(2, 1, 5);
    gr.addEdge(2, 3, 5);
    gr.addEdge(2, 3, 6);
    gr.addEdge(3, 2, 7);
    assertEquals(4, gr.numVertices());
    assertEquals(7, gr.numEdges());
    assertTrue(gr.hasEdge(0, 1));
    assertTrue(gr.hasEdge(0, 2));
    assertTrue(gr.hasEdge(1, 1));
    assertTrue(gr.hasEdge(1, 3));
    assertTrue(gr.hasEdge(2, 1));
    assertTrue(gr.hasEdge(2, 3));
    assertTrue(gr.hasEdge(3, 2));
    assertEquals(1, gr.weight(0, 1));
    assertEquals(2, gr.weight(0, 2));
    assertEquals(3, gr.weight(1, 1));
    assertEquals(4, gr.weight(1, 3));
    assertEquals(5, gr.weight(2, 1));
    assertEquals(6, gr.weight(2, 3));
    assertEquals(7, gr.weight(3, 2));
    assertFalse(gr.hasEdge(0, 0));
    assertFalse(gr.hasEdge(1, 0));
    assertFalse(gr.hasEdge(10, 11));
    assertEquals(Integer.MAX_VALUE, gr.weight(10, 11));
  }  
  
  @Test
  public void outTest() {
    MatrixDigraph gr = new MatrixDigraph(4);
    gr.addEdge(0, 1, 1);
    gr.addEdge(0, 2, 2);
    gr.addEdge(1, 1, 3);
    gr.addEdge(1, 3, 4);
    gr.addEdge(2, 1, 5);
    gr.addEdge(2, 3, 6);
    gr.addEdge(3, 2, 7);
    
    //System.out.println(gr.out(0));
    assertEquals(2, gr.out(0).size());
    assertTrue(gr.out(0).contains(1));
    assertTrue(gr.out(0).contains(2));

    assertEquals(2, gr.out(1).size());
    assertTrue(gr.out(1).contains(1));
    assertTrue(gr.out(1).contains(3));

    assertEquals(2, gr.out(2).size());
    assertTrue(gr.out(2).contains(1));
    assertTrue(gr.out(2).contains(3));

    assertEquals(1, gr.out(3).size());
    assertTrue(gr.out(3).contains(2));
  }
  
  /**
   * TODO: write a suitable test for the in() operation.
   * those vertices that are incident to an incoming edge of v.
   */
  
  @Test
  public void inTest() {
	  	MatrixDigraph gr = new MatrixDigraph(4);
	    gr.addEdge(0, 1, 1);
	    gr.addEdge(0, 2, 2);
	    gr.addEdge(1, 1, 3);
	    gr.addEdge(1, 3, 4);
	    gr.addEdge(2, 1, 5);
	    gr.addEdge(2, 3, 6);
	    gr.addEdge(3, 2, 7);
	    assertEquals(3, gr.in(1).size());
	    assertTrue(gr.in(1).contains(1));
	    assertTrue(gr.in(1).contains(0));
	    assertTrue(gr.in(1).contains(2));
  }

  @Test
  public void twoHopTest() {
    MatrixDigraph gr = new MatrixDigraph(4);
    gr.addEdge(0, 1, 1);
    gr.addEdge(0, 2, 2);
    gr.addEdge(1, 1, 3);
    gr.addEdge(1, 3, 4);
    gr.addEdge(2, 1, 5);
    gr.addEdge(2, 3, 6);
    gr.addEdge(3, 2, 7);

    assertEquals(2, gr.twoHopsAway(0).size());
    assertTrue(gr.twoHopsAway(0).contains(1));
    assertTrue(gr.twoHopsAway(0).contains(3));
    
    assertEquals(3, gr.twoHopsAway(1).size());
    assertTrue(gr.twoHopsAway(1).contains(1));
    assertTrue(gr.twoHopsAway(1).contains(2));
    assertTrue(gr.twoHopsAway(1).contains(3));
    
    assertEquals(3, gr.twoHopsAway(2).size());
    assertTrue(gr.twoHopsAway(2).contains(1));
    assertTrue(gr.twoHopsAway(2).contains(2));
    assertTrue(gr.twoHopsAway(2).contains(3));
    
    assertEquals(2, gr.twoHopsAway(3).size());
    assertTrue(gr.twoHopsAway(3).contains(1));
    assertTrue(gr.twoHopsAway(3).contains(3));
  }
  
}
