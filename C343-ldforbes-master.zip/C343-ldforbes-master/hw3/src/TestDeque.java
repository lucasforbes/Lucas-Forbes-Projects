import javax.xml.soap.Node;

import hw3.Deque;

public class TestDeque extends DoublyLinkedList implements Deque{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void push(Node x) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void inject(Node x) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void eject() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void push(javax.xml.soap.Node x) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void inject(javax.xml.soap.Node x) {
		// TODO Auto-generated method stub
		
	}

}
