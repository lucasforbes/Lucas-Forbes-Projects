package hw3;

import javax.xml.soap.Node;

public interface Deque {
	
	void push(Node x); //Insert item x on the front end of the deque. 
	void pop(); //Remove the front item from the deque and return it. 
	void inject(Node x); //Insert item x on the rear end of the deque. 
	void eject(); //Remove the rear item from the deque and return it.

}
