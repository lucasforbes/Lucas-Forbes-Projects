import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * hw3: Problem 2 starter code.
 */

public class SetOps {

	/**
	 * Returns a list (without duplicates) containing all the items
	 * in ls1 plus all the items in ls2. Note: ls1 and ls2 are 
	 * unchanged by this method.
	 */
	public static <T> List<T> union(List<T> ls1, List<T> ls2) {
		List<T> answer= new DoublyLinkedList<T>();//Setup a new list to return at the end
		for(int i = 0; i < ls1.size(); i++) {
			for(int j = 0; j < ls2.size(); j++) {
				T cur1 = ls1.get(i);
				T cur2 = ls2.get(j);
				if(!answer.contains(cur1))
					answer.add(cur1);
				else if(!answer.contains(cur2))
					answer.add(cur2);
			}
		}
		return answer;
	}
	// run-time O(n1^3 * n2^3)
	// the run time is order n1 to the fifth power * n2 to the fifth power because there are two lists of differing sizes
	// the algorithm traverses through the first list o(n1), traverses through the second list o(n2), calls the get method on L1 and L2 O(n),
	// and calls the contains method on L1 and L2 O(n). 
	/**
	 * Returns a list (without duplicates) of all the items which
	 * appear both in ls1 and in ls2. Note: ls1 and ls2 are
	 * unchanged by this method.
	 */
	public static <T> List<T> intersection(List<T> ls1, List<T> ls2) {
		List<T> answer= new DoublyLinkedList<T>();//Setup a new list to return at the end

		for (int i = 0; i < ls1.size(); i++) {//Loop through all elements in ls1
			for (int j = 0; j < ls2.size(); j++) {//Loop through all elements in ls2
				if (ls1.get(i) == ls2.get(j))//Check if they are the same (if they are equal then that element gets added to the lsit
					if(! answer.contains(ls1.get(i))) { //check if they are already in our list to prevent duplicates
						answer.add(ls1.get(i));//add them to the list
					}
			}
		}
		return answer;
	}
	// run-time O(n1^5 * n2^4)
	// the run time is order n1 to the fifth power * n2 to the fifth power because there are two lists of differing sizes
	// the algorithm traverses through the first list o(n1), traverses through the second list o(n2), calls the get method on L1 and L2 O(n),
	// and calls the contains method in conjunction with get method on L1 and L2 O(n^2). Then it adds the element to the list using get again O(n)
	/**
	 * Simple testing to get you started. Add more tests of your own!
	 */
	public static void main(String... args) {
		List<String> ls1 = new DoublyLinkedList<>();
		ls1.add("ant");
		ls1.add("bat");
		ls1.add("cat");
		ls1.add("ant");  // this is a duplicate element
		ls1.add("fox");
		int n1 = ls1.size();
		System.out.println("ls1 = " + ls1);

		List<String> ls2 = new DoublyLinkedList<>();
		ls2.add("cat");
		ls2.add("dog");
		ls2.add("dog");  // this is a duplicate element
		ls2.add("emu");
		ls2.add("fox");
		ls2.add("gnu");
		int n2 = ls2.size();
		System.out.println("ls2 = " + ls2);

		List<String> ls3, ls4;
		ls3 = union(ls1, ls2);
		assert n1 == ls1.size();
		assert n2 == ls2.size();
		assert 7 == ls3.size();
		System.out.println("ls3 = " + ls3);

		ls4 = intersection(ls1, ls2);
		assert n1 == ls1.size();
		assert n2 == ls2.size();
		assert 2 == ls4.size();
		System.out.println("ls4 = " + ls4);
	}
}

