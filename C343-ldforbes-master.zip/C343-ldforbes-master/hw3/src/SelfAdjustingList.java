/**
 * hw3: Problem 5 starter code.
 */

public class SelfAdjustingList<T> extends DoublyLinkedList<T> {

  // TODO: New code goes here.
	/*find operation, and when an element is accessed by a find, it is moved to the front of the 
	 * list without changing the relative order of the other items. 
	 * b. Write a linked list implementation of self-adjusting lists. 
	 */
  public int find(int x) {
	  Node ret = head;
	  for(int i = 0; i < x; i++) {
		  ret = head.next;
	  }
	  remove(x);
	  Node first = head.next; 
	  head.next = ret;
	  first.prev = ret;
	  ret.prev = head;
	  ret.next = first;
	  return (int) ret.data;
  }
  /**
   * Simple testing to get you started. Add more tests of your own!
   */
  public static void main(String... args) {
    SelfAdjustingList<Integer> xs = new SelfAdjustingList<>();
    for (int x = 1; x <= 10; x++)
      xs.add(x);
    for (int i = 0; i < xs.size(); i++)
      assert 10 - i == xs.get(i);
    for (int i = 0; i < xs.size(); i++) {
      int x = xs.get(i);
      assert x == xs.find(i);
    }
    for (int i = 0; i < xs.size(); i++) {
      int x = xs.find(i);
      assert x == xs.get(0);
    }
    System.out.println("All tests passed...");
  }
}
