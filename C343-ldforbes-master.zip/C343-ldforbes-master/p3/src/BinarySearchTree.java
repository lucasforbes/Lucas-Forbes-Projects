import java.util.LinkedList;
import java.util.List;
import java.util.function.BiPredicate;

/**
 * TODO: This is your first major task.
 * 
 * This class implements a generic unbalanced binary search tree (BST).
 */

public class BinarySearchTree<K> implements Tree<K> {
  
  /**
   * A Node is a Location, which means that it can be the return value
   * of a search on the tree.
   */
  
  class Node implements Location<K> { 
    protected K data;
    protected Node left, right;
    protected Node parent;     // the parent of this node
    protected int height;      // the height of the subtree rooted at this node
    protected boolean dirty;   // true iff the key in this node has been removed
    /**
     * Constructs a leaf node with the given key.
     */
    public Node(K key) {
      this(key, null, null);
    }
    
    /**
     * TODO
     * 
     * Constructs a new node with the given values for fields.
     */
    public Node(K data, Node left, Node right) {
    	// assign global variables
    	this.data = data;
    	this.left = left;
    	this.right = right;
    	this.height = 1;
    	this.dirty = false;
    }

    /**
     * Return true iff this node is a leaf in the tree.
     */
    protected boolean isLeaf() {
      return left == null && right == null;
    }
    
    /**
     * TODO
     * 
     * Performs a local update on the height of this node. Assumes that the 
     * heights in the child nodes are correct. This function *must* run in 
     * O(1) time.
     */
    protected void fixHeight() {
    	// check if node is not a leaf
    	int lHeight = 0;
		int rHeight = 0;
		int max = 0;
    	if(!isLeaf()) {
    		
    		// assigns left subtree height to height of left node
    		if(left != null) {
    			lHeight = left.height;
    		}
    		// assigns right subtree height to height of right node
    		if(right != null) {
    			rHeight = right.height;
    		}
    		// assigns the maximum height to the larger of lHeight and rHeight
    		max = Math.max(lHeight, rHeight);
    		height = max + 1;
    	}
    	else {
    		height = 1;
    	}
    }
    
    /**
     * TODO
     * 
     * Returns the data in this node.
     */
    public K get() {
    	return this.data; //idk if this is right
    }

    /**
     * TODO
     * 
     * Returns the location of the node containing the inorder predecessor
     * of this node.
     */
    public Node getBefore() {
    	//check if this.node has a parent and does not have a left child
    	if(parent != null && left == null) {
    		//create a new node before
    		Node before = this;
    		while(before.parent != null) {
    			// check if node is to the right of its parent
    			if(before.parent.right != null && before == before.parent.right) {
    				//returns the parent if not marked dirty
    				if(!before.parent.dirty)
    					return before.parent;
    				// recursively calls getBefore on parent until a parent thats not dirty is found
    				else
    					return before.parent.getBefore();
    			}
    			// check if node is to the left of its parent which is root
    			else if(before.parent == root && before.parent.left != null && before == before.parent.left) {
    				return null;
    			}
    			// steps up the tree if previous criteria was not met
    			else
    				before = before.parent;
    		}
    		// calls getBefore on node if it's found to be the root node and dirty
    		// will then go to else if statement
    		if(before == root && before.dirty)
    			return before.getBefore();
    	}
    	else if(left != null) {
    		Node b = left;
    		// finds the rightmost node of left subtree
    		while(b.right != null)
    			b = b.right;
    		//returns the rightmost node of left subtree if not dirty
    		if(!b.dirty)
    			return b;
    		// if b is dirty it will get the node before
    		else
    			return b.getBefore();
    	}
    	
      return null;
     }

    /**
     * TODO
     * 
     * Returns the location of the node containing the inorder successor
     * of this node.
     */
    public Node getAfter() {
    	// check if parent is not null and right child is null
    	if(parent != null && right == null) {
    		// create new node after
    		Node after = this;
    		//walks up tree
    		while(after.parent != null) {
    			//checks if after is the left child of its parent
    			if(after.parent.left != null && after == after.parent.left) {
    				// returns parent if node is not dirty
    				if(!after.parent.dirty)
    					return after.parent;
    				// if dirty recursively finds parent
    				else
    					return after.parent.getBefore();
    			}
    			// returns null if parent is the root and after is the right node of the parent
    			else if(after.parent == root && after.parent.right != null && after.parent.right == after) {
    				return null;
    			}
    			// walks node after up the tree
    			else
    				after = after.parent;
    		}
    		// recursively calls getAfter if node after is a dirty root
    		if(after == root && after.dirty)
    			return after.getAfter();
    	}
    	// checks the right child is not null
    	else if(right != null) {
    		Node a = right;
    		// finds the left most child of right node
    		while(a.left != null)
    			a = a.left;
    		// returns left most if its nod dirty
    		if(!a.dirty)
    			return a;
    		// otherwise recursively calls getAfter on left leaf node
    		else
    			return a.getAfter();
    	}
    	
      return null;
    }


    /**
     * TODO
     *
     * Checks if the height difference of this node's subtrees is greater than 1
     */
     public boolean isOverweight() {
	      if(! isBalanced()) {
	    	  return true;
	      }
	      else {
	    	  return false;
	      }
     }

     /**
      * TODO
      * 
      * Checks if the subtrees of this node have the same height.
      */
      public boolean isBalanced() {
    	  BinarySearchTree<K>.Node left = root.left;
    	  BinarySearchTree<K>.Node right = root.right;
    	  
    	  if(left.height == right.height) {
    		  return true;
    	  }
    	  return false;
  }
 }
  protected Node root;
  protected int n;
  protected BiPredicate<K, K> lessThan;

  protected int dirtyCount;
  
  //Constructs a binary search tree in less than fashion
  public BinarySearchTree(BiPredicate<K, K> lessThan) {
      	this.lessThan = lessThan;
  }
  
  /**
   * TODO
   * 
   * Looks up the key in this tree and, if found, returns the (possibly dirty)
   * location containing the key.
   */
  public Node search(K key) {
	  Node find = root;
	  
	  while(find != null) {
		  // returns node if data matches the key
		  if(find.data == key)
			  return find;
		  // tests if key and find are in the bst and then
		  // assigns the left node to find
		  else if(lessThan.test(key, find.data))
			  find = find.left;
		  // assigns right child node to find
		  else
			  find = find.right;
	  }
	  
    return null;
  } 

  /**
   * TODO
   * 
   * Returns the height of this tree. Runs in O(1) time!
   */
  public int height() {
	  if(root == null)
		  return 0;
	  
	  return root.height;
  }
  
  /**
   * TODO
   * 
   * Clears all the keys from this tree. Runs in O(1) time!
   */
  public void clear() {
	  this.root = null;
	  dirtyCount = 0;
	  this.n = 0;
	  
  }
 

  /**
   * Returns the number of keys in this tree.
   */
  public int size() {
    return n;
  }
  
  /**
   * TODO
   * 
   * Inserts the given key into this BST, as a leaf, where the path
   * to the leaf is determined by the predicate provided to the tree
   * at construction time. The parent pointer of the new node and
   * the heights in all node along the path to the root are adjusted
   * accordingly.
   * 
   * Note: we assume that all keys are unique. Thus, if the given
   * key is already present in the tree, nothing happens.
   * 
   * Returns the location where the insert occurred (i.e., the leaf
   * node containing the key).
   */
  public Node insert(K key) {
	  Node i = root;
	  boolean contains = contains(key);
	  // if tree is empty enters a new node into the root
	  if(root == null) {
		  root = new Node(key, null, null);
		  n++;
		  contains = true;
	  }
	  // if node is root but is dirty changes dirty setting
	  else if(root.data.equals(key) && root.dirty) {
		  root.dirty = false;
		  dirtyCount--;
		  n++;
		  contains = true;
	  }
	  // run through the tree until contains is set to true
	  while(i != null && !contains) {
		  // test variable 
		  boolean check = lessThan.test(key, i.data);
		  // if i.data is less than key
		  if(check) {
			  //if left is null insert key into l child
			  if(i.left == null) {
				  i.left = new Node(key, null, null);
				  // assign i's l child's parent
				  i.left.parent = i;
				  n++;
				  contains = true;
				  i = i.left;
			  }
			  // if left child exists and is equal to i and is dirty, set to not dirty
			  else if (i.left.data.equals(key) && i.left.dirty == true) {
				  i.left.dirty = false;
				  dirtyCount--;
				  n++;
				  contains = true;
				  i = i.left;
			  }
			  // otherwise assign i to l child
			  else {
				  i = i.left;
			  }
		  }
		  else{
			  //if i.data is greater than key and right is null
			  // assign r child to new node key
			  if(i.right == null) {
				  i.right = new Node(key, null, null);
				  i.right.parent = i;
				  n++;
				  contains = true;
				  i = i.right;
			  }
			  // if r child is dirty and is equal to key change dirty status
			  else if (i.right.data.equals(key) && i.right.dirty == true) {
				  i.right.dirty = false;
				  dirtyCount--;
				  n++;
				  contains = true;
				  i = i.right;
			  }
			  // otherwise assign node i to r child
			  else {
				  i = i.right;
			  }  
		  }
	  }
	  // assign node i to node key
	  i = search(key);
	  Node r = i;
	  // change tree structure while traversing up the tree
	  while(i != null) {
		  i.fixHeight();
		  i = i.parent;
	  }
	  
    return r;
  }
  
  /**
   * TODO
   * 
   * Returns true iff the given key is in this BST.
   */
  public boolean contains(K key) {
    Node n = search(key);

    return (n != null && !n.dirty);
  }

  /**
   * TODO
   * 
   * Removes the key from this BST. If the key is not in the tree,
   * nothing happens. Implement the removal using lazy deletion.
   */
  public void remove(K key) {
	  Node x = search(key);
	  if(x != null && !x.dirty) {
		  n--;
		  x.dirty = true;
		  dirtyCount++;
	  }
  }
  
  /**
   * TODO
   * 
   * Clears out all dirty nodes from this BST.
   * 
   * Use the following algorithm:
   * (1) Let ks be the list of keys in this tree. 
   * (2) Clear this tree.
   * (2) For each key in ks, insert it into this tree.
   */
  public void rebuild() {
	  List<K> allKeys = keys();
	  // clear current bst
	  clear();
	  // insert all keys into bst
	  allKeys.forEach((key) -> insert(key));
  }
    
  /**
   * TODO
   * 
   * Returns a sorted list of all the keys in this tree.
   */
  public List<K> keys() {
	  // create a linked list to hold keys
	  List<K> list = new LinkedList<>();
	  Node l = root;
	  // root tree is filled 
	  if(root != null) {
		  // get left most node in tree
		  while(l.left != null) {
			  l = l.left;
		  }
		  // if left most is dirty add node to list
		  if(!l.dirty)
			  list.add(l.data);
		  // adds all nodes after the farthest left node
		  while(l.getAfter() != null) {
			  Node temp = l.getAfter();
			  list.add(temp.data);
			  l = temp;
		  }
	  }
	  
    return list;
  }

  /**
   * TODO
   * 
   * Returns a textual representation of this BST.
   */
  public String toString() {
	  String res = "";
	  Node temp = root;
	  if(root == null) {
		  return "";
	  }
	  res += stringHelper(temp.left);
	  res += stringHelper(temp.right);
	  res += temp.data.toString();
	  return res;

  }
 
  private String stringHelper(BinarySearchTree<K>.Node t) {
	  while(t != null) {
		  root = t;
		  root.toString();
	  }
	  return root.data.toString();
  }
}
