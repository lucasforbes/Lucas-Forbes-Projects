import java.util.function.BiPredicate;

/**
 * TODO: This is your second major task.
 *
 * This class implements a generic height-balanced binary search tree, 
 * using the AVL algorithm. Beyond the constructor, only the insert()
 * method needs to be implemented. All other methods are unchanged.
 */

public class AVLTree<K> extends BinarySearchTree<K> {

  /**
   * Creates an empty AVL tree as a BST organized according to the
   * lessThan predicate.
   */
  public AVLTree(BiPredicate<K, K> lessThan) {
    super(lessThan);
  }

  /**efw
   * TODO
   * 
   * Inserts the given key into this AVL tree such that the ordering 
   * property for a BST and the balancing property for an AVL tree are
   * maintained.
   */
  
  public Node insert(K key) {
	 
    Node insert = super.insert(key);
    Node i = insert;
    Node par = insert.parent;
    Node x = null;
    
    while(par != null) {
        int lHeight = 0;
        int rHeight = 0;
        // assign lHeight to left child of parent
        if(par.left != null)
        	lHeight = par.left.height;
        // assign rHeight to right child of parent
        if(par.right != null)
        	rHeight = par.right.height;
        // get min and max height of the subtrees
    	int max = Math.max(lHeight, rHeight);
    	int min = Math.min(lHeight, rHeight);
    	// if subtrees are the same height return the node that was inserted
        if(max - min == 0) {
        	return i;
        }
        // if sub tree heights arn't equal traverse up the tree
        else if(max - min == 1) {
        	//System.out.println("Advancing up by 1");
        	x = insert;
        	insert = par;
        	par = insert.parent;
        }
        
        else {
        	// if inserted node is parents left child
        	if(insert == par.left) {
        		// perform single rotation LL
        		if(x == insert.left) {
        			Node rTemp = insert.right;
        		    insert.parent = par.parent;
        		    //
        			if(insert.parent != null) {		
        				if(insert.parent.left != null && insert.parent.left == par) {
        					insert.parent.left = insert;
        				}
        				else if(insert.parent.right != null && insert.parent.right == par) {
        					insert.parent.right = insert;
        				}
        			}
        			par.parent = insert;
        			insert.right = par;
        			par.left = rTemp;
        			if(par.left != null) {
        				par.left.parent = par;
        			}
        			par.fixHeight();
        			insert.fixHeight();
        			par = insert.parent;
        			if(par != null)
            			par.fixHeight();
        		}
        		// perform LR rotation on tree
        		else {
        			Node temp2L = x.left;
        			Node temp2R = x.right;
        			x.parent = par.parent;
        			if(x.parent != null) {		
        				if(x.parent.left != null && x.parent.left == par) {
        					x.parent.left = x;
        				}
        				else if(x.parent.right != null && x.parent.right == par) {
        					x.parent.right = x;
        				}
        			}
        			x.left = insert;
        			x.right = par;
        			insert.parent = x;
        			par.parent = x;
        			insert.right = temp2L;
        			if(insert.right != null) {
        				insert.right.parent = insert;
        			}
        			par.left = temp2R;
        			if(par.left != null) {
        				par.left.parent = par;
        			}
        			par.fixHeight();
        			insert.fixHeight();
        			x.fixHeight();
        			insert = x;
        			par = x.parent;
        			if(par != null)
            			par.fixHeight();
        		}
        	}
        	else if(insert == par.right) {
        		// if inserted node is parents r child perform single rotation RR
        		if(x == insert.right) {
        			Node lTemp = insert.left;
        			insert.parent = par.parent;
        			if(insert.parent != null) {		
        				if(insert.parent.left != null && insert.parent.left == par) {
        					insert.parent.left = insert;
        				}
        				else if(insert.parent.right != null && insert.parent.right == par) {
        					insert.parent.right = insert;
        				}
        			}
        			insert.left = par;
        			par.parent = insert;
        			par.right = lTemp;
        			if(par.right != null) {
        				par.right.parent = par;
        			}
        			par.fixHeight();
        			insert.fixHeight();
        			par = insert.parent;
        			if(par != null)
            			par.fixHeight();
        		}
        		// Double rotation (RL)
        		else {
        			
        			Node temp2L = x.left;
        			Node temp2R = x.right;
        			x.parent = par.parent;
        			//if par is x's parents left child assign x to par's position
        			if(x.parent != null) {		
        				if(x.parent.left != null && x.parent.left == par) {
        					x.parent.left = x;
        				}
        				// otherwise assign x to par's postion which is x's parents r child
        				else if(x.parent.right != null && x.parent.right == par) {
        					x.parent.right = x;
        				}
        			}
        			x.left = par;
        			x.right = insert;
        			par.parent = x;
        			insert.parent = x;
        			par.right = temp2L;
        			// restructure par to be parent of tempL node
        			if(par.right != null) {
        				par.right.parent = par;
        			}
        			// restructure insert to parent 
        			insert.left = temp2R;
        			if(insert.left != null) {
        				insert.left.parent = insert;
        			}
        			// call associative methods to fix heights of subtrees
        			par.fixHeight();
        			insert.fixHeight();
        			x.fixHeight();
        			insert = x;
        			par = x.parent;
        			if(par != null)
            			par.fixHeight();
        		}
        	}
        }
    }
    root = insert;
    root.fixHeight();
    
    return i;
  }
}
