/**
 * TODO #1
 */

public class StringMatch {

  /**
   * TODO
   * 
   * Returns the result of running the naive algorithm to match pattern in text.
   */
  public static Result matchNaive(String pattern, String text) { 
	  if(text.length() == 0 && pattern.length() != 0) {
		  return new Result(-1,0);
	  }
	  if(pattern.length() == 0) {
		  return new Result(0,0);
	  }
	  int m = pattern.length(), n = text.length();
	  // create new result to return
	  Result ret = new Result(0,0);
	  int compareNum = 0;
	  int ans = 0, i = 0, j = 0;
	  while (ans <= n - m) {  
		  if (pattern.charAt(i) == text.charAt(j)) {
			  // keep matching     
			  i++;      
			  j++;
			  compareNum += 1;
			  if (i == m) {
				  ret = new Result(ans, compareNum);
				  return ret;    
			  }
		  }
		  else {
			  // slide pattern forward and start over     
			  i = 0;     
			  ans = ans + 1;     
			  j = ans;   
			  compareNum++;
			  }  
		  }
	  ret = new Result(-1, compareNum);
	  return ret;
  }
  
  /**
   * TODO
   * 
   * Populates flink with the failure links for the KMP machine associated with the
   * given pattern, and returns the cost in terms of the number of character comparisons.
   */
  public static int buildKMP(String pattern, int[] flink) {
	  if(flink == null) {
		  throw new IllegalArgumentException();
	  }
	  int j = 0;
	  // set flinks initial values
	  flink[0] = -1;
	  int comparisons = 0;
	  int i = 2;
	  int m = pattern.length();
	  if(m < 1) {
		  return 0;
	  }
	  flink[1] = 0;
	  // while loop to populate flink based on pattern and add the number of comparisons
	  while(i <= m) {
		  j = flink[i - 1];
		  while( j != -1 && pattern.charAt(j) != pattern.charAt(i-1)) {
			  j = flink[j];
			  comparisons++;
		  }
		  if(j != -1 && pattern.charAt(j) == pattern.charAt(i-1)) {
			  comparisons++;
		  }
		  flink[i] = j + 1;
		  i++;
	  }
	    return comparisons;
}
	  
	  

  
  /**
   * TODO
   * 
   * Returns the result of running the KMP machine specified by flink (built for the
   * given pattern) on the text.
   */
  public static Result runKMP(String pattern, String text, int[] flink) {
	  if(pattern.length() == 0) {
		  return new Result(0,0);
	  }
	  
	  else if(text.length() == 0 && pattern.length() != 0) {
		  return new Result(-1,0);
	  }

	  
	  int i = 0;
	  int j = 0;
	  int comparisons = 0;
	  int m = pattern.length();
	  int n = text.length();
	  // for loop to run through text checking for pattern
	  for(i = 0; i <= n; i++) {
		  comparisons++;
		  if(i == n) {
			  return new Result(-1, comparisons - 1);
		  }
		  // changes position of j based on flink
		  while(j > 0 && pattern.charAt(j) != text.charAt(i)) {
			  j = flink[j];
			  comparisons++;
		  }
		  if(pattern.charAt(j) == text.charAt(i)) {
			  j ++;
		  }
		  if(j == m) {
			  return new Result(i-m + 1, comparisons);
		  }
	  }
    return new Result(-1, comparisons);   
  }
  
  /**
   * Returns the result of running the KMP algorithm to match pattern in text. The number
   * of comparisons includes the cost of building the machine from the pattern.
   */
  public static Result matchKMP(String pattern, String text) {
    int m = pattern.length();
    int[] flink = new int[m + 1];
    int comps = buildKMP(pattern, flink);
    Result ans = runKMP(pattern, text, flink);
    return new Result(ans.pos, comps + ans.comps);
  }
  
  /**
   * TODO
   * 
   * Populates delta1 with the shift values associated with each character in the
   * alphabet. Assume delta1 is large enough to hold any ASCII value.
   */
  public static void buildDelta1(String pattern, int[] delta1) {
	  int m = pattern.length();
	  if(delta1 == null) {
		  throw new IllegalArgumentException();
	  }
	  for(int i = 0; i < Constants.SIGMA_SIZE; i ++) {
		  delta1[i] = pattern.length(); // initialize all elements to pattern size
	  }
	  for(int j = 0; j < pattern.length(); j ++) {
		  delta1[pattern.charAt(j)] = m - j - 1; // Last value will be stored
	  }
  }

  /**
   * TODO
   * 
   * Returns the result of running the simplified Boyer-Moore algorithm using the
   * delta1 table from the pre-processing phase.
   */
  public static Result runBoyerMoore(String pattern, String text, int[] delta1) {

	  int comparisons = 0;
	  int n = text.length();
	  int m = pattern.length();
	  if(m == 0) {
		  return new Result(0,0);
	  }
	  if(m > n || n == 0) {
		  return new Result(-1, 0);
	  }
	  int i = m - 1;
	  int j = m - 1;
	  int k = 0;
	  while(i < n) {
		  comparisons++;
		  if(pattern.charAt(j) == text.charAt(i - k)){
			  if(j == 0) {
				  return new Result(i-m + 1, comparisons);
			  }
			  j--;
			  k++;
		  }
		  
		  // this try and catch block catches any emogis in the tweets as those are not in regular ascii value
//		  try{
//			  i += Math.max(1, delta1[text.charAt(i-k)]-k);
//			  k = 0;
//			  j = m-1;
//		  }
//		  catch(ArrayIndexOutOfBoundsException e){
//			  i += Math.max(1, m - k);
//		  }
		  else {
			  i += Math.max(1, delta1[text.charAt(i-k)]-k);
			  k = 0;
			  j = m-1;
		  }
	  }
	  return new Result(-1, comparisons /*comps*/);
  }
  
  /**
   * Returns the result of running the simplified Boyer-Moore algorithm to match 
   * pattern in text. 
   */
  public static Result matchBoyerMoore(String pattern, String text) {
    int[] delta1 = new int[Constants.SIGMA_SIZE];
    buildDelta1(pattern, delta1);
    return runBoyerMoore(pattern, text, delta1);
  }

}
