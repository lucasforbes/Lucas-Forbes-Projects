import java.util.ArrayList;
import java.util.List;

/**
 * TODO #2
 */

public class MatchBot extends TwitterBot {
  /**
   * Constructs a MatchBot to operate on the last numTweets of the given user.
   */
  public MatchBot(String user, int numTweets) {
    super(user, numTweets);
  }
  
  /**
   * TODO
   * 
   * Employs the KMP string matching algorithm to add all tweets containing 
   * the given pattern to the provided list. Returns the total number of 
   * character comparisons performed.
   */
  public int searchTweetsKMP(String pattern, List<String> ans) {
	  	String pat = pattern.toLowerCase();
	  	int m = pattern.length();
	  	
	    int[] flink = new int[m + 1];
	    int comps = StringMatch.buildKMP(pat, flink);
	    for(String tweet: tweets) {
	    	
	    	Result temp = StringMatch.runKMP(pat, tweet.toLowerCase(), flink);
	    	comps += temp.comps;
	    	if(temp.pos != -1) {
	    		ans.add(tweet);
	    	}
	    }
	    return comps;
  }
  
  /**
   * TODO
   * 
   * Employs the naive string matching algorithm to find all tweets containing 
   * the given pattern to the provided list. Returns the total number of 
   * character comparisons performed.
   */
  public int searchTweetsNaive(String pattern, List<String> ans) {
	    int comps = 0;
	    String pat = pattern.toLowerCase();
	    for(String tweet: tweets) {
	    	Result temp = StringMatch.matchNaive(pat, tweet.toLowerCase());
	    	comps += temp.comps;
	    	if(temp.pos != -1) {
	    		ans.add(tweet);
	    	}
	    }
	    return comps;
  }
  // extra test to see if boyer moore algorithm works on tweets
  public int searchBoyerMoore(String pattern, List<String> ans) {
	  	String pat = pattern.toLowerCase();
	  	int m = pattern.length();
	  	int[] delta = new int[Constants.SIGMA_SIZE];
	  	int comps = 0;
	  	StringMatch.buildDelta1(pat, delta);
	    for(String tweet: tweets) {
	    	
	    	Result temp = StringMatch.runBoyerMoore(pat, tweet.toLowerCase(), delta);
	    	if(temp.pos != -1) {
	    		ans.add(tweet);
	    	}
	    	comps += temp.comps;
	    }
	    return comps;
  }
  
  public static void main(String... args) {
    String handle = "acflinch", pattern = "oo";
    MatchBot bot = new MatchBot(handle, 2000);
   
    // Search all tweets for the pattern.
    List<String> ansNaive = new ArrayList<>();
    int compsNaive = bot.searchTweetsNaive(pattern, ansNaive); 
    List<String> ansKMP = new ArrayList<>();
    int compsKMP = bot.searchTweetsKMP(pattern, ansKMP);  
    List<String> ansBM = new ArrayList<>();
    int compsBM = bot.searchBoyerMoore(pattern, ansBM);
    System.out.println("naive comps = " + compsNaive + ", KMP comps = " + compsKMP + ", BM comps = " + compsBM);

    for (int i = 0; i < ansKMP.size(); i++) {
      String tweet = ansKMP.get(i);
      assert tweet.equals(ansNaive.get(i));
      System.out.println(i++ + ". " + tweet);
      System.out.println(pattern + " appears at index " + 
          tweet.toLowerCase().indexOf(pattern.toLowerCase()));
    }
    
    // Do something similar for the Boyer-Moore matching algorithm.
  
  }
}
