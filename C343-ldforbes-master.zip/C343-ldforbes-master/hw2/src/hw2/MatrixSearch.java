package hw2;

/**
 * We implement the search algorithm described in Problem 2.27 of
 * Weiss.
 */

public class MatrixSearch {
  
  /**My run time is O(n) because I first use if/else statements to find the proper column the value may be in
   * I then run a loop on the rows with that column number which only has to run through the loop n times
   * 
   * 
   * Returns true iff val is in the n x n array a. Assume that a is
   * arranged so that the elements in every row are in increasing
   * order from left to right, and the elements in every col are in
   * increasing order from top to bottom. The worst-case running time
   * of this method must be O(n).
   */  
  public static boolean contains(int val, int[][] a) {
	  int column;
	 if(val >= a[0][5]) {
		 column = 5;
	 }
	 else if(val >= a[0][4]) {
		 column = 4;
	 }
	 else if(val >= a[0][3]) {
		 column = 3;
	 }
	 else if(val >= a[0][2]) {
		 column = 2;
	 }
	 else if(val >= a[0][1]) {
		 column = 1;
	 }
	 else {
		 column = 0;
	 }
	  for(int i = 0; i < a[0].length; i++) {
		  if(val == a[i][column]) {
			  return true;
		  }
	  }
    return false;
  }
  
  /**
   * Run some tests.
   */
  public static void main(String... args) {
    int[][] a;
    a = new int[][] {
        new int[] {  2, 14, 26, 37, 43, 51, },
        new int[] {  4, 16, 28, 38, 44, 54, },
        new int[] {  6, 18, 30, 39, 45, 57, },
        new int[] {  8, 20, 32, 40, 46, 60, },
        new int[] { 10, 22, 34, 41, 47, 63, },
        new int[] { 12, 24, 36, 42, 48, 66, },  
        };
    for (int[] row : a)
      for (int x : row)
        assert contains(x, a);
    for (int x = 15; x <= 35; x += 2)
      assert !contains(x, a);
  }
}