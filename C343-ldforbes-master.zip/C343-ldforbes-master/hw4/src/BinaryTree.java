/**
 * Tree interface and BinaryTree class from lec4b.
 */

public class BinaryTree implements Tree {
  
  class Node {
    int data;
    Node left, right;
    
    Node(int key) {
      this(key, null, null);
    }
    
    Node(int data, Node left, Node right) {
      this.data = data;
      this.left = left;
      this.right = right;
    }
    
    boolean isLeaf() {
      return left == null && right == null;
    }
  }
  
  Node root;
  int n;
  
  public void insert(int key) {
    n++;
    if (root == null)
      root = new Node(key);
    else if (root.left == null)
      root.left = new Node(key);
    else if (root.right == null)
      root.right = new Node(key);
    else if (Math.random() < 0.5)
      root = new Node(key, root, null);
    else
      root = new Node(key, null, root);
  }
  
  public boolean contains(int key) {
    return containsHelper(key, root);
  }
  
  private boolean containsHelper(int key, Node p) {
    if (p == null)
      return false;
    if (p.data == key)
      return true;
    return containsHelper(key, p.left) || containsHelper(key, p.right);
  }
  
  public int size() {
    return n;
  }
  
  public static void main(String... args) {
    int[] a = new int[] { 3, 9, 7, 2, 1, 5, 6, 4, 8 };
    BinaryTree tr = new BinaryTree();
    assert tr.isEmpty();
    for (int key : a)
      tr.insert(key);
    assert tr.size() == a.length;
    assert !tr.root.isLeaf();
    for (int key : a)
      assert tr.contains(key);
    try { 
      tr.remove(3);
    }
    catch (UnsupportedOperationException e) {
    }  
    System.out.println("Passed all tests...");
  }

public int pruneLeaves() {
	return pruneHelper(root);
}

public int pruneHelper(Node r) {
	if(r == null) {
		return 0;
	}
	if(root.isLeaf()) {
		root = null;
		return 1;
	}
	else {
		return (pruneHelper(r.left) + pruneHelper(r.right));
	}
}








}

