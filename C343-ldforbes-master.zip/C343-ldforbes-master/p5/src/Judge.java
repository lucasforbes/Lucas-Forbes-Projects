/**
 * This class is used to score alignments. 
 * 
 * TODO: You are to implement the two score() methods.
 * 
 * @author Lucas Forbes
 */

public class Judge {

  public static final int DEFAULT_MATCH_COST = 2;
  public static final int DEFAULT_MISMATCH_COST = -2;
  public static final int DEFAULT_GAP_COST = -1;
  
  private int matchCost, mismatchCost, gapCost;
  
  /**
   * Creates the default judge.
   */
  public Judge() {
    this(DEFAULT_MATCH_COST, DEFAULT_MISMATCH_COST, DEFAULT_GAP_COST);
  }
  
  /**
   * Creates a judge using the specified costs.
   */
  public Judge(int matchCost, int mismatchCost, int gapCost) {
    this.matchCost = matchCost;
    this.mismatchCost = mismatchCost;
    this.gapCost = gapCost;
  }
  
  /**
   * Returns the gap cost used by this judge.
   */
  public int getGapCost() {
    return gapCost;
  }
  
  /**
   * Returns the match cost used by this judge.
   */
  public int getMatchCost() {
    return matchCost;
  }
  
  /**
   * Returns the mismatch cost used by this judge.
   */
  public int getMismatchCost() {
    return mismatchCost;
  }
  
  /**
   * TODO
   * 
   * Returns the score associated with the two characters.
   */
  public int score(char a, char b) {
    if(a == '_' || b == '_' && a != b) {
    	return gapCost;
    }
    else if(a == b) {
    	return matchCost;
    }
    else
    	return mismatchCost;
  }
  
  /**
   * TODO
   * 
   * Returns the score associated with the two strings.
   */
  public int score(String s1, String s2) {
	  int sco = 0;
    for(int i = 0; i < Math.max(s1.length(), s2.length()); i++) {
    	sco += score(s1.charAt(i), s2.charAt(i));
    }
    return sco;
  }
  
  public static void main(String... args) {
	  String x = "ACTA_GC_AC";
	  String y = "AT_CTG_CAC";
	  int scoreCorrect = 0;
	  Judge fudge = new Judge();
	  int check = fudge.score(x, y);
	  System.out.println(check == scoreCorrect);
	  String a = "ACCTG";
	  String b = "ACCTG";
	  int totes = fudge.score(a, b);
	  int totesCorrect = 10;
	  System.out.println(totes == totesCorrect);
	  
  }
}
