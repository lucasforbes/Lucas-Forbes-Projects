import java.util.LinkedList;

public class practice1 {
	
	public static void main(String... args) {
		System.out.println(factorial(4));
		LinkedList<Integer> x = new LinkedList<Integer>();
		x.add(5);
		x.add(8);
		x.add(12);
		System.out.println(sum(x));
	}
	/**
	 * method to compute factorial recursively
	 * @param n int
	 * @return Factorial of the given number
	*/
	int fac;
	public static int factorial(int n) {
		
		if(n <= 1) {
			return 1;
		}
		else {
		int recAnswer = factorial(n-1);	
		return n * recAnswer;
		}
	}
	
	/**
	 * Computes the sum of the given list of numbers recursively
	 * @param nums
	 * @return sum 
	 */
	public static int sum(LinkedList<Integer> nums) {
		if (nums.isEmpty()){
			return 0;
		}
		else {
			int first = nums.removeFirst();
			int sum = sum(nums);
			return first + sum;
		}
	}
}
