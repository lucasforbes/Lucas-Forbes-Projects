import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * TODO: Complete the implementation of this class.
 */

public class FrequencyTable extends HashMap<Character, Integer> {
  /**
   * Constructs an empty table. in the form of a hashmap
   */
  public FrequencyTable() {
    super();
  }
  ArrayList<Character> arraylist = new ArrayList<Character>();;  
  /**
   * TODO: Make use of get() and put().
   * 
   * Constructs a table of character counts from the given text string.
   */
  public FrequencyTable(String text) {
	  //abacca
	  char[] array = text.toCharArray();
	  int length = text.length();
	  int count = 1;
	 
	  for(int i = 0; i < length; i++) {
		  if(get(array[i]) == 0) {
			  for(int j = i + 1; j < length; j++) {
				  if(array[i] == array[j]) {
					  count++;
				  } 
			  }
			  this.put(array[i], count);
			  arraylist.add(array[i]);
		  }
		  count = 1;
		  
	  }
	  //System.out.println(this.toString());

  }
  
  /**
   * TODO
   * 
   * Returns the count associated with the given character. In the case that
   * there is no association of ch in the map, return 0.
   */
  @Override
  public Integer get(Object ch) {
    // if ch is not in map return 0
	  if(this.containsKey(ch) == false) {
		  return 0;
	  }
	  else 
		  return super.get(ch);
  }
  public static void main(String[] args) {
	  FrequencyTable ft = new FrequencyTable("abacca");
  }
}
