import java.util.Arrays;
import java.util.Comparator;
import java.util.Set;

/**
 * TODO: Complete the implementation of this class.
 * 
 * A HuffmanTree represents a variable-length code such that the shorter the
 * bit pattern associated with a character, the more frequently that character
 * appears in the text to be encoded.
 */

public class HuffmanTree {
  
  class Node {
    protected char key;
    protected int priority;
    protected Node left, right;
    
    public Node(int priority, char key) {
      this(priority, key, null, null);
    }
    
    public Node(int priority, Node left, Node right) {
      this(priority, '\0', left, right);
    }
    
    public Node(int priority, char key, Node left, Node right) {
      this.key = key;
      this.priority = priority;
      this.left = left;
      this.right = right;
    }
    
    public boolean isLeaf() {
      return left == null && right == null;
    }

	public int compareTo(Node y) {
		// TODO Auto-generated method stub
		if(this.priority < y.priority) {
			return -1;
		}
		else if(this.priority >= y.priority) {
			return 1;
		}
		return 0;
		
	}
  }
  
  protected Node root;
  
  /**
   * TODO
   * 
   * Creates a HuffmanTree from the given frequencies of letters in the
   * alphabet using the algorithm described in lecture.
   */
  public HuffmanTree(FrequencyTable charFreqs) {
    Comparator<Node> comparator = (x, y) -> {
      /**
       *  TODO: x and y are Nodes
       *  x comes before y if x's priority is less than y's priority
       */
    	// comparator should return -1 if x's priority is less than y
    	// returns 1 if x's priority is greater than y
    	if(x.priority > y.priority) return -1;
    	else if(x.priority == y.priority) return 0;
    	else if(x.priority < y.priority) return 1;
		return -2;
    	
    };  
    Comparator<Node> comp2 = (x, y) -> {
    	if(x.priority > y.priority) return 1;
    	else if(x.priority == y.priority) return 0;
    	else if(x.priority < y.priority) return -1;
		return -2;
    };
    PriorityQueue<Node> forest = new Heap<Node>(comp2);

    /**
     * TODO: Complete the implementation of Huffman's Algorithm.
     * Start by populating forest with leaves.
     */
	root = null;
	Set<Character> keys = charFreqs.keySet();
    for(char c : keys) {
    	forest.insert(new Node(charFreqs.get(c), c, null, null));
    }
    // does the above for loop allow all the individual nodes to be in order based on their priority???
    while(forest.size() != 1) {
    	Node first = forest.delete();
//    	System.out.println("First is: " + first.priority);
    	Node second = forest.delete();
    	System.out.println("Second is: " + second.priority);
    	Node parent = new Node(first.priority + second.priority,first, second);
    	
    	forest.insert(parent);
    	
    	root = forest.peek();
    }
    
  }
  
  /**
   * TODO
   * 
   * Returns the character associated with the prefix of bits.
   * 
   * @throws DecodeException if bits does not match a character in the tree.
   */
  public char decodeChar(String bits) {
	  Node ret = root;
	  if(root.isLeaf()) {
		  return root.key;
	  }
	  char[] arr = bits.toCharArray();
	  
	  while(!ret.isLeaf()) {
		  Node temp;
		  if(arr[0] == '0') {
			  temp = ret.left;
			  ret = temp;
		  }
		  else if(arr[0] == '1') {
			  temp = ret.right;
			  ret = temp;
		  }
		  arr = Arrays.copyOfRange(arr, 1, arr.length);
	  }
	  return ret.key;
  }
    
  /**
   * TODO
   * 
   * Returns the bit string associated with the given character. Must
   * search the tree for a leaf containing the character. Every left
   * turn corresponds to a 0 in the code. Every right turn corresponds
   * to a 1. This function is used by CodeBook to populate the map.
   * 
   * @throws EncodeException if the character does not appear in the tree.
   */
  public String lookup(char ch) {
	  if(search(ch, root) == false) {
		  throw new EncodeException(ch);
	  }
	  else {
		  String x = helper(ch, "");
		  return x;
	  }
	  
	  
  }
  public boolean search(char ch, Node x) {
	  if(x != null) {
		  if(x.key == ch) {
			  return true;
		  }
		  else {
			  boolean find = search(ch, x.left);
			  if(find == false) {
				  find = search(ch, x.right);
			  }
			  return find;
		  }
		 
	  }
	  else {
		  return false;
	  }
  }
  public String helper(char ch, String x) {
	  Node current = root;
	  if(!current.isLeaf()) {
		  if(current.left != null) {
			  Node left = current.left;
			  helper(left.key, x + "0");
			  current = left;
		  }
		  if(current.right != null) {
			  Node right = current.right;
			  helper(right.key, x + "1");
			  current = right;
		  }
	  }
	  return x;
	  
  }
  
  
  
}

