import java.awt.Color;
import java.io.IOException;
import java.util.HashMap;
import java.util.Random;

/**
 * @author Lucas Forbes
 * 
 * A Color entry represents a dictionary of frequency counts, keyed on Color.
 * It is a simplification of Map<Color, Integer>. The size of the key space
 * can be reduced by limiting each Color to a certain number of bits per channel.
 */



public class ColorTable {
  /**
   * Counts the number of collisions during an operation.
   */
  private static int numCollisions = 0;
  
  /** global variables to be used in constructor
   * 
   */
  Assoc[] entry;
  int initialCapacity;
  int bitsPerChannel;
  int collisionStrategy;
  double rehashThreshold;
  int frequency;
  /** global variable used in put to count number of key/value pairs
   * 
   */
  int numPairs;
  

  /**
   * Returns the number of collisions that occurred during the most recent get or
   * put operation.
   */
  public static int getNumCollisions() {
    return numCollisions;
  }

  /**
   * method initializes global variables to values and sets the hashmap to the initial capacity
   * 
   * Constructs a color entry with a starting capacity of initialCapacity. Keys in
   * the color key space are truncated to bitsPerChannel bits. The collision resolution
   * strategy is specified by passing either Constants.LINEAR or Constants.QUADRATIC for
   * the collisionStrategy parameter. The rehashThrehold specifies the maximum tolerable load 
   * factor before triggering a rehash.
   * 
   * Constructor checks if any of the following conditions aren't met and throws exceptions accordingly 
   * @throws RuntimeException if initialCapacity is not in the range [1..Constants.MAX_CAPACITY]
   * @throws RuntimeException if bitsPerChannel is not in the range [1..8]
   * @throws RuntimeException if collisionStrategy is not one of Constants.LINEAR or Constants.QUADRATIC
   * @throws RuntimeException if rehashThreshold is not in the range (0.0..1.0] for a
   *                             linear strategy or (0.0..0.5) for a quadratic strategy
   */
  public ColorTable(int initialCapacity, int bitsPerChannel, int collisionStrategy, double rehashThreshold) { 
	  
		 this.initialCapacity = initialCapacity;
		 this.bitsPerChannel = bitsPerChannel;
		 this.collisionStrategy = collisionStrategy;
		 this.rehashThreshold = rehashThreshold;
		
		 if((initialCapacity) > Constants.MAX_CAPACITY || (initialCapacity < 1))
			 throw new RuntimeException ("Error, Initial Capcity out of range (1-MAXX_CAPACITY");
		 else if (bitsPerChannel > 8 || bitsPerChannel < 1)
		  	 throw new RuntimeException ("Error, bisPerChannel must be in range 1-8");
		 else if (collisionStrategy != Constants.QUADRATIC && collisionStrategy != Constants.LINEAR)
			 throw new RuntimeException ("Error, Collision Strategy must be either LINEAR or QUADRATIC");
		 else if(collisionStrategy == Constants.QUADRATIC)
			 if(rehashThreshold <= 0 && rehashThreshold >= 0.5)
		  			throw new RuntimeException ("Error, RehashThreshold must be in range 0.0-0.5 for Quadratic collision strategy");
		 else if (collisionStrategy == Constants.LINEAR)
			 if(rehashThreshold >= 0 && rehashThreshold <= 1) {
				 throw new RuntimeException ("Error, RehashThreshold must be in range 0.0-1.0 for Linear collision strategy");
			 }
		 entry = new Assoc[initialCapacity];
		 
		 
	  }
		  		
  // inner class creates the key/value pairs in the hashmap
  	class Assoc{
  		
  		Color key;
  		long value;
  		public Assoc(Color key, long val) {
  			this.key = key;
  			this.value = val;
  			}
  		public Assoc() {
  			this.key = null;
  			this.value = 0;
  		}
  	
  }

  /**
   * returns the bitsPerChannel for whichever color table the method is run on
   * 
   * Returns the number of bits per channel used by the colors in this entry.
   */
  public int getBitsPerChannel() {
	
	  return this.bitsPerChannel;
  }

  /**Method traverses through the hashmap, compares the color to keys in the map
   * and returns the frequency if the color is found or 0 if it is not
   * 
   * Returns the frequency count associated with color. Note that colors not
   * explicitly represented in the entry are assumed to be present with a
   * count of zero. Uses Util.pack() as the hash function.
   */
  public long get(Color color) {

	  for(int i = 0; i < entry.length; i++) {
		  if(color == entry[i].key) {
			  return entry[i].value;
		  }
	  }
	  return 0;
  }

  /**
   * put method takes the color and packs it to get a key. the method then takes the key and searches if there
   * is a collision inside the map. if there isn't a collision it places the key value pair into the map. If there is 
   * a collision than it uses linear probing or quadratic probing to hash the value to a key
   * 
   * Associates the count with the color in this entry. Do nothing if count is less than
   * or equal to zero. Uses Util.pack() as the hash function.
   */
  public void put(Color color, long count) {
	  // first step to hash the color
	  int index = Util.pack(color, this.bitsPerChannel);
	  
	  if(entry[index].key == null	) {
		  entry[index].key = color;
		  entry[index].value = count;
		  numPairs += 1;
	  }
	  else {
		  // 
		  if(this.collisionStrategy == Constants.LINEAR) {
			  while(entry[index].key != null) {
				  index = (index + 1) % entry.length;
				  
			  }
			  entry[index].key = color;
			  entry[index].value = count;
			  
		  }
		  else if(this.collisionStrategy == Constants.QUADRATIC) {
			  int i = 1;
			  int start = index;
			  while(entry[index].key != null) {
				  index = (int) ((start + Math.pow(i, 2)) % entry.length);
				  i++;
			  }
			  entry[index].key = color;
			  entry[index].value = count;
		  }
	  }
  }

  /**
   * Increment is called when the color is already inside the map. The method
   * puts the color back into the map just with a value that is 1 greater than before
   * 
   * Increments the frequency count associated with color. Note that colors not
   * explicitly represented in the entry are assumed to be present with a
   * count of zero.
   */
  // would a get key function be helpful for this method?
  
  public void increment(Color color) {
	  // new color -> put
	  put(color, get(color) + 1);
	  // in entry already -> [i].inc() 
	  
  }
  

  /**
   * getLoadFactor method returns the quotient of key/value pairs to the size of the map
   * this method is used to determine whether the map needs to be rehashed
   * 
   * Returns the load factor for this entry.
   */
  public double getLoadFactor() {
    return (getSize()/ getCapacity());
  }

  /**
   * getCapacity shows the size of the entire map
   * 
   * Returns the size of the internal array representing this entry.
   */
  // Figure out function to get hashmap size
  public int getCapacity() {
    return entry.length;
  }

  /**
   * getSize returns the number of key/value pairs in the map
   * 
   * Returns the number of key/value associations in this entry.
   */
  public int getSize() {
    return numPairs;
  }

  /**
   * isEmpty returns whether or not the map is empty
   * 
   * Returns true iff this entry is empty.
   */
  public boolean isEmpty() {
	  if(getSize() == 0) {
		  return true;
	  }
	  else {
		  return false;
	  }
  }

  /**rehash will:
   * @throws RuntimeException if the entry is already at maximum capacity.
   * It then finds the next prime number after doubling the table size
   * after that it copies the global array to a local array called oldArray
   * the global array is then resized to the prime number and the oldArray is 
   * traversed to put the key/value pairs into the global array
   *
   */
  private void rehash() { 
	  
	  if(getCapacity() >= Constants.MAX_CAPACITY) {
		  throw new RuntimeException("Table size too big");
	  }
	  int entryLen = getCapacity();
		  // Create a new double-sized, empty table
	  entryLen = 2 * entryLen + 1;
	  while(Util.isPrime(entryLen) == false && (entryLen - 3) % 4 != 0) {
			   
			   // needs to be in 4j + 3
			   entryLen += 2;
		   }
	  Assoc[] oldArray = entry;
	  entry = new Assoc[entryLen];
	  for(int i = 0; i < getCapacity(); i++) {
		  if(oldArray[i] != null) {
			  put(oldArray[i].key, oldArray[i].value);
		  }
	  }
}


  /**
   * 
   * Returns an Iterator that marches through each color in the key color space and
   * returns the sequence of frequency counts.
   */ 
  public Iterator iterator() {
	  
    return null;
  }

  /**
   * toString method returns key value pairs of all entries 
   * including null entries separated by ||
   * 
   */

  public String toString() {
    String x = "Colors (Keys) || Count (Values) \n";
    for(int i= 0; i < getSize(); i++) {
    	x += (entry[i].key) + " || " + (entry[i].value);	
    }
    return x;
  }

  /**
   * getCountAt returns the frequency of a specific color given the colors index
   * 
   * Returns the count in the entry at index i in the array representing the entry.
   * The sole purpose of this function is to aid in writing the unit tests.
   */
  public long getCountAt(int i) { 
    return entry[i].value;
  }

  /**
   * Simple testing.
   */
  public static void main(String[] args) {
    ColorTable table = new ColorTable(3, 6, Constants.QUADRATIC, .49);
    int[] data = new int[] { 32960, 4293315, 99011, 296390 };
    for (int i = 0; i < data.length; i++) 
      table.increment(new Color(data[i]));
    System.out.println("capacity: " + table.getCapacity()); // Expected: 7
    System.out.println("size: " + table.getSize());         // Expected: 3
    
    /* The following automatically calls entry.toString().
       Notice that we only include non-zero counts in the String representation.
       
       Expected: [3:2096,2, 5:67632,1, 6:6257,1]
       
       This shows that there are 3 keys in the entry. They are at positions 3, 5, and 6.
       Their color codes are 2096, 67632, and 6257. The code 2096 was incremented twice.
       You do not have to mimic this format exactly, but strive for something compact
       and readable.
       */
    System.out.println(table);  
  }
}
