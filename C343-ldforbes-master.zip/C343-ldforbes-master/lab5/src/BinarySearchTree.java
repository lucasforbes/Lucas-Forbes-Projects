/**
 * Starter code for lab5. This is an implementation of BinarySearchTree 
 * for int data.
 * 
 * Implement the remove() method using the algorithm described by your AI.
 *
 * @author Lucas Forbes
 */

public class BinarySearchTree implements Tree {

  class Node {
    int data;
    Node left, right;

    Node(int key) {
      this(key, null, null);
    }

    Node(int data, Node left, Node right) {
      this.data = data;
      this.left = left;
      this.right = right;
    }

    boolean isLeaf() {
      return left == null && right == null;
    }
  }
  public Node getParent(int key) {
	  return getParentHelper(key, root);
  }
  public Node getParentHelper(int key, Node p) {
	  if(p.right != null && key == p.right.data) {
		  return p;
	  }
	  if(p.left != null && key == p.left.data) {
		  return p;
	  }
	  if(key == p.right.data || key == p.left.data){
		  return p;
	  }
	  else if(key < p.data)
		  return getParentHelper(key, p.left);
	  return getParentHelper(key, p.right);
  }
  
  public Node getNode(int key) {
	  return getNodeHelper(key, root);
  }
  
  public Node getNodeHelper(int key, Node p) {
	  if(key == p.data)
		  return p;
	  else if(key < p.data)
		  return getNodeHelper(key, p.left);
	  return getNodeHelper(key, p.right);
  }
  
  public int findLeftMost(Node l) {
	  int minKey = root.data;
	  while (root.left != null)
	  {
	      minKey = root.left.data;
	      root = root.left;
	  }
	  return minKey;
  }
 

  Node root;
  int n;

  /**
   * TODO
   * 
   * Removes the key from this tree. Must run in O(h) time, where h
   * is the height of the tree.
   */
  public void remove(int key)
  {
      root = removeHelper(root, key);
  }

  // A recursive function to insert a new key in BST 
  Node removeHelper(Node p, int key)
  {
      // Base Case: If the tree is empty 
      if (p.isLeaf()) {
    	  return null;
      }

      // Otherwise, recur down the tree 
      if (key < root.data)
          p.left = removeHelper(p.left, key);
      else if (key > root.data)
          p.right = removeHelper(p.right, key);

      // if key is same as root's key, then This is the node
      // to be deleted
      else
      {
          // node with only one child or no child
          if (p.left == null)
              return p.right;
          else if (p.right == null)
              return p.left;

          // node with two children: Get the inorder successor (smallest
          // in the right subtree)
          p.data = findLeftMost(p);

          // Delete the inorder successor
          p.right = removeHelper(p.right, p.data);
      }

      return p;
  }

  /**
   * Inserts the key into this tree. Runs in O(h) time, where h is
   * the height of the tree.
   */
  public void insert(int key) {
    n++;
    root = insertHelper(key, root);
  }

  private Node insertHelper(int key, Node p) {
    if (p == null) 
      p = new Node(key);
    else if (key < p.data)
      p.left = insertHelper(key, p.left);
    else 
      // if keys are unique, it must be the case that key > p.data
      p.right = insertHelper(key, p.right);
    return p;
  }

  /**
   * Returns true iff key is in this tree. Runs in O(h) time, where h is
   * the height of the tree.
   */
  public boolean contains(int key) {
    return containsHelper(key, root);
  }

  private boolean containsHelper(int key, Node p) {
    if (p == null)
      return false;
    if (key == p.data)
      return true;
    if (key < p.data)
      return containsHelper(key, p.left);
    return containsHelper(key, p.right);
  }
  public void printTree(Node p){
	  System.out.println(p.data + " ");
	  if(p.left != null) {
		  printTree(p.left);
	  }
  }

  /**
   * Returns the number of keys in this tree.
   */
  public int size() {
    return n;
  }

  /**
   * Testing.
   */
  public static void main(String... args) {
    int[] a = new int[] { 3, 9, 7, 2, 1, 5, 6, 4, 8 };
    int[] b = new int[] { 1, 6, 4, 5, 8, 9, 7, 2 };
    Tree bst = new BinarySearchTree();
    Tree bstB = new BinarySearchTree();
    assert bst.isEmpty();
    assert bstB.isEmpty();
    for (int key : a)
      bst.insert(key);
    for (int key : b)
        bstB.insert(key);
    assert bst.size() == a.length;
    for (int key : a)
      assert bst.contains(key);
    bst.remove(3);
    for (int key : b)
      assert bstB.contains(key);
    assert !bst.contains(3);
    int n = bst.size();
    for (int key : b) {
      assert bst.contains(key);
      bst.remove(key);
    assert !bst.contains(key);
      n--;
      assert n == bst.size();
    }
    assert bst.isEmpty();
    System.out.println("Passed all the basic tests...");

    /**
     * TODO: As a challenge, arrange things so that attempts to remove
     * key that are not in the tree are simply ignored (and do no harm).
     */
    for (int key : a)
      bst.insert(key);
    n = bst.size();
    for (int key : a) {
      bst.remove(-key);
      assert n == bst.size();
    }
    System.out.println("Passed challenge tests...");
  }
}

interface Tree {
  void insert(int key);
  default void remove(int key) {
    throw new UnsupportedOperationException();
  }
  boolean contains(int key);
  int size();
  default boolean isEmpty() {
    return size() == 0;
  }
}

