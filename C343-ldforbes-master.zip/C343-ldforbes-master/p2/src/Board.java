import java.awt.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * A Board represents the current state of the game. Boards know their dimension, 
 * the collection of tiles that are inside the current flooded region, and those tiles 
 * that are on the outside.
 * 
 * @author <Lucas Forbes>
 */

public class Board {
  private Map<Coord, Tile> inside, outside;
  private int size;
  
  /**
   * Constructs a square game board of the given size, initializes the list of 
   * inside tiles to include just the tile in the upper left corner, and puts 
   * all the other tiles in the outside list.
   */
  public Board(int size) {
    // A tile is either inside or outside the current flooded region.
    inside = new HashMap<>();
    outside = new HashMap<>();
    this.size = size;
    for (int y = 0; y < size; y++)
      for (int x = 0; x < size; x++) {
        Coord coord = new Coord(x, y);
        outside.put(coord, new Tile(coord));
      }
    // Move the corner tile into the flooded region and run flood on its color.
    Tile corner = outside.remove(Coord.ORIGIN);
    inside.put(Coord.ORIGIN, corner);
    flood(corner.getColor());
  }
  
  /**
   * Returns the tile at the specified coordinate.
   */ 
  public Tile get(Coord coord) {
    if (outside.containsKey(coord))
      return outside.get(coord);
    return inside.get(coord);
  }
  
  /**
   * Returns the size of this board.
   */
  public int getSize() {
    return size;
  }
  
  /**
   * @param none
   * @return boolean
   * function: traverses through the entire size of the board at all possitions 
   * to check if they are in the inside hashmap
   * 
   * Returns true iff all tiles on the board have the same color.
   */
  public boolean fullyFlooded() {
	  for(int i = 0; i < this.getSize(); i++) {
		  for(int j = 0; j < this.getSize(); j++) {
			  if(inside.containsKey(new Coord(i,j))) {
				  continue;
			  }
			  else {
				  return false;
			  }
		  }
	  }
    return true;
  }
  
  /**
   * TODO
   * @param Color taken from the mouselistener
   * @return void
   * function: this method updates the hashmaps inside and outside depending on which color was clicked.
   * the board will then update to include regions with similar colors
   * Updates this board by changing the color of the current flood region 
   * and extending its reach.
   */
  public void flood(WaterColor color) {
// go through key sets
	  int oldSize = inside.size();
	  while(true) {
		  // set to traverse through all Coords in inside hashmap
		  Set<Coord> insideKeys = inside.keySet();
		  // set to add all neighbors that need to be updated to the color
		  Set<Coord> updateKeys = new HashSet<Coord>();
		  //enhanced loop to go through inside Coords
		  for(Coord a : insideKeys) {
			// set color of each inside tile to color
			  inside.get(a).setColor(color);
			// go through neighbors of each key
			  for(Coord n : a.neighbors(getSize())) {
				  //check if neighbors are in outide and are the color we're looking for
				  if(outside.containsKey(n)) {
					  	if(outside.get(n).getColor().equals(color)) {
					  		// if key is the correct color add it to keys that need to be updated
						  updateKeys.add(n);
					  }
				  }
				  
			  }
		  }
		  // loop to update keys
		  for(Coord x : updateKeys) {
			  inside.put(x , outside.get(x));
			  outside.remove(x);
			  inside.get(x).setColor(color);
		  }
		  // condition to see if anything was updated
		  if(inside.size() == oldSize)
			  break;
		  oldSize = inside.size();
	  }
	  
  }
  public int testFlood(WaterColor color) {
	  int oldSize = inside.size();
	  int size = inside.size();
	  while(true) {
		  Set<Coord> insideKeys = inside.keySet();
		  Set<Coord> updateKeys = new HashSet<Coord>();
		  //have a set
		  for(Coord a : insideKeys) {
			// go through neighbors of each key
			  //inside.get(a).setColor(color);
			  for(Coord n : a.neighbors(getSize())) {
				  if(outside.containsKey(n)) {
					  	if(outside.get(n).getColor().equals(color)) {
						  updateKeys.add(n);
					  }
				  }
				  
			  }
		  }
		  for(Coord x : updateKeys) {
			  size++;
			  /*inside.put(x , outside.get(x));
			  outside.remove(x);
			  */
		  }
		  if(inside.size() == oldSize)
			  break;
		  oldSize = inside.size();
	  }
	  return size;
  }
  /**
   * TODO
   * 
   * Explore a variety of algorithms for handling a flood. Use the same interface 
   * as for flood above, but add an index so your methods are named flood1,
   * flood2, ..., and so on. Then, use the batchTest() tool in Driver to run game
   * simulations and then display a graph showing the run times of all your different 
   * flood functions. Do not delete your flood code attempts. For each variety of 
   * flood, including the one above that you eventually settle on, write a comment
   * that describes your algorithm in English. For those implementations that you
   * abandon, state your reasons.
  */
  
  public void flood1(WaterColor color) {
	  int oldSize = inside.size();
	  while(true) {
		  Set<Coord> insideKeys = inside.keySet();
		  ArrayList<Coord> updateKeys = new ArrayList<Coord>();
		  //have a set
		  for(Coord a : insideKeys) {
			// go through neighbors of each key
			  inside.get(a).setColor(color);
			  for(Coord n : a.neighbors(getSize())) {
				  if(outside.containsKey(n)) {
					  	if(outside.get(n).getColor().equals(color)) {
						  updateKeys.add(n);
					  }
				  }
				  
			  }
		  }
		  for(Coord x : updateKeys) {
			  inside.put(x , outside.get(x));
			  outside.remove(x);
			  inside.get(x).setColor(color);
		  }
		  if(inside.size() == oldSize)
			  break;
		  oldSize = inside.size();
	  }
  }
  /*
  public void flood2(WaterColor color) {
    
  }
   */
  
  /**
   * TODO
   * 
   * Returns the "best" GameColor for the next move. 
   * 
   * The algorithm for suggest creates 5 integers that are created from using the testFlood method
   * the method returns the number of tiles in the inside hashmap after its specific color is tried.
   * The algorith then places the integers in an arraylist and finds the maximum integer. It then returns the 
   * color associated with the greatest increase in tiles. The algorithm is fairly slow because it has to run test flood
   * on each color, however it is very accurate.
   */
  public WaterColor suggest() {
    WaterColor cornerColor = inside.get(Coord.ORIGIN).getColor();

    int blueTry = testFlood(WaterColor.BLUE);
    int redTry = testFlood(WaterColor.RED);
    int pinkTry = testFlood(WaterColor.PINK);
    int cyanTry = testFlood(WaterColor.CYAN);
    int yellowTry = testFlood(WaterColor.YELLOW);
    
    ArrayList colorSizes = new ArrayList();
    colorSizes.add(blueTry);
    colorSizes.add(redTry);
    colorSizes.add(pinkTry);
    colorSizes.add(cyanTry);
    colorSizes.add(yellowTry);
    
    int greatest = (int) Collections.max(colorSizes);
    if(greatest == blueTry)
    	return WaterColor.BLUE;
    else if(greatest == redTry)
    	return WaterColor.RED;
    else if(greatest == pinkTry)
    	return WaterColor.PINK;
    else if(greatest == cyanTry)
    	return WaterColor.CYAN;
    else
    	return WaterColor.YELLOW;
  }
  
  /**
   * Returns a string representation of this board. Tiles are given as their
   * color names, with those inside the flooded region written in uppercase.
   */ 
  public String toString() {
    StringBuilder ans = new StringBuilder();
    for (int y = 0; y < size; y++) {
      for (int x = 0; x < size; x++) {
        Coord curr = new Coord(x, y);
        WaterColor color = get(curr).getColor();
        // what is this line doing???
        ans.append(inside.containsKey(curr) ? color.toString().toUpperCase() : color);
        ans.append("\t");
      }
      ans.append("\n");
    }
    return ans.toString();
  }
  
  /**
   * Simple testing.
   */
  public static void main(String... args) {
    // Print out boards of size 1, 2, ..., 5
	  int n = 5;
    Board x = new Board(n);
    for (int size = 1; size <= n; size++) {
      Board someBoard = new Board(size);
      System.out.println(someBoard);
    }
  }
}






