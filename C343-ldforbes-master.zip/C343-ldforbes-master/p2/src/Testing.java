import static org.junit.Assert.*;

import java.awt.Color;
import java.awt.List;
import java.util.ArrayList;
import java.util.Map;

import org.junit.Test;

/**
 * JUnit tests for all TODO methods.
 */

public class Testing {
	  // test onBoard
  @Test
  public void testOnBoard() {
    assertFalse(new Coord(3, 4).onBoard(4));
    assertTrue(new Coord(3, 4).onBoard(5));
  }
  // test flood
 @Test
  public void testFlood() {
	  Board x = new Board(5);
	  x.flood(WaterColor.BLUE);
	  WaterColor origin = x.get(new Coord(0,0)).getColor();
	  assertEquals(origin, WaterColor.BLUE);
  }
 // test suggest
 @Test
 public void testSuggest() {
	 Board y = new Board(2);
	 y.flood(WaterColor.BLUE);
	 WaterColor choice = y.suggest();
	 assertNotEquals(choice, WaterColor.BLUE);
 }
  //test neighbors function here
@Test
 public void testNeighbors() {
	 Coord z = new Coord(0,0);
	 ArrayList<Coord> n = new ArrayList<Coord>();
	 n.add(new Coord(1,0));
	 n.add(new Coord(0,1));
	 assertEquals(z.neighbors(3), n);
 }
 
  // test fullyFlooded
 @Test 
 public void testFullyFlooded() {
	 Board test = new Board(1);
	 assertTrue(test.fullyFlooded());
	 
	 Board test2 = new Board(5);
	 assertFalse(test2.fullyFlooded());
 }
  // test flood2
  
  
  // test hashcode
  @Test
  public void testHashcode() {
	  int val = new Coord(1,2).hashCode();
	  assertEquals(val, 10);
  }


}