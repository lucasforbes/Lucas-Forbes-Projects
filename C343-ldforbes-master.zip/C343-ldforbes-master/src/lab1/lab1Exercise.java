package lab1;

public class lab1Exercise {

	public static int search(int[] A, int[] B) {
		int placeA = 0;
		int placeB = 0;
		int aLengeth = A.length;
		while(placeB <= B.length -1) {
			//System.out.println("place a:" + placeA + " place B:" + placeB);
			if(A[placeA] == B[placeB] && A[placeA + 1] == B[placeB + 1]) {
					return placeB;
				}
				else if(placeB == B.length-1){
					placeA += 1;
					placeB = 0;
				}
				else {
					placeB++;
				}
		}
		return -1;
	}
	
	
	public static void main(String args[]){
		int[] A = {2,4};
		int[] B	= {5,1,8,76,2,4,67,9,12,19};
		System.out.println(search(A,B));
	}
}
