/**@author Lucas Forbes
 * Tree interface and BinaryTree class from lec4b.
 */

public class BinaryTree implements Tree {
  
  class Node {
    int data;
    Node left, right;
   /* 
    * Node constructor if key is only given 
    */
    Node(int key) {
    	/*
    	 * calls full constructor with null values for leaf nodes
    	 */
      this(key, null, null);
    }
    /*
     * Node constructor when data, left, and right nodes are given
     */
    Node(int data, Node left, Node right) {
      this.data = data;
      this.left = left;
      this.right = right;
    }
    /*
     * @param none
     * @return returns a boolean value
     * Function: checks if Node has empty left and right leaf nodes 
     */
    boolean isLeaf() {
      return left == null && right == null;
    }
  }
  /*
   * global root variable and number of node variable
   */
  Node root;
  int n;
  /*
   * @param takes in trees key value
   * @return nothing
   * function: takes in a key and uses the value to place into binary tree at correct location
   * @see Tree#insert(int)
   */
  public void insert(int key) {
    n++;
    if (root == null)
      root = new Node(key);
    else if (root.left == null)
      root.left = new Node(key);
    else if (root.right == null)
      root.right = new Node(key);
    else if (Math.random() < 0.5)
      root = new Node(key, root, null);
    else
      root = new Node(key, null, root);
  }
  
  /* 
   * @param int key
   * @return boolean value
   * function: if the tree contains the key returns true
   * @see Tree#contains(int)
   */
  public boolean contains(int key) {
    return containsHelper(key, root);
  }
  /*
   * @param int key, Node p
   * @return boolean value 
   * function: helper method to traverse through tree checking left and right nodes of 
   * each value for the entered key
   */
  private boolean containsHelper(int key, Node p) {
    if (p == null)
      return false;
    if (p.data == key)
      return true;
    return containsHelper(key, p.left) || containsHelper(key, p.right);
  }
  /*
   * @param none
   * @return integer
   * function: gives trees size
   * (non-Javadoc)
   * @see Tree#size()
   */
  public int size() {
    return n;
  }
/*
 * @param none
 * @return integer
 * function: calls heightHelper to get height of tree
 */
  public int getHeight() {
	  return heightHelper(root);
	  }
  /*
   * @param Node p
   * @return integer
   * function: traverses through each level recursively calling itself
   * adding 1 each level
   */
  public int heightHelper(Node p) {
	  if (p == null)
		  return 0;
	  return 1 + Math.max(heightHelper(p.left),heightHelper(p.right));}
  /*
   * function: main method creates tree and runs tests on it
   */
  public static void main(String... args) {
    int[] a = new int[] { 3, 9, 7, 2, 1, 5, 6, 4, 8 };
    BinaryTree tr = new BinaryTree();
    assert tr.isEmpty();
    for (int key : a)
      tr.insert(key);
    assert tr.size() == a.length;
    assert !tr.root.isLeaf();
    for (int key : a)
      assert tr.contains(key);
    int[] t = new int[] { 3, 9, 1, 5, 6, 4, 8, };
    BinaryTree test = new BinaryTree();
    assert test.isEmpty();
    for(int x: t)
    	test.insert(x);
    // test remove method by removing every 3rd value
    try {
    	test.remove(4);
    	test.remove(9);
    }
    catch (UnsupportedOperationException e) {
    } 
    try { 
      tr.remove(3);
    }
    catch (UnsupportedOperationException e) {
    }  
    System.out.println("The height of the first tree is: " + tr.getHeight()+ "\n");
    System.out.println("The number of elements entered into the first tree is: " + tr.size() + "\n");
    System.out.println("The number of elements entered into the tree is: " + test.n + "\n");
    System.out.println("The test tree contains the number 4: " + test.contains(8));
    System.out.println("Passed all tests...");
  }
}
// interface Tree for Binarytree to implement
interface Tree {
  void insert(int key);
  default void remove(int key) {
    throw new UnsupportedOperationException();
  }
  boolean contains(int key);
  int size();
  default boolean isEmpty() {
    return size() == 0;
  }
}

