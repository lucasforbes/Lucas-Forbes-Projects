/* hw2 
name: Lucas Forbes
date: 08/29/18
*/
#include <stdio.h>
#include <stdlib.h>

int rect(){
	return 0;
}

int circ(){
	printf("Circle Works!");
	menu();
	return 0;
}

int star(){
	 return 0;
}

int tri(){
	 return 0;
}

int umb(){
	 return 0;
}
int menu(){
	char input;	
 	printf("Please enter R for a rectangle, \n");
        printf("Please enter C for a circle, \n");
        printf("Please enter S for a star, \n");
        printf("Please enter T for a triangle, \n");
        printf("Please enter U for an umbrella, \n");
        printf("Or enter E to exit, \n");
	scanf("%c", &input);
        if(input == 'R' || input == 'r'){
                rect();
        }
        else if(input == 'C' || input == 'c'){
                circ();
        }
        else if(input == 'S' || input == 's'){
                star();
        }
	else if(input == 'T' || input == 't'){
                tri();
        }
        else if(input == 'U' || input == 'u'){
                umb();
        }
        else if(input == 'E' || input == 'e'){
                void exit(int status);
        }
        else{
		printf("Oops that's not a correct command. Please try again");
                menu();
        }


	return 0;
}
int main(){
	menu();
	return 0;
}
