# 1.  Consider the Vocab.csv data on Canvas (in the data folder), containing the number of years of education and the performance on a vocabulary test 
#     for a number of individuals.  For this problem we want to perform simple linear  regression  by  modeling  the  relationship  between  the  response  
#     (the  test  score)  and  the  predictor  (the education level).  As with the simple linear regression done in class, case we want to model yi???axi+b
#     However, we want to do this according to the generic method for regression presented in class in which we solve the normal equations, XtX??=Xty
#     using an appropriate choice ofXmatrix.
#   (a)  In R, read in the data and create the X matrix that would be appropriate for estimating a and b.

temp = read.csv("C:\\Users\\Ldforbes\\Documents\\B365\\Vocab.csv")

X = temp[,4] #education
y = temp[,5] #vocab
n = length(X)
#   (b)  Solve the normal equations with your choice of X and report the values you get for a and b.
a = solve(t(X) %*% X, t(X) %*% y)

xbar = sum(X)/n;	  # we derived our optimal choice for alpha and beta in terms of these
ybar = sum(y)/n;
xybar = sum(X*y)/n
xsqbar = sum(X*X)/n

b = (ybar*xsqbar-xbar*xybar)/ (xsqbar - xbar*xbar)  # from our calculations
plot(X,y, xlab = "education", ylab = "vocab")
abline(b,a)
cat("a value: ", a, ", b value: ", b)

#   (c)  Does it appear that people with more education tend to have larger vocabularies?
#        There is a positive slope in relation to vocabulry to education level so yes, it does appear that people with more education tend to have larger vocabularies?

#   (d)  It is usually hard to make quantitative statements about the value of a year of education, however, you can do so here in the context of this 
#        particulary vocabulary test.  Make such a quantitative statement here.
#         There is a very small increase in vocabulary score that goes along with an extra year of education. A extra year only increases
#         your vocab score by around a half a point.


# 2.  This  problem  deals  with  the  ais.csv  data  (also  in  the  Canvas  data  folder) describing  various  measurementstaken on a collection of 
#     Austrailian athletes.  These data can be read in using the command  (unlike  previous  datasets where  we  have  used  "read.csv2").   For  each  athlete,  
#     the  data  contain  anumber of numeric variables we will consider, though we will ignore the gender and sport variables.  We areinterested in trying 
#     to predict the red blood cell count (rcc) from the other numeric variables.
dat = read.csv("C:\\Users\\Ldforbes\\Documents\\B365\\ais.csv")
#   (a)  In  R,  create  theXmatrix  using  variables  3  through  12  as  the  predictors,  while  creating  the  responsevariable  from  the  2nd  variable,  
#        rcc.   Solve  the  normal  equations  and  report  the  values  you  get  for  theregression coefficients.
X = as.matrix(dat[,3:12])
rcc = dat[,2]
a = solve(t(X) %*% X, t(X) %*% rcc) 
cat(a, '\n')          #vector with optimal coefficients for prediction y from x
#   (b)  Compute your predicted values of the rcc level, ^y, the errors (e=y???^y), and the give the sum of squarederrors (sse) , defined by???ie2i.
yhat = X %*% a # our predictions of y values
error = rcc - yhat
sumSqEr = sum(error*error)
cat(sumSqEr, '\n')

#   (c)  In a loop, perform a regression by omitting a single variable from the collection of predictors used above.The first time through the loop you should 
#        omit variable 3, the 2nd time through the loop you shouldinclude 3 but omit 4, etc.  In each case compute your sum of squared errors.  
#        Which variable's omission causes the greatest increase in sse?  Which variable appears to be the most important in predicting rcc?
n = nrow(X)
for(i in 1:12){
  #May need to change
  X = as.matrix(dat[,3:12])
  X = X[,-i]
  z = solve(t(X) %*% X, t(X) %*% rcc)
  yhat = X %*% z
  er = rcc - yhat
  sumSqEr = sum(er*er)
  cat("We get a sum squared error of: ", sumSqEr, " without ", i + 2, " variable", "\n")
}
# WCC sum squared error of:  5.910028  
# HC sum squared error of:  8.518492  
# HG sum squared error of:  5.942013  
# FERRsum squared error of:  5.909733  
# BMI sum squared error of:  5.961539  
# SSF sum squared error of:  6.021431  
# PCBFAT sum squared error of:  5.919325  
# LBM sum squared error of:  5.916463 
# HT sum squared error of:  5.927754  
# WT sum squared error of:  5.914183  
# SEX sum squared error of:  5.909294  
# SPORT sum squared error of:  5.909294 

# 3.  This problem uses the Nottingham beer sales data which you can include into your R program with
data(nottem)
y = nottem
n = length(y)
x = 1:n;
plot(nottem)
#        Here y is a vector containing the montly beer sales from the Nottingham company for 20 consecutive years(n= 240 months), numbered by the vector x.
#   (a)  Plot the sales data for the various months using both lines and points, as below

par(mar=c(1,1,1,1))
plot(x,y,type="b")  # b is for "both"

#   (b)  Construct the X  matrix for simple linear regression (yi???axi+b) and solve for a and b.  Plot the resulting line on top of the original plot.1
# first attempt
X = as.matrix(nottem)
lmfit1 <- lm(y ~ x)
abline(lmfit1)
print(summary(lmfit1))

# second attempt
xb = sum(x) / n
yb = sum(y) / n
xyb = sum(x * y) / n
xsqbar = sum(x * x) / n

b = (yb * xsqbar - xb * xyb) / (xsqbar - xb*xb)
a = (yb - b) / xb
abline(b,a)

#   (c)  Of course the linear model has no chance to capture the seasonal pattern of sales.  We will model this periodic component by including a sine wave 
#        and a cosine wave, both n points long, oscillating with 12 points per period (there are 12 months in a year).  Specifically, we use the model:
#                     yi???acos(2??xi/12) +bsin(2??xi/12) +c
#        Find the values for a,b,c that minimize the sum of squared errors in predicting the{yi}.  Plot your fitted model 
#        on the same plot as the original data, using a different color for each.  Be sure to use both lines and points in your plot.
yi = rep(0,240)

for(i in c(1:240)){
  yi[i] = a * cos((2 * pi * x[i]) / 12) + b * sin((2 * pi * x[i]) / 12) + c # where is c?
}

#   (d)  The company hopes that, in addition to the obvious seasonal pattern, their sales grow over time.  Consider the model
#                     yi???acos(2??xi/12) +bsin(2??xi/12) +c+dxi 
#        that acconts for a possible linear trend in sales.  Fit this model to that data and plot the fitted results 
#        as you did in the previous part, showing both original data and fitted model.  Do the results suggest thatthe company is experiencing growth in sales?  
#        Explain your answer in terms of the estimated regression coefficients.
for(i in c(1:240)){
  yi[i] = a * cos((2 * pi * x[i]) / 12) + b * sin((2 * pi * x[i]) / 12) + c  + (d * x[i]) # where is c and d?
}

# 4.  Consider the AirPassengers dataset that can be imported to R as usual, that is data(AirPassengers) Note that both the average number of passengers as well 
#     as the size of seasonal fluctuations grow over time.
#   (a)  Plot the log of the number of passengers for each month and, from this plot, propose a model for the log data along the lines of regression.
data(AirPassengers)
air = AirPassengers
plot(AirPassengers, ylab = "Passengers (1000s)", type = "o", pch = 20)


#   (b)  Fit your model to the log data and plot your fitted model on this same graph as the log data.
plot(log(AirPassengers)) 
time = time(AirPassengers)

xb = sum(x) / n
yb = sum(y) / n
xyb = sum(x * y) / n
xsqbar = sum(x * x) / n


b = (yb * xsqbar - xb * xyb) / (xsqbar - xb*xb)
a = (yb - b) / xb

#   (c)  Plot  both  the  original  data  and  the  fitted  model  in  the  non-log-tranformed  domain  -  that  is,  in  theoriginal form.

abline(b,a)
cat("A and B are: ", a, b, "\n")

