#1.  Suppose you have an n�d R matrix,X, of predictor variables and a response n-vector,y.  Backward selction is the mirror image of the forward 
#     selection procedure for choosing which variables you will use.  The first iteration of the algorithm removes the variable so that regression 
#     using the remaining variables gives the smallest SSE(sum of sqared errors).  This variable will not be used for the remainder of the algorithm.  
#     The next iterationremoves an additional variable so that the remaining variables give the smallest SSE. The algorithm continuesin the fashion 
#     until only one variable is left.Implement the backward selection algorithm in R, printing out at each iteration the variable you are removingand 
#     the resulting SSE of your current collection of variables.  You may assume that both n and d are variables in R that are at your disposal.
# n = 10;
# d = 10
# X = matrix(rnorm(n*d),ncol=n);
# for(i in 0:n){
#   X = as.matrix(X[i:n,i:d])
#   y = rnorm(n-i)
#   a = solve(X,y);
#   e = y - X %*% a;
#   cat("sum sq error without variable ", i , " is ", sum(e*e), "\n");
# }


n = 100
d = 100;
X = matrix(rnorm(n*d),nrow = n, ncol=d);
y = X %*% rnorm(n);

used = rep(FALSE,d);		# initially all varaibles available for selection
var = rep(0,d);			# var[j] will be variable chosen in jth round
bestsse = rep(10000000,d);      # bestsse[j] will be best sse from jth round
for (j in 1:d)  {		# choose 1 variable each time through this loop
  for (i in which(used == FALSE)) {
    used[i] = TRUE;
    XX = X[,used];		# take the "used" columns = used variables
    a = solve(t(XX) %*% XX , t(XX) %*% y);
    yhat = XX %*% a;
    error = y-yhat;
    sse = sum(error*error);

    if (sse < bestsse[d-j+1]) {	# if we find a better sse, take it
      bestsse[d-j+1] = sse;
      var[d-j+1] = i;
    }
    used[i] = FALSE;
  }
  cat("sum sq error without variable ", d-j+1 , " is ", sse,'\n')
  used[var[d-j+1]] = TRUE;	 # claim the best variable for future iterations of loop
  cat("The next best variable for future iterations when removing variable ", d-j+1 , " is ", var[d-j+1],'\n')
}
plot(bestsse)


#2.  Suppose our data set is given by{(0,1)t,(1,1)t,(0,2)t,(1,2)t,(0,3)t,(1,3)t}and we begin with m1= (0,1)t and m2= (0,2)t as our initial configuration.
#   (a)  Construct the initial partition of the data constructed by the K-means algorithm and give the mean for each set in the partition.
#         m1= (0,1)t and m2= (0,2)t as our initial configuration.
# data = {(0,1),(1,1),(0,2),(1,2),(0,3),(1,3)}
# m1 = (0,1)
# m2 = (0,2)
# m1Cluster = {(0,1), (1,1)}
# m2Cluster = {(0,2),(1,2),(0,3),(1,3)}
# m1Mean = (.5, 1)
# m2Mean =(.5, 2.5)

#   (b)  Working  from  the  mean  values  you  constructed  in  the  previous  part,  compute  the  partition  and  mean values for the 2nd iteration 
#         of the algorithm.
# m1Mean = (.5, 1)
# m2Mean =(.5, 2.5)

#   (c)  Carry the algorithm through to completion giving the final resulting clusters and mean values.
# m1Mean = (.5, 1)
# m2Mean =(.5, 2.5)

# this gives us an H val of 
#(0.5)^2 + (0.5)^2+ (0.25)^2 + (0.25)^2 + (0.25)^2 + (0.25)^2 = 2.5


#   (d)  How can you tell that you have reached the terminal point of the algorithm?
# there are a few ways you can tell that you have reached the terminal point of the algorithm. First, the datapoints assigned to specific clusters remain
# the same (takes too much time), second, Centroids remain the same (time consuming), third, the distance of datapoints from their centroid is minimum 
# (compared to some thresholdd)

#3.  Let x1, . . . , xn be a collection of numbers and consider H(m) =???ni=1(xi???m)2 for an unknown number m.We can minimize this function by differentiating 
#     with respect to m and setting the derivative equal to 0.  Do this to show that the minimizing value is m=1n???ni=1xi.  Said another way, the sample mean is 
#     the number that minimizes the sum of squared differences from a collection of numbers.
#set the derivative to 0 and calculate m
# 2(xi - n * m) = 0
# xi - n * m = 0
# xi = n * m
#(1/n)xi = m

#4.  Consider the K-means algorithm in one dimension (clustering a collection of numbers,x1, . . . , xn), using the usual interpretation of our clustering 
#     functionc(i).  That is,c(i) is the cluster that xi currently belongs to.

#     (a)  Show that the objective function H=K???k=1???i:c(i)=k(xi???mk)^2 decreases  at  each  iteration  of  the  algorithm.   It  may  help  to  show  that  
#     both  steps  of  the  algorithm: assigning points to the closest cluster, and recomputing the cluster means both decrease H.
# the objective function decreases at each iteration because both steps of the algorithm can only cause the cluster means to decrease or stay the same. If the 
# mean is updated it causes the function H to decrease as it will more closely cluster the points around it. The other step, allocating points to a cluster can
# only decrease H as points will only be reclustered if it is a better option than a previous iteration. Both options will never increase H and when they converge
# we know we have found an optimal solution.

#     (b)  Argue  the  the  algorithm  cannot  cycle  (repeat  an  earlier  configuration  of  the  clustering  function),  thus must terminate.
# There are at most K^n ways to partition N data points into k clusters where each partition can be called a "clustering" for each iteration of the 
# algorithm we make a new clustering based only on the old clustering. So if the old clustering is the same as the new then the new clustering will 
# will again be the same and if the new clustering is different from the old clustering then the newer one has a lower cost. Since the algorithm 
# iterates a function whose domain is a finite set, the only way the algorithm can cycle is if the old clustering has a lower cost than the new clustering
# which we know not to be true. Hence, there is no way the algorithm can cycle and it will terminate in a finite number of iterations

#5.  For the data points in problem 2, find a "stable configuration" of m1 and m2 that is not "globally optimal."  A stable configuration is one that doesn't 
#     change after an iteration of the K-means algorithm.  "Globally optimal" means giving the lowest value of the objective criterion from the previous 
#     problem when compared with all possible choices of m1 and m2.
# m1 = (0,1)
# m2 = (1,3)
# m1Cluster = {(0,1), (1,1), (0,2)}
# m2Cluster = {(1,2),(0,3),(1,3)}
# m1Mean = (1/3, 4/3)
# m2Mean = (2/3, 8/3)

#(0.471357)^2 + (0.745371)^2 + (0.745371)^2 + (0.471357)^2 + (0.745371)^2 + (0.745371)^2 = 2.66666655346
