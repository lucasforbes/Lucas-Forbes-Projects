#1.   This problem works with the Chilean voting data as in chilean
#     voting.r where the data matrix is x.  The age variable can be simplified 
#     to retain only the decade of the person by using x[,5] = floor(x[,5]/10)
#(a)  Using this simplification, create a 3-dimensional table on age, 
#     education and vote.  Show your code and your output.
x = read.csv2("C:\\Users\\Ldforbes\\Downloads\\chilean_voting.csv",stringsAsFactors=FALSE,sep=",");
x = x[no | yes,]
x[,5] = floor(x[,5]/10)

t = table(x[c(5,6,9)])
print(t)
age = 5
gender = 4
region = 2
education = 6
vote = 9
#mosaicplot(t)
cond_probRow = prop.table(t, margin = 1);
#cond_probRow = prop.table(margin = 2)
cond_probCol = prop.table(t, margin = 2);
#cond_probCol = prop.table(margin = 2)
print(cond_probRow)
print(cond_probCol)

#(b)  Using this table create a Bayes� classifier to predict the voting 
#     status of a person given their decade and education  level.   You  can  
#     represent  your  classifier  as  we  have  done  in  class.   That  is,  
#     as  a  table  where the  rows  account  for  all  possible  configurations  
#     of  the  decade and  education  variables,  giving  the  vote classification for each.

error = 0
for(i in 1:1750){
  thisAge = x[i, age]
  thisEdu = x[i, education]
  ans = ""
  if(t[thisAge, thisEdu, 1] > t[thisAge,thisEdu,2]) ans = "N"
  else ans = "Y"
  cat(thisEdu, "\t", thisAge,"  ", x[i, vote], "   ", ans, "\n")
  if(x[i,vote] != ans) error = error + 1
}
cat("Errors = ", error, "\n")
cat("Percent Error = ", error / 1750, "\n")

# #probability No
# sumNo = sum(x=no)
# 
# #probability Yes
# sumYes = sum(x=yes)
# pNo = sumNo / (sumNo + sumYes)
# pYes = sumYes / (sumNo + sumYes)
# print(pNo)
# print(pYes)
# #probability age | No
# count = with(x, table(revetment, pool)) %>% 
# count.table(margin = 1)
# print(count)
# 
# #probability age | Yes
# 
# #probability P | No
# 
# #probability P | Yes
# 
# #probability PS | No
# 
# #probability PS | Yes
# 
# #probability S | No
# 
# #probability S | Yes

# 
# for (f in 1:2) {    	    # for each feature
#   bk = quantile(x[,f,],c(0,.5,1))  # the 0%, 25% , 50%, 75%, 100% quantiles
#   bk[1] = 0;            # kludge for endpoint problem
#   x[,f,] = cut(x[,f,],breaks=bk, labels=1:2)   # substitute the 4 quantized values
# }
# 
# 
# 
# Q = array(0,dim=c(5,6,9));	# Q[c,f,v] is P(feature f = v | class c)
# for (c in 1:2) {
#   for (f in 1:4) {
#     for (v in 1:4) {
#       Q[c,f,v] = sum(x[,f,c] == v)/50   # estimate probs by usual counting
#     }
#   }
# }


#(c)  How would the Bayes� classifier classify a female, 
#     post-secondary-educated person from the SA region inher 40�s?

# they would be classified as a "Yes" voter

#d)   Expalin your degree of confidence in this classification and why you believe this.
# 
#
cat("Errors = ", error, "\n")
cat("Percent Error = ", error / 1750, "\n")
#Our classifier does not take into account gender and we only focus on education and age. From the data,
# the greates probability of votes is in the U classification and based on this error I am confident in the classification.

#2.   Continuing with the Chilean voting data:
#(a)  Estimate the prior distribution on the vote (Y or N) using the data.
totVotes = 2700
yesVotes = 887
yesRatio = 887/2700
noVotes = 863
noRatio = 863/2700

#(b)  Separately for both the Yes and No voters, estimate the class-conditional 
#     distributions for gender, education, region, and age.  For instance, for gender 
#     you would need to compute four probabilities:
#     P(F|Yes),P(M|Yes),P(F|No),P(M|No)
#gender
g = table(x[c(4,9)])
e = table(x[c(6,9)])
r = table(x[c(2,9)])
a = table(x[c(5,9)])
        
cond_probG = prop.table(g,margin = 2);
cond_probE = prop.table(e, margin = 2);
cond_probR = prop.table(r, margin = 2);
cond_probA = prop.table(a, margin = 2);
print(cond_probG)
print(cond_probE)
print(cond_probR)
print(cond_probA)
#education

#region

#age
print(t)

#mosaicplot(t)
cond_probRow = t.table(margin = 1);
#     P()
#c)   How would the naive Bayes� classifier classify a female, post-secondary-educated person 
#     from the SA regionin her 40s?  Show the calculations clearly.

#3.   A common medical condition is present in 25% of the population.  We have 10 tests for the 
#     condition, which donot discriminate particularly well.  To be precise, when the condition 
#     is present the tests give a positive result with probabilities:  .65, .60, .57, .62, .58, 
#     .64, .67, .58, .61, .60.  However when the condition is not present thetest gives a negative
#     result with the stated probabilities.  We will assume that the tests are independent giventhe 
#     medical condition, thus it is reasonable to use a naive Bayes classifier.  Write an R program 
#     that does the following n= 1000 times
#(a)  simulate a boolean variable that behaves like the described medical condition.
n = 1000
x = (runif(n)<0.25)*1
y = c(0.65,0.60,0.57,0.62,0.58,0.64,0.67,0.58,0.61,0.60)
z = c()
#(b)  Generate the results of the 10 tests (which depend on whether or not the condition exists)
for(i in 1:n){
  t = runif(10)
  r = t < y
  if(x[i] > 0){
    z = rbind(z,r*1)
  }
  else{
    z = rbind(z,abs(r-1))
  }
}
#(c)  Compute the posterior probability that the condition is present, given the test results
p = 0.25
prob = c()
for(i in 1:n){
  p1 = prod(z[i,]*y+abs(z[i,]-1)*(1-y))
  p1 = p1 * p
  p2 = prod(z[i,]*(1-y)+abs(z[i,]-1)*y)
  p2 = p2*(1-p)
  prob = c(prob,p1/(p1+p2))
}
#(d)  Classify the the instance as either �trait present� or �trait not present�
t = (prob>0.5)*0.5


#(e)  Keep a tally of the number of correctly identified individuals and compute the error rate of your classifier.
#     Your results should show that a collection of rather weak classifiers can perform very well when used collectively.
sum(x==t)
sum(x==t)/n
#error rate
1-sum(x==t)/n

#4.   Here we want to create a 5-NN classifier of the iris data.  Following the discussion in class, 
#     for each instance in our data set we will find the 5 closest instances (other than the instance itself).  
#     It may help to know about the order function in R: If x is vector of numbers, order(x) gives the order of elements.  
#     So if index=order(x) then index[1] is the the index of the smallest element, index[2] is the index of the 2nd smallest, etc.  
#     Said another way x[index[1]] is the smallest value of x, x[index[2]] is the 2nd smallest, etc.  Use this information to create a
#     5-NN classifier for the iris data.  That is, your classifier should loop through each row of the distance matrix and  tally  
#     the  class  labels  of  the  5  closest  instances  (other  than  the  instance  itself).   You  would  classify  the
#     instance according to the most prevalent class within the 5 neighbors, breaking ties arbitrarily.
data(iris); 

d = as.matrix(dist(iris[,1:4]))

n = nrow(iris);

#(a)  Compute a vector, classhat, which is the result of your classifier applied to each instance.1
class = as.numeric(iris[,5])
classhat = rep(0,n);
#(b)  Compute the error rate of your classifier.
for (i in 1:n){
  j = which.min(d[i,])
  classhat[i] = iris[j,5];
}
cat("error rate = ", sum(class != classhat) / n, "\n");

#(c)  Explain why you do or don�t believe your error rate is an accurate estimate of the generalization error rate
# The error rate is most likely not an accurate estimate of the generalization error rate. We get an error rate of
# 0 which means the model is overfitting the data, and if we overfit we are not generalizing as we should. 
#5.   Consider two R vectors created by x = 10 + 10*rnorm(100) y = -10 + 3*rnorm(100)
#(a)  Create two different scatterplots, one of the raw vectors, x and y, and another of the standardized vectors.
#     Remember that the standardized vector x'is given by "Look on HW for Formula" where
#     Formula
# raw vectors:
x = 10 + 10*rnorm(100) 
y = -10 + 3*rnorm(100)
plot(x,y)
xm = mean(x)
s = sd(x)
ym = mean(y)
ys = sd(y)
x1 = (x - xm)/s
y1 = (y - ym)/ys
plot(x1,y1)
#     These two quantities can be computed in R by mean(x) =  �xand sd(x) =s.(b)  What are the similarities and dissimilarities in the 
#     original plot and the standardized plot?