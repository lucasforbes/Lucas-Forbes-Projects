#1. a)  No, T and S are not independent. If they were independent the fact that a person has trait T would not effect
#       whether they have the trait S. Obviously whether or not a person has trait S is affected by them having trait T as 
#       90% of people with trait T have trait S compared to people without trait T only having a 30% chance of having trait S
#       P(S^T) = .18 does not equal P(S) = .18+.24=.42
#   b)  P(S^T) / P(S) = .18/.42 = .4286
#   c)  
x=runif(10000);y=runif(10000)

S=c();T=c()

S[which(x<=2/5)]=1;S[which(x>2/5)]=0

T[intersect(which(S==1),which(y<=2/5))]=1
T[intersect(which(S==1),which(y>2/5))]=0
T[intersect(which(S==0),which(y<1/15))]=1
T[intersect(which(S==0),which(y>1/15))]=0

(t=table(S,T)/10000)

(p.hat=t[2,2]/(t[2,1]+t[2,2]))

#   d)
p.hat-1.96*sqrt(p.hat*(1-p.hat))/100;p.hat+1.96*sqrt(p.hat*(1-p.hat))/100
# yes this is consistent with my answer to part b as I estimated P(S^T) / P(S) = (4/25)/(2/5) = 2/5

#2. a)  P(A|not favor) = ((P(A)*(1-P(favor|A))/((P(A)*(1-P(favor|A)+(P(B)*(1-P(favor|B)+(P(C)*(1-P(favor|C))
#   b)  (.1)(.7)/((0.1*0.7)+(0.3*0.5)+(0.6*0.1)) = .07/.28 = .25
#   c)  (0.3*0.5)/((0.1*0.7)+(0.3*0.5)+(0.6*0.1)) = .15/.28 = .5357
#   d)  (0.6*0.1)/((0.1*0.7)+(0.3*0.5)+(0.6*0.1)) = .06/.28 = .2143
#   e)  
numA = 0
n= 10000
d = rep(0,n)
for (i in 1:n){
  A = runif(1) 
  #P(Favor Ballot) = (.1 * .3)+(.3 * .5) + (.6 * .9) = .72
  if(A <= .1){
    B = runif(1)
    if(B <= .3){
      d[i] = 1
      numA = numA + 1
    }
  }
  else if(A > .1 && A <= .4){
    B = runif(1)
    if(B <= .5){
      d[i] = 1
    }
  }
  else{
    B = runif(1)
    if(B <= .9){
      d[i] = 1
    }
  }
}
print("Estimate of political party A for individuals who favor ballot measure")
print(numA/sum(d))
#   f)  No, in part a the probability for not favoring the ballot measure was calculated for people in party A. Since we 
#       do not know the political party of the person we met we can not apply this calculation on them

#3. a)  
data("UCBAdmissions"); # import the data
ucb = UCBAdmissions;   # abbreviate "UCBAdmissions"
print(dimnames(ucb));
print(apply(ucb,c("Dept","Admit"),sum));  # 2-way table of Department x Admit
mosaicplot(apply(ucb,c("Dept","Admit"),sum));  # mosaic plot clearer ...
#Ignore:The department and admission status are not independent. P(admitance) = 1755/4531 = 0.3873
#       while the P(admitance^dep(f)) = 46/715 = .3035. People in department f have a lower chance 
#       of being admitted which wouldn't be the case if the two events were independent
#   
#       They table appears to be heavily biased toward male admitance vs female
#   b)  
print(apply(ucb,c("Dept","Gender"),sum));  # 2-way table of Department x Admit
mosaicplot(apply(ucb,c("Dept","Gender"),sum));  # mosaic plot clearer ...
#       Similar to part a the total is skewed but now we see that actually males are only heavily
#       favored for departments A and B. The rest of the departments seem fairly even and not biased
#   c)
print(t(ucb[,,"F"]));  # 2-way table of Department x Admit
mosaicplot(t(ucb[,,"F"]));  # mosaic plot clearer ...
#       Gender and admit status appear to be independent for the department f as Males have an acceptance
#       rate of .0590 and females .0704 which are very similar
#   d)  YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY
#print(apply(ucb("Rejected"),sum)); 
#4  a)
data(iris);  	    # include the famous iris data
n = nrow(iris);     # n is number of observations (will usually use "n" for this)
type = rep(0,n);

type[iris[,5] == "setosa"] = "s";      # class is 5th column.  
type[iris[,5] == "versicolor"] = "c";
type[iris[,5] == "virginica"] = "v";

pairs(iris[,1:4],pch=21,bg = c("red", "green3", "blue"),cex=1)   # pairs plot using all four variables
#   b)  based on observation I would recommend building a classifier for Sepal Width. While all variables
#       do not allow a person to visually classify a iris's type based on where it falls on the graph, Sepal 
#       width appears to be the least coorelated between types which may make it easier to classify.
#5) a)
d1 = c(1,2,3,4,5,6)
d2 = c(1,1,3,3,5,5,2,4,6)
d3 = c(4,4,5,5,6,6,1,2,3)
choice = runif(1)
s = c()
die = 0
cheeze <- function(){
  if(choice <=.5){
    s = sample(d1,3,replace=TRUE)
    die = 1
  }
  if(choice > .5 && choice <= .875){
    s = sample(d2,3,replace=TRUE)
    die = 2
  }
  if(choice > .875){
    s = sample(d1,3,replace=TRUE)
    die = 3
  }
  return(c(die,s))
}
print(cheeze());
#   b) = dice a = (1/6)^3 = .00463
#        dice b = (2/9) * (1/9) * (1/9) = .0027
#        dice c = (2/9) * (2/9) * (1/9) = .0055
#       P(A|x1, x2, x3) = (1/2)*.00463/((.5*.00463)+((3/8)*.0027)+((1/8)*.0055) = 0.5766
#       P(B|x1, x2, x3) = (3/8)*.0027/((.5*.00463)+((3/8)*.0027)+((1/8)*.0055) = 0.2522
#       P(C|x1, x2, x3) = ((1/8)*.0055)/((.5*.00463)+((3/8)*.0027)+((1/8)*.0055) = 0.1712
#   c)  Bayes classifier says classify the dice having a maximum probability so bayes would classify this result as dice a
#   d)
n= 1000
l = list()
d = rep(l,n)
for (i in 1:n){
  d[i] = c(cheeze())
}
for (i in 1:n){
  #print(d[i])
}
print(d[22])