#1.  100,000 Massachusetts adults were randomly sampled with two factors recorded:  whether or not the individualhad diabetes, 
#    and whether or not the person ate Kale.  The following gives a table of the results.

# a) We can't determine the P(Diabetes|Kale) for Massachusetts adults as we do not have the whole population but just a sample. This means
#     we can only find the sample proportions based on the sample data.

# b) The probability for the sample proportion is 796 / (796+9187) = 0.0797

# c) for kale eaters: 0.0797 +/- (1.96 * sqrt((0.0797 * (1-0.0797))/9983)) = (0.0744,0.0850)
#    for non-kale eaters: p = 9900/90017 = 0.11
#    CI = .11 +/- (1.96 * sqrt((.11 * .89)/90017)) =  (.108,0.112)
  
# d) No we cannot determine that kale eaters are less likely to get diabetes as it could be associated with other factors such as blood exersize
#    which is not taken into account in our sample
  
# e) Yes, we can determine Kale eaters are less likely to get diabetes based on the fact that the low end of a 95% CI for non kale eaters 
#    is higher than the high end of the 95% CI for kale eaters
  
# f) Kale is low in sugar. People who eat kale are getting their calories from food that has less sugar than those who don't eat kale.
#    Blood sugar is known to have an affect on the probability of having diabetes
  
# 2.  Consider the same numerical data, but imagine that the people were assigned to eat kale for 10 years, according to the following mechanisms.  
#     In each case say if you believe there is evidence that Kale causes a lower rate of diabetes and explain why.
  
# a)  No, it is known that some zip codes are better areas than others. The better zipcodes may have more access to exersize, higher income
#     for healthier foods, and live an all around healthier lifestyle. If these zip codes get put in the same group it could skew results

# b)  No, because they asked people to rate themselves health consious or not, there is no baseline to determine if the kale actual took effect
  
# c)  If this R program was used to distribut people into the kale and non-kale groups, you would expect there to be roughly 40% of people in
#     the Kale eating group which is not even close to the case so NO, this would not be evidence.
  
# 3.  Consider the following computer experiment.  Generate two �uniformly distributed� numbers x, y in the interval[0,1] (this is what runif does).  
#     Let A be the event that x+y < 1 and B be the event that x-y < 0.
n= 500
resultX = rep(0,n)
resultY = rep(0,n)
p = rep(0,n)
zeroZero = 0
zeroOne = 0
oneZero = 0
oneOne = 0
countA = 0
countB = 0
countSame = 0
eventAB = 0
for (i in 1:n){
  x = runif(1); 
  y = runif(1);
  a = x + y < 1
  b = x - y < 0
  if(a){
    countA = countA + 1
    countSame = countSame + 1
  }
  if(b){
    countB = countB + 1
    countSame = countSame + 1
  }
  if(countSame %% 2 == 0){
    eventAB = eventAB + 1
  }
  countSame = 0
  resultX[i] = a
  resultY[i] = b
  if(a == 0 & b == 0){
    zeroZero = zeroZero + 1
    p[i] = 0
  }
  else if(a == 0 & b == 1){
    zeroOne = zeroOne + 1
    p[i] = 1
  }
  else if(a == 1 & b == 0){
    oneZero = oneZero + 1
    p[i] = 2
  }
  else{
    oneOne = oneOne + 1
    p[i] = 3
  }
}
probA = countA / n
probB = countA / n
probAB = eventAB / n
probAB1 = probAB / probB

resTable <- matrix(c(zeroZero, zeroOne, oneZero, oneOne),ncol=2,byrow=TRUE)
colnames(resTable) <- c("F","T")
rownames(resTable) <- c("F", "T")
resTable<- as.table(resTable)
resTable
#mosaicplot(resTable)

confiErrorA <- qnorm(0.95)*probA/sqrt(n)
cat(confiErrorA)
confiErrorAB <- qnorm(0.95)*probAB1/sqrt(n)
cat("p(A) CI: (" ,(probA - confiErrorA) , ", " , (probA + confiErrorA) , ")")
cat("p(A|B) CI: (" ,(probAB1 - confiErrorAB) , ", " , (probAB1 + confiErrorAB) , ")")
plot((1:n),p, pch = 20)


#These events have shown to be fairly dependent on eachother as the confidence interval for
#(A|B) is approximently ( 1.096305 ,  0.9460679 )

# from the graph produced it appears the values are evenly distributed hinting towards
# the two events are independent of eachother

# P(A) = 

#4. Consider the following experiment for generating two boolean variables corresponding to the events A, B.  Here x%%y
#   is the remainder when x is divided by y, so x%%1 is the �decimal part� ofx.
nu = 500000
a = rep(FALSE, nu)
b = rep(FALSE, nu)
ab = rep(FALSE, nu)

for(i in 1: nu){
  x = runif(1);
  a[i] = (x < .5);
  b[i] = ((2*x) %% 1) < .5
  ab[i] = (a[i] & b[i]);
  
}
proA = sum(a) / nu
proB = sum(b) / nu
proAB = sum(ab) / nu
ciPA = qnorm(0.95) * (proA) / sqrt(nu);
ciPB = qnorm(0.95) * (proB) / sqrt(nu);
ciPAB = qnorm(0.95) * (proAB) / sqrt(nu);

cat("p(A) CI: (" ,(proA - ciPA) , ", " , (proA + ciPA) , ")")
cat("p(B) CI: (" ,(proB - ciPB) , ", " , (proB + ciPB) , ")")
cat("p(A,B) CI: (" ,(proAB - ciPAB) , ", " , (proAB + ciPAB) , ")")

#   A and B seem to be independent of eachother as the 95% confidence interval for P(A,B)
#   is approximently (.248*, .2499) meaning A and B only occur around 25% of the time which is less then their individual
#   probabilities, meaning A does not impact the chance of event B occuring and vice versa

#5. a:  These events can be seen as being independent of eachother as the voter is chosen at random
#       and their preference of mayor vs police chief cannot be known. One preference does not influence the other
#   b:  These events are also independent of eachother because the likelyhood of the second person favoring the mayor
#       is not influenced by the first person's preference
#   c:  These events are also independent of eachother because the probability of next flip of a coin
#       for each event is exactly the same as the first flip. One event does not effect the other
#   d:  These events are most likely dependent of eachother as the probability that the person likes
#       the incredible 2 can probably be shown to be correlated with the event "liking increadible's 1

