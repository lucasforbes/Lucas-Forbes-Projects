#problem 1
#a.
n= 5000
x = rep(0,n)


for (i in 1:n){
	a = runif(1)<.5;
	b = runif(1)<.5;
	c = runif(1)<.5;

if(b==c & a!=b){
	x[i] = 1
}
else{
	x[i] = 0
}
}
cat("A's probability of winning: ", sum(x==1)/n)

#b.
# using the probability of A's winning = 0.2598 we can find how many trials to
# get a 95% confidence interval with a half width of +/-.01
# formula to use: p +/- 1.96 * sqrt(p(1-p))/sqrt(n)
# 0.01 = sqrt(0.2598(1-0.2598))/ sqrt(n)
# 0.01 = 0.43852475414 / sqrt(n)
# 43.852475414 = sqrt(n)
# n = 1923.0396 trials

#c.
# The true value of P(A) may or may not be in the confidence interval because
# the confidence interval is on the entire simulation. That is, for 100 simulations
# of the simulation done in part a, we get 10 different values of P(A) and 
# 100 different confidence intervals. The 95% confidence interval means the 
# value of P(A) is a reliable value for 95 of those simulations. The other 5
# simulations would provide an in accurate value for P(A)

#d
# The true probability of P(A wins) is unknown as the actual probability
# is almost always unknown for a given situation. The actual probability of 
# a coin landing heads up is affected by the position from which it is tossed,
# the asymmetry of the two faces of the coin etc, meaning the actual probability
# of A wins can not be exact but can come very close to 0.25
 
#problem 2
numTrials = 10000 #used this number of trials based on a p^ value of .5 and +/- .005 
#                 using the sqrt(n) rule

aWins = rep(0,numTrials);
for(i in 1:numTrials){
	a = 14
	b = 14
	while(a > 13 & b > 13){
		a = sample(1:52, 1, replace = T)
		b = sample(1:52, 1, replace = T)
	}
	if(a <= 13){
		aWins[i] = 1
	}
	else{
		aWins[i] = 0
	}
}

cat("A's probability of winning: ", round(sum((aWins==1)/numTrials),digits=2))




#problem 3
#a. 	sample space = {(x,y): x = first card, y = second card}
#	number of elemends in Omega = 1326
#b.	4 cards with same rank and select 2 = 4*3/2 = 6 ways
#	13 types of cards * 6 ways = 78 elements of Omega
#c.	78/1326 = 1/17 = .059

#problem 4	
#a.
trys = 300
prob = .3
ciUpper = rep(0, trys)
ciLower = rep(0, trys)

for(i in 1:trys){
	num = 1.96 * sqrt(prob * (1-prob))/sqrt(i)
	xUp = .3 + num
	xLow = .3 - num
	ciUpper[i] = xUp
	ciLower[i] = xLow
}
cat("Confidence Lower Limit: ", ciLower[300], " Confidence Upper Limit: ", ciUpper[300]);

#b. 
plot((1:trys), ciUpper, col = "red")
par(new=T)
plot((1:trys), ciLower)

#c
trys2 = 1000
inCI = rep(0, trys2)
p = .3
for(i in 1:trys2){
	num = 1.96 * sqrt(prob * (1-prob))/sqrt(i)
	xUp = .3 + num
	xLow = .3 - num
	if(p < xUp & p > xLow){
		inCI[i] = 1
	}
	
}
cat("Fraction of the time CI contains true probability: ", sum(inCI==1)/trys2);


#Problem 5
# The exact probability that A's number is greater than B's is 1/2 or .5.
# Let A's choice be xi. P(A) = 1/n where i is an element in {1,2,3,...,n}
# If A's number is bigger than B's then B's choice, xj < xi
# P(B) = (i-1)/(n-1)
# total probability = sum from i = 1 to n, (1/n) * ((i-1)/(n-1))
# total probability = sum from i = 1 to n - 1, (1/n) * (i /(n-1))
# total probability = (1/n(n-1)) * ((n-1)(n)/2)
# total probability = 1/2




#problem 6
p=c(.1,.2,.3,.35, .02, .03)
run = sample(1:6, 1, replace=TRUE, prob = p)
cat(run);
