#HW 5
#1.  Consider the Fisher iris data, as plotted in the program �iris.r� studied in class.
#   (a)  Reasoning from this plot,  choose a variable and a split point for the variable so that the 
#       resulting two regions have one that contains only Setosa flowers, while the ther mixes the other two classes.
data(iris)
n = nrow(iris);
type[iris[,5] == "setosa"] = "s";      # class is 5th column.
type[iris[,5] == "versicolor"] = "c";
type[iris[,5] == "virginica"] = "v";
setosa = iris[iris[,4] < 0.61,]
otherTwo = iris[iris[,4] >= 0.61,]
 print(setosa)
 print(otherTwo)
#   (b)  For the �mixed� region resulting from the first part, choose a variable and split point that separates the
#       Versicolor and Virginica flowers as well as possible.
versicolor = otherTwo[otherTwo[,3] < 4.9,]
virginica = otherTwo[otherTwo[,3] >= 4.9,]
 print(versicolor)
 print(virginica)
#   (c)  Sketch the resulting three regions over the scatterplot of the two relevant variables, clearly labeling 
#       each region with the resulting class.
setosa[,5] = "A";      # class is 5th column.
versicolor[,5] = "B";
virginica[,5] = "C"
newTable = rbind(setosa, versicolor, virginica)
print(newTable)
type[newTable[,5] == "A"] = "A";      # class is 5th column.
type[newTable[,5] == "B"] = "B";
type[newTable[,5] == "C"] = "C";
par(mar=c(1,1,1,1))
plot(iris[,4],iris[,3],pch=type)  # scatterplot

#2.   Consider  the  table  for  a  2-class  tree  classifier  with  classes{+,-}
#     below  giving  the  number  of  +�s  and  -�s reaching each node. The nodes are numbered so that 1 is the root, 
#     while the children of node k are 2k and 2k+ 1.  The �terminal� column says if a node is terminal or not.
#     (a)  Construct the tree as a graph (the usual depiction of a tree) labeling the nodes with numbers and giving
#          the classification each node and the number of errors it would produce if it were a terminal node.
#                                                   Number of errors = Numerator
            #                 (1)                   1: C = -, #Errors = 40/100
            #             /         \
            #       (2)                 (3)         2: C = -, #Errors = 22/57   3: C = -, #Errors = 18/43
            #     /    \              /     \
            #   (4)     (5)          (6)      (7)   4: C = +, #Errors = 5/20  5: C = -, #Errors = 7/37  6: C = +, #Errors = 5/17  7: C = -, #Errors = 6/26
            #   / \                                 
            # (8) (9)                               8: C = +, #Errors = 2/9  9: C = +, #Errors = 3/11
          #       /  \           
          #     (18) (19)                           18: C = +, #Errors =  0/7 19: C = -, #Errors = 1/4

library(rpart)
train = data.frame(
  node = c(c(1:9),18,19),
  pos = c(40, 22, 18, 15, 7, 12, 6, 7, 8, 7, 1),
  neg = c(60, 35, 25, 5, 30, 5, 20, 2, 3, 0, 3),
  terminal = c(0,0,0,0,1,1,1,1,0,1,1)
)
train
tree1 = rpart(node ~ ., data=train, method="class", minbucket=1, cp=0, minsplit=2)
#install.packages('rpart.plot')
library(rpart.plot)
rpart.plot(tree1, type = 1, extra = 3, under = TRUE)


#     (b)  Compute R(T) where T is the tree given in the example and R(T) is our probabability of error for the
#          tree when tested on the training set.

# 5: Errors = 7/100  
# 6: Errors = 5/100
# 7: Errors = 6/100
# 8: Errors = 2/100

# 18: Errors =  0/100 
# 19: Errors = 1/100

#total = 21/100

# ctrain = sample(0:1, 11, replace=TRUE)
# pred = predict(tree1, train, type="vector")
# trainerrors = sum(pred != ctrain)
# cat("num errors: ", trainerrors, "\n")

#     (c)  Explain why you do or do not believe this is an accurate representation of the tree�s performance on new data.
#         No, I do not believe this is an accurate representation on new data. This tree was built to match the training data
#         and its nodes are created accordingly. With new data, the creation of the original tree would be obsolete and not fit well
#     (d)  Compute the optimal penalized risk,R*a for each node of T where a=.03.  Give the corresponding optimal tree Ta.
#   a = .03
# 1: Optimal Penalized Risk = a + 2 + 3 =  .36
# 2: Optimal Penalized Risk = a + 4 = 5 = .19
# 3: Optimal Penalized Risk = a + 6 + 7 = .14
# 4: Optimal Penalized Risk = a + 8 + 9 = .09
# 5: Optimal Penalized Risk = .07  
# 6: Optimal Penalized Risk = .05
# 7: Optimal Penalized Risk = .06
# 8: Optimal Penalized Risk = .02
# 9: Optimal Penalized Risk = a + 18 + 19 = .04
# 18: Optimal Penalized Risk =  0 
# 19: Optimal Penalized Risk = .01

#                 (1)                   1: Error = 40/100  ErrorAfter = .32
#             /         \
#       (2)                 (3)         2: Errors = 22/100 ErrorAfter = .15  3: Errors = 18/100  ErrorAfter = .14
#     /    \              /     \
#   (4)     (5)          (6)      (7)   4: Errors = 5/100  ErrorAfter = .05  5: Errors = 7/100  ErrorAfter = .07
#                                       6: Errors = 5/100  ErrorAfter = .05  7: Errors = 6/100  ErrorAfter = .06
#                           
#                                 prune 8: Errors = 2/100  ErrorAfter = .02  9: Errors = 3/100   ErrorAfter = .03
#                                 prune 18: Errors =  0/100   19: Errors = 1/100

#     (e)  How much do you need to increase a before a different Ta appears?  Same question for decreasing a.
#         for new tree
#         increase by: x | x > .04    new alpah > .07
#         decrease by: x | x > .01    new alpha < .02
#                

#3.   The  following  code  shows  two  things.   First  we  show  how  to  create  a  matrix  from  the  file  
#     �treedata.dat,�available from Canvas, which stores the data above.  In the resulting matrix, the columns contain 
#     the numberof +�s, the number of -�s arriving at each node, and the boolean variable describing the node as terminal 
#     or not.  The rows 10 through 17 are all zeros and are unused.  This way X[i,] gives the data associated with tree 
#     node i.The factorial function, shown below, gives an example of a simple recursive function in R, which you would
#     call by, e.g.  factorial(5).
X = matrix(scan("tree_data.dat"),byrow=TRUE,ncol = 3)
X
factorial <- function(i) {
  if (i == 1) { return(1);}
  else return(i*factorial(i-1))
}
X
#     (a)  Write a recursive function in R that takes as input the number of a node and returns the optimal risk associated with 
#          that node, with a split penalty of a=.03.  When you run your function with input 1 (the root node) it should return 
#          the optimal risk for the entire tree.
a = 0.03
risk <- function(i){
  if(X[i,3] == 1){
    return (min(X[i,1], X[i,2])/100)
  }
  else{
    small = min( (a + risk(i * 2) + risk(i * 2 + 1)), min(X[i,1], X[i,2])/100  )
    return(small)
  }
}
print(risk(3))
#     (b)  Let Ta =.03 denote the associated optimal tree, as computed in the previous problem.  Construct this tree, explicitly 
#          giving the classifications associated with each terminal tree node.
#                 (1)                   1: Error = 40/100  ErrorAfter = .32  
#             /         \
#       (2)                 (3)         2: Errors = 22/100 ErrorAfter = .15  3: Errors = 18/100  ErrorAfter = .14
#     /    \              /     \       4: Errors = 5/100  ErrorAfter = .05  
#   (4)     (5)          (6)      (7)   5: Errors = 7/100  ErrorAfter = .07   
#   / \                                 
# (8) (9)                               6: Errors = 5/100  ErrorAfter = .05   Class = +
#                                       7: Errors = 6/100  ErrorAfter = .06   Class = -
#                                       8: Errors = 2/100  ErrorAfter = .02   Class = +
#                                       9: Errors = 3/100  ErrorAfter = .03   Class = +
#                                 prune 18: Errors =  0/100   19: Errors = 1/100

#     (c)  Explain clearly what problem has Ta=.03 as its optimal solution.
#         Ta = .03 corresponds to node 9

#4.  Consider the following table of cross validation on tree induction for a two-class classification problem,as discussed in class:
#     (a)  In the �rel error� column we get a value of 0.  for the 23rd row.  Explain what this number means.
#           For the 23rd row, there were no values mis-classified. The 23rd node is one of the deepest nodes of the tree
#           where it either classifies the data perfectly so no pruning needs to be done at that node.

#     (b)  In terms of error rate, how well do you think the tree associated with line 23 will perform on different
#          data from the sample population.
#           The tree associated with line 23 will not perform very well on different data as it is either perfect for the training data
#           or overfitting. The tree matches the training data perfectly which makes it highly unlikely that it will
#           fit new data well.

#     (c)  Consider the tree that makes no splits � i.e.  the one that simply classifies according to the most likely class.  
#         How well will this tree classify new data from the same population.
#         This tree will also not classify new data well as it will severly underfit the data. There is no additional
#         splits done which means if the most likely case in the first node is inaccurate, then all classifications will be inaccurate.
#     
#     (d)  Judging from the table, what appears to be your best choice of complexity parameter a?  In what sense is your a value best?
#         The best choice based on the complexity parameter a is the tree at node 212. This tree has the lowest xerror with a value of 0.045955.
#         The alpha value at node 22 is 0.00064725

#5.  As a result of a recent exam, an instructor of a class believes that 70% of the students do yet not understand a topic 
#     sufficiently well.  The instructor wishes to implement a Naive Bayes classifier to estimate each student�s probability of 
#     understanding.  Students are asked a sequence of 7 true or false questions.  The instructor assumes that the responses to 
#     these questions are conditionally independent given the student�s state of knowledge �understands or does not understand.  
#     Of course, understanding is not really a binary attribute in real life as there are degrees of understanding and various 
#     aspects to understanding, though we regard it as binary here. The following code fragment creates a 2x7 matrix,x, wherex[i,j] 
#     is the probability that a student will answer the jth question correctly when her state of knowledge is i.  Here i= 1 
#     corresponds to �not understanding� and i= 2 corresponds to understanding.  For ease of computation we compute the 2x7x2 
#     array,z, wherez[i,j,k] gives the probability that a student will give answer k(k=1 means wrong and k=2 means right) to 
#     question j,given her state of knowledge is i.

x = matrix(c(.7, .6, .5, .5, .5, .5, .7, .8, .7, .6, .7, .9, .8, .9 ),byrow=T,nrow=2);
z = array(0,c(2,7,2));
print(x)


#     (a)  Write R code to fill in the matrix z to be as described in the problem.
for(i in 1:2){
  for(j in 1:7){
    p = x[i,j]
    z[i,j,1] = (1 - p)
    z[i,j,2] = p 
  }
}
print(z)
#     (b)  Using your z matrix create an R function that receives a vector of 7 test answers which are either wrong or right.  
#          For instance, if the answers are c(0,0,0,0,1,1,1), that would mean the student answered only the last three questions 
#          correctly.  The function should return the probability that the student has understood the subject, using a Naive Bayes classifier.

probUnderstand = .7
classify <- function(input){
  probs = input
  for(i in 1:7){
    if(input[i] == 0){
      probs[i] = 1
    }
    else{
      probs[i] = 2
    }
  }
  print(probs)
  probY = (probUnderstand * z[1,1,probs[1]] * z[1,2,probs[2]] * z[1,3,probs[3]] * z[1,4,probs[4]] * z[1,5,probs[5]] * z[1,6,probs[6]] * z[1,7,probs[7]]) / (.5**7)
  probN = (probUnderstand * z[2,1,probs[1]] * z[2,2,probs[2]] * z[2,3,probs[3]] * z[2,4,probs[4]] * z[2,5,probs[5]] * z[2,6,probs[6]] * z[2,7,probs[7]]) / (.5**7)
  st = ''  
  class = max(probY, probN)
  if(class == probY){
    st = 'Understands'
  }
  else{
    st= 'Not Understand'
  }
  cat("The student Understands with a probability of: ", probY, "\n")
  return(probY)
  
}
probStudentUnderstand = classify(c(0,0,0,0,1,1,1))
print(probStudentUnderstand)
